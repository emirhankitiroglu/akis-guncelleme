/* Akış — arayüz, yönlendirme, ekranlar */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const TABS = ['home', 'tx', 'add', 'assets', 'sim'];
const UI = { tab: 'home', txMode: 'list', assetMode: 'all', month: ymNow(), filter: 'all', q: '', simTable: false };
const S = () => Store.state;
const byDateDesc = (a, b) => b.date.localeCompare(a.date) || String(b.id).localeCompare(String(a.id));

/* ---------- Genel yardımcılar ---------- */
/* Günün saatine göre tema: sabah (06-12) aydınlık gökyüzü, öğle (12-18) lacivert, akşam (18-06) gece */
function timeOfDay(h = new Date().getHours()) { return h >= 6 && h < 12 ? 'morning' : h >= 12 && h < 18 ? 'noon' : 'evening'; }
const PALETTES = [
  { id: 'navy', name: 'Boğaz Gecesi', desc: 'İstanbul gecesinin derin laciverti', c: ['#0b3a8c', '#1f6bff', '#3ec5ff'] },
  { id: 'emerald', name: 'Karadeniz Ormanı', desc: 'Yaylaların sisli yeşili', c: ['#065f46', '#10b981', '#7dd3fc'] },
  { id: 'violet', name: 'Kuzey Işıkları', desc: 'Gökyüzünde dans eden aurora', c: ['#4c1d95', '#7c4dff', '#2dd4bf'] },
  { id: 'sunset', name: 'Ege Gün Batımı', desc: 'Bodrum’da altın saat', c: ['#9a3412', '#f97316', '#facc15'] },
  { id: 'rose', name: 'Kiraz Çiçeği', desc: 'Baharın pembe beyazı', c: ['#9d174d', '#ec4899', '#c4b5fd'] },
  { id: 'graphite', name: 'Ay Işığı', desc: 'Gümüş, sakin ve sade', c: ['#1f2937', '#64748b', '#cbd5e1'] },
];
/* Tema/mod değişiminde dokunulan noktadan yayılan dairesel geçiş */
function auraSwitch(x, y, apply) {
  const done = () => { const a = $('#aura'); if (a) { a.classList.remove('shift'); void a.offsetWidth; a.classList.add('shift'); } };
  if (!document.startViewTransition) { apply(); done(); return; }
  const t = document.startViewTransition(() => { apply(); });
  t.ready.then(() => {
    const r = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    document.documentElement.animate({ clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${r}px at ${x}px ${y}px)`] }, { duration: 750, easing: 'cubic-bezier(.22,.9,.24,1)', pseudoElement: '::view-transition-new(root)' });
  }).catch(() => {});
  t.finished.then(done).catch(done);
}
const sysDark = () => !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
function applyTheme() {
  const s = S().settings;
  const t = s.theme === 'auto' ? 'system' : s.theme || 'system';
  const tod = timeOfDay();
  const dark = t === 'dark' || (t === 'system' && sysDark()) || (t === 'time' && tod === 'evening');
  const root = document.documentElement;
  root.dataset.theme = dark ? 'dark' : 'light';
  root.dataset.tod = t === 'time' ? tod : dark ? 'evening' : 'noon';
  root.dataset.pal = s.palette || 'navy';
  const L = s.layout || {};
  root.dataset.density = L.density || 'normal';
  root.dataset.radius = L.radius || 'normal';
  root.dataset.tabbar = L.tabbar || 'normal';
  root.dataset.labels = L.tabLabels === false ? 'off' : 'on';
  root.dataset.scale = L.scale || 'normal';
  root.dataset.hero = L.hero || 'normal';
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.content = getComputedStyle(root).getPropertyValue('--hero-top').trim() || '#0a2f6e';
}
let toastT;
function toast(msg, opt = {}) {
  const el = $('#toast');
  const ic = opt.icon || (opt.tone === 'error' ? 'info' : 'check');
  el.className = 'island ' + (opt.tone || 'ok');
  el.innerHTML = `<span class="isl-ic">${icon(ic)}</span><div class="isl-t">${opt.title ? `<b>${opt.title}</b>` : ''}<span>${msg}</span></div>`;
  void el.offsetWidth; el.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), opt.ms || 2600);
}
/* Hitap: "EMİR", "emir" ya da "eMiR" yazılsa da "Emir" (her kelimenin ilk harfi büyük, gerisi küçük) */
const titleCase = (n) => String(n || '').trim().replace(/\s+/g, ' ').split(' ').map((w) => (w ? w.charAt(0).toLocaleUpperCase('tr-TR') + w.slice(1).toLocaleLowerCase('tr-TR') : w)).join(' ');
const displayName = () => { if (isBetul()) return 'Betül'; return titleCase(S().settings.name); };
/* Sürpriz: Betül / betül / BETÜL / Betul / betul / BETUL ... hepsi */
function isBetul(name = S().settings.name) {
  const first = SMS.norm(String(name || '').trim()).split(/[\s'’.,!]+/)[0].replace(/[^a-z]/g, '');
  return first === 'betul';
}
function bigMoney(v) {
  if (S().settings.hide) return '₺ •••••';
  const s = money(v, { mask: false }); const i = s.lastIndexOf(',');
  return `${s.slice(0, i)}<small>${s.slice(i)}</small>`;
}
const chipMoney = (v) => (S().settings.hide ? '•••' : compact(v));
function countUp(root) {
  if (S().settings.hide) return;
  $$('[data-count]', root).forEach((el) => {
    const to = +el.dataset.count, t0 = performance.now(), dur = 900;
    const step = (t) => { const k = Math.min(1, (t - t0) / dur); el.innerHTML = bigMoney(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  });
}
function seg(items, active, action, cls = '') {
  const i = Math.max(0, items.findIndex((x) => x[0] === active));
  return `<div class="seg ${cls}"><span class="pill ${active}" style="width:calc((100% - 8px)/${items.length});transform:translateX(${i * 100}%)"></span>${items
    .map(([v, l]) => `<button class="${v === active ? 'on' : ''}" data-action="${action}" data-v="${v}">${l}</button>`).join('')}</div>`;
}
function segSet(btn) {
  const seg = btn.closest('.seg'); const btns = $$('button', seg); const i = btns.indexOf(btn);
  btns.forEach((b) => b.classList.toggle('on', b === btn));
  const pill = $('.pill', seg); pill.style.transform = `translateX(${i * 100}%)`; pill.className = 'pill ' + btn.dataset.v;
}
function sw(attr, checked) { return `<label class="switch"><input type="checkbox" ${attr} ${checked ? 'checked' : ''}><i></i></label>`; }

/* ---------- Geçmiş (Android geri tuşu) ---------- */
let guarded = false, ignorePop = 0;
function ensureGuard() { if (!guarded) { history.pushState({ g: 1 }, ''); guarded = true; } }
function releaseGuard() { if (guarded && !sheets.length && UI.tab === 'home') { guarded = false; ignorePop++; history.back(); } }
window.addEventListener('popstate', () => {
  if (ignorePop > 0) { ignorePop--; return; }
  guarded = false;
  if (sheets.length) sheets[sheets.length - 1].close(true);
  else if (UI.tab !== 'home') go('home', true);
  if (sheets.length || UI.tab !== 'home') ensureGuard();
});

/* ---------- Yönlendirme ---------- */
function go(tab, fromPop) {
  if (tab === 'add') { openAddMenu(); return; }
  if (tab === UI.tab) { const p = currentPage(); p && p.scrollTo({ top: 0, behavior: 'smooth' }); return; }
  const dir = TABS.indexOf(tab) > TABS.indexOf(UI.tab) ? 1 : -1;
  UI.tab = tab; render(dir);
  $$('#tabbar .tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  if (!fromPop) { if (tab !== 'home') ensureGuard(); else releaseGuard(); }
}
const currentPage = () => $('#viewport .page:not(.leave-l):not(.leave-r)');
function render(dir = 0) {
  const vp = $('#viewport'); const old = currentPage();
  const page = document.createElement('section'); page.className = 'page entering';
  page.innerHTML = VIEWS[UI.tab]();
  if (old) {
    if (dir) { old.classList.add(dir > 0 ? 'leave-l' : 'leave-r'); setTimeout(() => old.remove(), 330); page.classList.add(dir > 0 ? 'enter-r' : 'enter-l'); }
    else old.remove();
  }
  vp.appendChild(page);
  AFTER[UI.tab] && AFTER[UI.tab](page);
  countUp(page);
  setTimeout(() => page.classList.remove('entering', 'enter-r', 'enter-l'), 950);
}
function refresh() {
  if (typeof syncCardReminders === 'function') syncCardReminders();
  const page = currentPage(); if (!page) return render();
  const st = page.scrollTop; page.innerHTML = VIEWS[UI.tab]();
  AFTER[UI.tab] && AFTER[UI.tab](page); page.scrollTop = st;
}
function refreshBody() {
  const page = currentPage(); const body = page && $('[data-body]', page); if (!body) return refresh();
  body.innerHTML = BODIES[UI.tab](); body.classList.remove('fade-in'); void body.offsetWidth; body.classList.add('fade-in');
  AFTER[UI.tab] && AFTER[UI.tab](page);
}

/* ====================================================================== */
/*  ANA SAYFA                                                              */
/* ====================================================================== */
function txRow(t) {
  const c = catById(t.cat);
  const badge = t.src === 'sms' ? '<span class="badge">SMS</span>' : t.src === 'notif' ? '<span class="badge">Bildirim</span>' : '';
  return `<button class="row" data-action="editTx" data-id="${t.id}">
    <div class="avatar" style="--c:${c.color}">${icon(c.icon)}</div>
    <div class="mid"><div class="ttl">${esc(t.note || c.name)}</div>
      <div class="meta">${c.name}${badge}</div></div>
    <div class="amt num ${t.type}">${t.type === 'in' ? '+' : '-'}${money(t.amount)}</div></button>`;
}

function homeSections() {
  const L = S().settings.layout; const all = ['dock', 'month', 'debts', 'recv', 'spend', 'recent'];
  const list = (L.home || []).filter((x) => all.includes(x.id));
  for (const id of all) if (!list.find((x) => x.id === id)) list.push({ id, on: true });
  L.home = list; return list;
}
const SECTION_NAMES = { dock: 'Hızlı tuşlar', month: 'Aylık özet', debts: 'Borçlar & kartlar', recv: 'Alacaklar', spend: 'Harcama dağılımı', recent: 'Son hareketler' };
function viewHome() {
  const s = S(), ym = ymNow(), m = Calc.monthSums(ym);
  const bal = Calc.balance(), sav = Calc.savingsTotal(), inv = Calc.investTotal(), bes = Calc.besTotal(), debt = Calc.debtTotal();
  const recv = Calc.recvTotal();
  const total = bal + sav + inv + bes + recv - debt;
  const d = new Date(); const h = d.getHours();
  const greet = h < 6 ? 'İyi geceler' : h < 12 ? 'Günaydın' : h < 18 ? 'İyi günler' : 'İyi akşamlar';
  const name = displayName();
  const pend = s.pending.length;
  const todIcon = document.documentElement.dataset.tod === 'evening' ? 'moon' : 'sun';

  const sec = {
    dock: () => `<div class="card dock">
      <button class="dk plus" data-action="newTx" data-type="in" data-hint="Gelir ekle" aria-label="Gelir ekle">${icon('plus')}</button>
      <button class="dk minus" data-action="newTx" data-type="out" data-hint="Gider ekle" aria-label="Gider ekle">${icon('minus')}</button>
      <span class="dk-sep"></span>
      <button class="dk ghost amber" data-action="debt" data-hint="Borç / kart ekle" aria-label="Borç ekle">${icon('receipt')}</button>
      <button class="dk ghost blue" data-action="sms" data-hint="Banka hareketlerini al" aria-label="Banka hareketlerini al">${icon('sync')}${pend ? `<i class="dot-badge">${pend}</i>` : ''}</button>
      <button class="dk ghost violet" data-action="tab" data-tab="sim" data-hint="Geleceği simüle et" aria-label="Simülasyon">${icon('sim')}</button>
    </div>${pend ? `<button class="banner" data-action="pending"><span class="bi">${icon('inbox')}</span><div><b>${pend} yeni hareket onay bekliyor</b><span>SMS ve banka bildirimlerinden bulundu</span></div>${icon('chevR', 'r')}</button>` : ''}${(s.cardSuggest || []).length ? `<button class="banner amber" data-action="cardSuggest"><span class="bi">${icon('card')}</span><div><b>${s.cardSuggest.length} kart ekstresi bulundu</b><span>Kartına eklemek ister misin?</span></div>${icon('chevR', 'r')}</button>` : ''}`,
    month: () => {
      const ratio = m.inc > 0 ? Math.max(0, Math.min(100, (1 - m.out / m.inc) * 100)) : 0;
      return `<div class="card">
      <div class="card-h"><h3>${MONTHS[d.getMonth()]} Özeti</h3><button class="link" data-action="analysis">Analiz ${icon('chevR')}</button></div>
      <div class="month-sum">
        <div class="stat in"><div class="t">${icon('in')}Gelen</div><div class="v num">${money(m.inc)}</div></div>
        <div class="stat out"><div class="t">${icon('out')}Giden</div><div class="v num">${money(m.out)}</div></div>
      </div>
      <div class="ratio"><i style="width:${ratio}%"></i></div>
      <div class="tiny" style="margin-top:8px">Net: <b class="num ${m.net >= 0 ? 'up' : 'down'}">${money(m.net, { sign: true })}</b>${m.inc > 0 ? ` · Gelirinin <b>${pct(ratio, 0)}</b>'i elinde kaldı` : ''}</div>
      ${statusGauge(m, recv, debt)}
    </div>`;
    },
    debts: () => {
      const cards = s.cards || [];
      const debts = (s.debts || []).filter((x) => x.remaining > 0).sort((a, b) => (a.due || '9').localeCompare(b.due || '9'));
      if (!cards.length && !debts.length) return `<div class="card"><div class="card-h"><h3>Borçlar & Kartlar</h3></div><div class="empty-row"><span>Kredi kartlarını ve borçlarını ekle; asgari ödemeni ve son ödeme gününü takip et.</span><div class="btn-row"><button class="btn ghost sm" data-action="addCard">${icon('card')} Kart</button><button class="btn ghost sm" data-action="debt">${icon('receipt')} Borç</button></div></div></div>`;
      const minTotal = cards.reduce((a, c) => a + cardMinimum(c), 0);
      return `<div class="card">
      <div class="card-h"><h3>Borçlar & Kartlar</h3><button class="link" data-action="debts">Tümü ${icon('chevR')}</button></div>
      ${cards.length ? `<div class="kpis" style="margin-bottom:6px"><div class="kpi"><div class="t">Toplam borç</div><div class="v num down">${money(debt)}</div></div><div class="kpi"><div class="t">Toplam asgari</div><div class="v num">${money(minTotal)}</div></div></div>` : ''}
      <div class="rows">${cards.map(cardRow).join('')}${debts.slice(0, 3).map(debtRow).join('')}</div></div>`;
    },
    recv: () => {
      const list = (s.receivables || []).filter((x) => x.remaining > 0);
      return `<div class="card"><div class="card-h"><h3>Alacaklar</h3>${list.length ? `<button class="link" data-action="recvList">Tümü ${icon('chevR')}</button>` : `<button class="link" data-action="recvAdd">${icon('plus')} Ekle</button>`}</div>
        ${list.length ? `<div class="rows">${list.slice(0, 3).map(recvRow).join('')}</div><div class="tiny" style="margin-top:6px">Toplam alacağın <b class="up num">${money(Calc.recvTotal())}</b></div>` : '<div class="tiny">Birine borç verdiysen buraya yaz; geri gelince tek dokunuşla kapat.</div>'}</div>`;
    },
    spend: () => {
      const cats = Calc.byCategory(ym);
      const top = cats.slice(0, 4); const rest = cats.slice(4).reduce((a, x) => a + x.value, 0);
      const segs = top.map((x) => ({ value: x.value, color: x.cat.color, label: x.cat.name }));
      if (rest > 0) segs.push({ value: rest, color: '#94a3b8', label: 'Diğer' });
      return `<div class="card">
      <div class="card-h"><h3>Harcama Dağılımı</h3><span class="tiny">Bu ay</span></div>
      ${segs.length ? `<div class="donut-row">${Charts.donut(segs, { size: 132, thick: 16, center: `<div><b class="num">${compact(m.out)}</b><span>toplam</span></div>` })}
        <div class="legend">${segs.map((x) => `<div class="lg"><i style="background:${x.color}"></i><span>${x.label}</span><b class="num">${pct(x.value / m.out * 100, 0)}</b></div>`).join('')}</div></div>`
        : `<div class="empty">${icon('pie')}<div>Bu ay henüz harcama yok</div></div>`}
    </div>`;
    },
    recent: () => {
      const recent = [...s.tx].sort(byDateDesc).slice(0, s.settings.layout.recentCount || 5);
      return `<div class="card">
      <div class="card-h"><h3>Son Hareketler</h3><button class="link" data-action="tab" data-tab="tx">Tümü ${icon('chevR')}</button></div>
      ${recent.length ? `<div class="rows">${recent.map(txRow).join('')}</div>` : `<div class="empty">${icon('list')}<div>Henüz hareket yok.<br>Banka SMS ve bildirimlerin geldikçe burada görünecek.</div></div>`}
    </div>`;
    },
  };

  return `
  <header class="hero">
    <div class="hero-top">
      <div><div class="hello">${greet}${name ? ', ' + esc(name) : ''}${isBetul() ? ' <span class="heart">♥</span>' : ''}</div>
      <div class="sub">${icon(todIcon, 'tod-ic')} ${d.getDate()} ${MONTHS[d.getMonth()]} ${DAYS[d.getDay()]}</div></div>
      <button class="glass-btn" data-action="settings" aria-label="Ayarlar">${icon('settings')}</button>
    </div>
    <div class="balance">
      <div class="lbl">${debt > 0 ? 'Net Varlık' : 'Toplam Varlık'} <button data-action="toggleHide" aria-label="Gizle/Göster">${icon(s.settings.hide ? 'eyeOff' : 'eye')}</button></div>
      <div class="big num" data-count="${total}">${bigMoney(total)}</div>
      <div class="chips">
        <span class="chip-glass"><span class="dot" style="background:#3ec5ff"></span>Hesap <b class="num">${chipMoney(bal)}</b></span>
        <span class="chip-glass"><span class="dot" style="background:#7aa7ff"></span>Birikim <b class="num">${chipMoney(sav)}</b></span>
        <span class="chip-glass"><span class="dot" style="background:#ffd166"></span>Yatırım <b class="num">${chipMoney(inv)}</b></span>
        ${bes ? `<span class="chip-glass"><span class="dot" style="background:#5ef0b5"></span>BES <b class="num">${chipMoney(bes)}</b></span>` : ''}
        ${debt ? `<span class="chip-glass"><span class="dot" style="background:#ff8d97"></span>Borç <b class="num">${chipMoney(-debt)}</b></span>` : ''}
      </div>
    </div>
  </header>
  <div class="content lift stagger">
    ${homeSections().filter((x) => x.on).map((x) => sec[x.id] ? sec[x.id]() : '').join('')}
  </div>`;
}
function debtRow(x) {
  const late = x.due && x.due < todayISO();
  const paidPct = x.amount ? Math.min(100, ((x.amount - x.remaining) / x.amount) * 100) : 0;
  return `<button class="row" data-action="debtOpen" data-id="${x.id}">
    ${x.bank ? bankBadge(x.bank, 42) : `<div class="avatar" style="--c:${late ? '#ef4c5a' : '#f5a524'}">${icon('receipt')}</div>`}
    <div class="mid"><div class="ttl">${esc(x.name)}</div><div class="meta">${x.due ? (late ? 'Vadesi geçti · ' : 'Vade ') + dayLabel(x.due) : 'Vade yok'}</div>
      <div class="track goal-bar"><i style="width:${paidPct}%;background:var(--in)"></i></div></div>
    <div class="amt num down">${money(x.remaining)}</div></button>`;
}
function cardRow(c) {
  const n = nextDue(c); const min = cardMinimum(c);
  const urgent = n && n.days <= 3 && min > 0;
  return `<button class="row" data-action="cardOpen" data-id="${c.id}">
    ${bankBadge(c.bank, 42)}
    <div class="mid"><div class="ttl">${esc(c.name || bankById(c.bank).name)}${c.last4 ? ` <span class="tiny">•••• ${esc(c.last4)}</span>` : ''}</div>
      <div class="meta ${urgent ? 'down' : ''}">${dueText(n)}</div></div>
    <div class="amt num"><span class="down">${money(c.current)}</span><small class="muted">Asgari ${money(min)}</small></div></button>`;
}
/* ====================================================================== */
/*  HAREKETLER + ANALİZ                                                    */
/* ====================================================================== */
function viewTx() {
  const canNext = UI.month < ymNow();
  return `
  <header class="hero compact">
    <div class="hero-top"><h1>Hareketler</h1><button class="glass-btn" data-action="sms" aria-label="SMS">${icon('msg')}</button></div>
    <div style="margin-top:16px">${seg([['list', 'Liste'], ['analysis', 'Analiz']], UI.txMode, 'txMode')}</div>
    <div class="month-nav"><button data-action="month" data-d="-1">${icon('chevL')}</button><b>${ymLabel(UI.month)}</b><button data-action="month" data-d="1" ${canNext ? '' : 'disabled'}>${icon('chevR')}</button></div>
  </header>
  <div class="content stagger" style="margin-top:14px" data-body>${txBody()}</div>`;
}
function txBody() { return UI.txMode === 'list' ? txListBody() : txAnalysisBody(); }

function txListBody() {
  return `
    <div class="search">${icon('search')}<input placeholder="Hareketlerde ara" data-input="q" value="${esc(UI.q)}"></div>
    <div class="chip-row">${[['all', 'Tümü'], ['in', 'Gelen'], ['out', 'Giden'], ['sms', 'SMS ile']].map(([v, l]) => `<button class="chip ${UI.filter === v ? 'on' : ''}" data-action="filter" data-v="${v}">${l}</button>`).join('')}</div>
    <div id="txlist" style="display:flex;flex-direction:column;gap:12px">${txListHTML()}</div>`;
}
function txListHTML() {
  const q = SMS.norm(UI.q.trim());
  let list = Calc.monthTx(UI.month);
  if (UI.filter === 'in' || UI.filter === 'out') list = list.filter((t) => t.type === UI.filter);
  if (UI.filter === 'sms') list = list.filter((t) => t.src === 'sms');
  if (q) list = list.filter((t) => SMS.norm(`${t.note} ${catById(t.cat).name} ${t.amount}`).includes(q));
  list.sort(byDateDesc);
  if (!list.length) return `<div class="card empty">${icon('search')}<div>${UI.q ? 'Sonuç bulunamadı' : 'Bu ay için hareket yok'}</div></div>`;
  const groups = {};
  for (const t of list) (groups[t.date] = groups[t.date] || []).push(t);
  return Object.entries(groups).map(([date, items]) => {
    const net = items.reduce((a, t) => a + (t.type === 'in' ? t.amount : -t.amount), 0);
    return `<div><div class="day-h"><span>${dayLabel(date)}</span><span class="num ${net >= 0 ? 'up' : 'down'}">${money(net, { sign: true })}</span></div>
      <div class="card" style="padding:4px 12px"><div class="rows">${items.map(txRow).join('')}</div></div></div>`;
  }).join('');
}

function txAnalysisBody() {
  const ym = UI.month, m = Calc.monthSums(ym), prev = Calc.monthSums(ymAdd(ym, -1));
  const cats = Calc.byCategory(ym);
  const months = []; for (let i = 5; i >= 0; i--) { const k = ymAdd(ym, -i); const x = Calc.monthSums(k); months.push({ label: ymLabel(k, true).split(' ')[0], a: x.inc, b: x.out, active: i === 0 }); }
  const isCur = ym === ymNow();
  const days = isCur ? new Date().getDate() : new Date(+ym.slice(0, 4), +ym.slice(5), 0).getDate();
  const outs = Calc.monthTx(ym).filter((t) => t.type === 'out' && !catById(t.cat).internal);
  const biggest = outs.sort((a, b) => b.amount - a.amount)[0];
  const change = prev.out > 0 ? ((m.out - prev.out) / prev.out) * 100 : null;
  const saveRate = m.inc > 0 ? (m.net / m.inc) * 100 : null;
  return `
    <div class="card">
      <div class="month-sum">
        <div class="stat in"><div class="t">${icon('in')}Gelir</div><div class="v num">${money(m.inc)}</div></div>
        <div class="stat out"><div class="t">${icon('out')}Gider</div><div class="v num">${money(m.out)}</div></div>
      </div>
      <div class="kpis" style="margin-top:10px">
        <div class="kpi"><div class="t">Net</div><div class="v num ${m.net >= 0 ? 'up' : 'down'}">${money(m.net, { sign: true })}</div></div>
        <div class="kpi"><div class="t">Tasarruf oranı</div><div class="v num">${saveRate === null ? '—' : pct(saveRate, 0)}</div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Son 6 Ay</h3></div>
      ${Charts.bars(months)}
      <div class="legend-key"><span><i style="background:var(--in)"></i>Gelir</span><span><i style="background:var(--out)"></i>Gider</span></div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Kategoriler</h3><span class="tiny">${ymLabel(ym)}</span></div>
      ${cats.length ? `<div style="display:flex;justify-content:center;margin-bottom:14px">${Charts.donut(cats.map((c) => ({ value: c.value, color: c.cat.color })), { size: 170, thick: 20, center: `<div><b class="num">${compact(m.out)}</b><span>${cats.length} kategori</span></div>` })}</div>
      <div style="display:flex;flex-direction:column;gap:14px">${cats.map((c, i) => `<div class="catbar"><div class="top"><span><span class="avatar" style="--c:${c.cat.color}">${icon(c.cat.icon)}</span>${c.cat.name}</span><b class="num">${money(c.value)} <span class="tiny">${pct(c.value / m.out * 100, 0)}</span></b></div>
        <div class="track"><i style="width:${(c.value / cats[0].value) * 100}%;background:${c.cat.color};animation-delay:${i * 50}ms"></i></div></div>`).join('')}</div>`
        : `<div class="empty">${icon('pie')}<div>Bu ay harcama yok</div></div>`}
    </div>
    <div class="card">
      <div class="card-h"><h3>Göstergeler</h3></div>
      <div class="kpis">
        <div class="kpi"><div class="t">Günlük ort. harcama</div><div class="v num">${money(m.out / Math.max(1, days))}</div></div>
        <div class="kpi"><div class="t">Geçen aya göre gider</div><div class="v num ${change === null ? '' : change > 0 ? 'down' : 'up'}">${change === null ? '—' : (change > 0 ? '▲ ' : '▼ ') + pct(Math.abs(change), 0)}</div></div>
        <div class="kpi" style="grid-column:span 2"><div class="t">En büyük harcama</div><div class="v num">${biggest ? money(biggest.amount) : '—'}</div>${biggest ? `<div class="d muted">${esc(biggest.note || catById(biggest.cat).name)} · ${dayLabel(biggest.date)}</div>` : ''}</div>
      </div>
    </div>`;
}

/* ====================================================================== */
/*  BİRİKİM & YATIRIM                                                      */
/* ====================================================================== */
function assetRow(a) {
  const t = assetTypeById(a.type);
  let meta = t.name, extra = '';
  if (a.kind === 'investment') {
    if (a.track) meta = `<span class="live-dot"></span>${esc(instrById(a.track.id) ? instrById(a.track.id).name : t.name)}${a.track.src === 'yh' ? ' ' + esc(a.track.sym || '') : ''}`;
    if (a.qty) meta += ` · ${Number(a.qty).toLocaleString('tr-TR', { maximumFractionDigits: 4 })} ${esc(a.unit || '')}`;
    if (a.alert && (a.alert.below || a.alert.above)) meta += ` ${icon('bell', 'mini-ic')}`;
    const pl = (a.value || 0) - (a.cost || 0), p = a.cost ? (pl / a.cost) * 100 : 0;
    extra = `<small class="${pl >= 0 ? 'up' : 'down'}">${pl >= 0 ? '▲' : '▼'} ${pct(Math.abs(p))}</small>`;
  } else {
    if (a.rate) meta += ` · ${pct(a.rate)} faiz`;
    if (a.target) extra = `<small class="muted">${pct(Math.min(100, (a.value / a.target) * 100), 0)}</small>`;
  }
  const goal = a.kind === 'savings' && a.target ? `<div class="track goal-bar"><i style="width:${Math.min(100, (a.value / a.target) * 100)}%;background:${t.color}"></i></div>` : '';
  return `<button class="row" data-action="asset" data-id="${a.id}">
    <div class="avatar" style="--c:${t.color}">${icon(t.icon)}</div>
    <div class="mid"><div class="ttl">${esc(a.name)}</div><div class="meta">${meta}</div>${goal}</div>
    <div class="amt num">${money(a.value)}${extra}</div></button>`;
}
function viewAssets() {
  const sav = Calc.savingsTotal(), inv = Calc.investTotal(), cost = Calc.investCost(), bes = Calc.besTotal();
  const pl = inv - cost;
  const live = S().assets.some((a) => a.track);
  const at = S().pricesAt ? new Date(S().pricesAt) : null;
  return `
  <header class="hero compact">
    <div class="hero-top"><h1>Varlıklarım</h1><div style="display:flex;gap:8px">
      ${live ? `<button class="glass-btn" data-action="refreshPrices" aria-label="Fiyatları güncelle">${icon('refresh')}</button>` : ''}
      <button class="glass-btn" data-action="newAsset" aria-label="Ekle">${icon('plus')}</button></div></div>
    <div class="balance" style="margin-top:14px">
      <div class="lbl">Birikim + Yatırım + BES${live && at ? ` · <span class="live-dot"></span>${pad(at.getHours())}:${pad(at.getMinutes())}` : ''}</div>
      <div class="big num" data-count="${sav + inv + bes}">${bigMoney(sav + inv + bes)}</div>
      <div class="chips">
        <span class="chip-glass">Birikim <b class="num">${chipMoney(sav)}</b></span>
        <span class="chip-glass">Yatırım <b class="num">${chipMoney(inv)}</b></span>
        ${cost ? `<span class="chip-glass">K/Z <b class="num" style="color:${pl >= 0 ? '#5ef0b5' : '#ff8d97'}">${S().settings.hide ? '•••' : (pl >= 0 ? '+' : '') + compact(pl)}</b></span>` : ''}
        ${bes ? `<span class="chip-glass">BES <b class="num">${chipMoney(bes)}</b></span>` : ''}
      </div>
    </div>
    <div style="margin-top:16px">${seg([['all', 'Tümü'], ['savings', 'Birikim'], ['investment', 'Yatırım'], ['bes', 'BES']], UI.assetMode, 'assetMode')}</div>
  </header>
  <div class="content stagger" style="margin-top:14px" data-body>${assetsBody()}</div>`;
}
function assetsBody() {
  const A = S().assets, mode = UI.assetMode;
  if (mode === 'bes') return besBody();
  if (mode === 'investment') return investBody();
  const sav = A.filter((a) => a.kind === 'savings'), inv = A.filter((a) => a.kind === 'investment');
  const listCard = (title, items, kind) => `<div class="card">
      <div class="card-h"><h3>${title}</h3><button class="link" data-action="newAsset" data-kind="${kind}">${icon('plus')} Ekle</button></div>
      ${items.length ? `<div class="rows">${items.sort((a, b) => b.value - a.value).map(assetRow).join('')}</div>` : `<div class="empty">${icon(kind === 'savings' ? 'piggy' : 'trend')}<div>Henüz ${kind === 'savings' ? 'birikim' : 'yatırım'} eklenmedi</div></div>`}</div>`;

  if (mode === 'all') {
    const byType = {};
    for (const a of A) byType[a.type] = (byType[a.type] || 0) + (a.value || 0);
    const segs = Object.entries(byType).map(([id, v]) => { const t = assetTypeById(id); return { value: v, color: t.color, label: t.name }; }).filter((x) => x.value > 0).sort((a, b) => b.value - a.value);
    const tot = segs.reduce((s, x) => s + x.value, 0);
    return `
      ${segs.length ? `<div class="card"><div class="card-h"><h3>Dağılım</h3><span class="tiny">${A.length} varlık</span></div>
        <div class="donut-row">${Charts.donut(segs, { size: 140, thick: 18, center: `<div><b class="num">${compact(tot)}</b><span>toplam</span></div>` })}
        <div class="legend">${segs.slice(0, 6).map((x) => `<div class="lg"><i style="background:${x.color}"></i><span>${x.label}</span><b class="num">${pct(x.value / tot * 100, 0)}</b></div>`).join('')}</div></div></div>` : ''}
      ${listCard('Birikimler', sav, 'savings')}
      ${listCard('Yatırımlar', inv, 'investment')}`;
  }
  if (mode === 'savings') {
    const total = sav.reduce((s, a) => s + a.value, 0);
    const monthly = sav.reduce((s, a) => s + a.value * (Math.pow(1 + (a.rate || 0) / 100, 1 / 12) - 1), 0);
    const goals = sav.filter((a) => a.target);
    return `
      <div class="card"><div class="kpis">
        <div class="kpi"><div class="t">Toplam birikim</div><div class="v num">${money(total)}</div></div>
        <div class="kpi"><div class="t">Tahmini aylık faiz</div><div class="v num up">${money(monthly, { sign: true })}</div></div>
        ${goals.length ? `<div class="kpi" style="grid-column:span 2"><div class="t">Hedeflere ilerleme</div><div class="v num">${money(goals.reduce((s, a) => s + a.value, 0))} <span class="tiny">/ ${money(goals.reduce((s, a) => s + a.target, 0))}</span></div></div>` : ''}
      </div></div>
      ${listCard('Birikimler', sav, 'savings')}`;
  }
  const value = inv.reduce((s, a) => s + a.value, 0), cost = inv.reduce((s, a) => s + (a.cost || 0), 0), pl = value - cost;
  return `
    <div class="card"><div class="kpis">
      <div class="kpi"><div class="t">Güncel değer</div><div class="v num">${money(value)}</div></div>
      <div class="kpi"><div class="t">Maliyet</div><div class="v num">${money(cost)}</div></div>
      <div class="kpi" style="grid-column:span 2"><div class="t">Toplam kâr / zarar</div><div class="v num ${pl >= 0 ? 'up' : 'down'}">${money(pl, { sign: true })} <span class="pl">(${cost ? pct((pl / cost) * 100) : '—'})</span></div></div>
    </div></div>
    ${listCard('Yatırımlar', inv, 'investment')}`;
}

/* ====================================================================== */
/*  SİMÜLASYON                                                             */
/* ====================================================================== */
function simP() { if (!S().sim) { S().sim = simDefaults(); Store.save(); } return S().sim; }
function viewSim() {
  const p = simP();
  const hz = [...(S().simHorizons || [12])].sort((a, b) => a - b);
  if (!hz.includes(p.horizon)) p.horizon = hz[0] || 12;
  const H = hz.map((m) => [m, horizonLabel(m)]);
  return `
  <header class="hero compact">
    <div class="hero-top"><div><h1>Gelecek Simülasyonu</h1><div class="sub">Maaşına ve giderlerine göre önümüzdeki dönem</div></div>
      <button class="glass-btn" data-action="simSettings" aria-label="Simülasyon ayarları">${icon('settings')}</button></div>
    <div class="chip-row" style="margin-top:16px">${H.map(([v, l]) => `<button class="chip-glass" style="font-weight:600;${p.horizon === v ? 'background:#fff;color:var(--navy-900)' : ''}" data-action="simH" data-v="${v}">${l}</button>`).join('')}</div>
  </header>
  <div class="content stagger" style="margin-top:14px">
    <div class="card" id="simres"></div>
    <div class="card">
      <div class="card-h"><h3>Gelir</h3><button class="link" data-action="simFill">${icon('sparkle')} Verilerimden doldur</button></div>
      <div style="display:flex;flex-direction:column;gap:12px">
        ${seg([['fixed', 'Sabit maaş'], ['hourly', 'Saatlik (part-time)']], p.incomeMode || 'fixed', 'simIncomeMode', 'light')}
        ${p.incomeMode === 'hourly'
          ? `<div class="two">${simField('Saat ücreti', 'hourly', '₺', p.hourly)}${simField('Günde kaç saat', 'hoursPerDay', 'sa', p.hoursPerDay)}</div>
             <div class="two">${simField('Haftada kaç gün', 'daysPerWeek', 'gün', p.daysPerWeek)}${simField('Ek gelir (aylık)', 'extraIncome', '₺', p.extraIncome)}</div>
             <div class="live-box" id="incCalc">${hourlyText(p)}</div>`
          : `<div class="two">${simField('Aylık net maaş', 'salary', '₺', p.salary)}${simField('Ek gelir (aylık)', 'extraIncome', '₺', p.extraIncome)}</div>`}
        <div class="two"><div class="field"><label>Zam (her zamda)</label><div class="raise-row">${seg([['pct', '%'], ['amount', '₺']], p.raiseType || 'pct', 'simRaiseType', 'light mini')}
            <div class="input-unit"><input class="inp num" inputmode="decimal" data-sim="${p.raiseType === 'amount' ? 'raiseAmt' : 'raisePct'}" value="${numInput(p.raiseType === 'amount' ? p.raiseAmt : p.raisePct)}" placeholder="0"><em>${p.raiseType === 'amount' ? (p.incomeMode === 'hourly' ? '₺/sa' : '₺') : '%'}</em></div></div></div>
          <div class="field"><label>Zam dönemi</label><select class="inp" data-sim="raiseMode">
            ${[['jan_jul', 'Ocak + Temmuz'], ['jan', 'Yılda bir (Ocak)'], ['none', 'Zam yok']].map(([v, l]) => `<option value="${v}" ${p.raiseMode === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Aylık Giderler</h3><span class="tiny num" id="exptotal">${money(p.expenses.reduce((s, e) => s + (+e.amount || 0), 0), { mask: false })}</span></div>
      <div style="display:flex;flex-direction:column;gap:8px" id="explist">${p.expenses.map(expRow).join('')}</div>
      <button class="btn ghost sm" style="margin-top:10px;width:100%" data-action="simAddExp">${icon('plus')} Gider kalemi ekle</button>
      <div style="margin-top:12px">${simField('Yıllık enflasyon (giderler bu oranda artar)', 'inflation', '%', p.inflation)}</div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Birikim & Yatırım Varsayımları</h3></div>
      <div style="display:flex;flex-direction:column;gap:12px">
        ${seg([['pct', 'Artanın yüzdesi'], ['amount', 'Sabit tutar']], p.investMode || 'pct', 'simInvestMode', 'light')}
        ${p.investMode === 'amount'
          ? `${simField('Her ay yatırıma ayır', 'investAmt', '₺', p.investAmt)}<div class="tiny" style="margin-top:-6px">Artan para bu tutardan azsa artanın tamamı yatırıma gider; geri kalan birikimde (mevduatta) kalır.</div>`
          : `<div class="field"><label>Artan paranın yatırıma giden kısmı: <b id="ratioLbl">${pct(p.investRatio, 0)}</b></label>
          <input type="range" class="range" min="0" max="100" step="5" value="${p.investRatio}" data-sim="investRatio"></div>`}
        <div class="two">${simField('Mevduat faizi (yıllık)', 'depositRate', '%', p.depositRate)}${simField('Yatırım getirisi (yıllık)', 'investReturn', '%', p.investReturn)}</div>
        <div class="opt-row" style="padding:4px 0"><div class="l"><b>Başlangıcı verilerimden al</b><span>Hesap + birikim + yatırım toplamın</span></div>${sw('data-sim="autoStart"', p.autoStart)}</div>
        <div class="two" id="startFields" style="${p.autoStart ? 'display:none' : ''}">${simField('Başlangıç nakit', 'startCash', '₺', p.startCash)}${simField('Başlangıç yatırım', 'startInv', '₺', p.startInv)}</div>
      </div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Tek Seferlik Olaylar</h3><button class="link" data-action="simAddEvent">${icon('plus')} Ekle</button></div>
      <div class="tiny" style="margin:-4px 0 10px">İkramiye (+), araba/tatil gibi büyük harcamalar (−)</div>
      <div style="display:flex;flex-direction:column;gap:8px" id="evlist">${p.events.map(evRow).join('') || '<div class="tiny">Olay eklenmedi</div>'}</div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Borç Kapanışı</h3>${Calc.debtTotal() ? `<button class="link" data-action="debtSimFill">${icon('sparkle')} Borçlarımdan al</button>` : ''}</div>
      <div class="tiny" style="margin:-4px 0 10px">Borcunu her ay ne kadar ödersen kaç ayda bitireceğini hesaplar.</div>
      <div class="two">${dsimField('Borç tutarı', 'amount', '₺', debtSimP().amount)}${dsimField('Aylık faiz', 'rate', '%', debtSimP().rate)}</div>
      <div style="margin-top:10px">${dsimField('Her ay ödeyeceğin', 'pay', '₺', debtSimP().pay)}</div>
      <div id="debtres" style="margin-top:12px"></div>
    </div>
    <div class="card">
      <button class="coll-h ${UI.simTable ? 'open' : ''}" data-action="simTable"><h3 style="margin:0;font-size:15px">Dönem Tablosu</h3>${icon('chevD')}</button>
      <div class="collapse ${UI.simTable ? 'open' : ''}"><div id="simtable"></div></div>
    </div>
    <button class="btn ghost" data-action="simReset">${icon('refresh')} Varsayılanlara dön</button>
  </div>`;
}
function simField(label, key, unit, val) {
  return `<div class="field"><label>${label}</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-sim="${key}" value="${numInput(val)}"><em>${unit}</em></div></div>`;
}
function expRow(e) {
  return `<div class="exp-row" data-exp="${e.id}"><input class="inp" value="${esc(e.name)}" data-expf="name" placeholder="Kalem"><input class="inp num" inputmode="decimal" value="${numInput(e.amount)}" data-expf="amount" placeholder="Tutar"><button class="icon-sq" data-action="simDelExp" data-id="${e.id}">${icon('minus')}</button></div>`;
}
function evRow(e) {
  const maxM = Math.max(120, ...(S().simHorizons || []));
  const opts = []; for (let i = 1; i <= maxM; i++) { const ym = ymAdd(ymNow(), i); opts.push(`<option value="${ym}" ${e.ym === ym ? 'selected' : ''}>${ymLabel(ym, true)}</option>`); }
  return `<div class="exp-row" data-ev="${e.id}" style="grid-template-columns:1fr 92px 96px 34px"><input class="inp" value="${esc(e.label)}" data-evf="label" placeholder="Açıklama"><select class="inp" data-evf="ym" style="padding:10px 6px">${opts.join('')}</select><input class="inp num" inputmode="decimal" value="${numInput(e.amount)}" data-evf="amount" placeholder="±Tutar"><button class="icon-sq" data-action="simDelEv" data-id="${e.id}">${icon('minus')}</button></div>`;
}
function renderSimResults(animate = true) {
  const p = simP(); const r = runSim(p);
  const box = $('#simres'); if (!box) return;
  const growth = r.end - r.start;
  box.innerHTML = `
    <div class="tiny">${ymLabel(r.rows[r.rows.length - 1].ym)} sonunda tahmini toplam varlık</div>
    <div class="sim-hero-v num">${money(r.end, { mask: false })}</div>
    <div class="tiny" style="margin-top:2px">Bugünün parasıyla: <b class="num" style="color:var(--text)">${money(r.endReal, { mask: false })}</b> · Değişim <b class="num ${growth >= 0 ? 'up' : 'down'}">${money(growth, { mask: false, sign: true, short: true })}</b></div>
    ${r.negMonth ? `<div class="warn-box" style="margin-top:12px">${icon('info')} ${ymLabel(r.negMonth)} itibarıyla varlıkların eksiye düşüyor.</div>` : ''}
    <div id="simchart" style="margin:22px 0 4px"></div>
    <div class="legend-key"><span><i style="background:var(--blue)"></i>Toplam</span><span><i style="background:#f5a524"></i>Yatırım</span><span><i style="background:#10b77f"></i>Nakit/Birikim</span><span><i style="background:#93a1b8"></i>Reel</span></div>
    <div class="kpis" style="margin-top:14px">
      <div class="kpi"><div class="t">Toplam gelir</div><div class="v num">${compact(r.totIn)}</div></div>
      <div class="kpi"><div class="t">Toplam gider</div><div class="v num">${compact(r.totOut)}</div></div>
      <div class="kpi"><div class="t">Faiz + getiri</div><div class="v num up">${compact(r.totInterest + r.totReturn)}</div></div>
      <div class="kpi"><div class="t">Ort. tasarruf oranı</div><div class="v num ${r.avgSave >= 0 ? '' : 'down'}">${pct(r.avgSave, 0)}</div></div>
    </div>`;
  const step = r.rows.length > 36 ? 3 : 1;
  const rows = r.rows.filter((_, i) => i % step === 0 || i === r.rows.length - 1);
  Charts.line($('#simchart'), {
    labels: rows.map((x) => ymLabel(x.ym, true)),
    series: [
      { name: 'Toplam', color: '#1f6bff', values: rows.map((x) => x.total), area: true, width: 2.8 },
      { name: 'Yatırım', color: '#f5a524', values: rows.map((x) => x.inv), width: 2 },
      { name: 'Nakit', color: '#10b77f', values: rows.map((x) => x.cash), width: 2 },
      { name: 'Reel', color: '#93a1b8', values: rows.map((x) => x.real), width: 1.6, dash: true },
    ],
  });
  if (!animate) $$('#simchart .line-path, #simchart .area').forEach((el) => (el.style.animationDuration = '0s'));
  // Tablo
  let trs;
  if (r.rows.length <= 24) {
    trs = r.rows.map((x) => `<tr><td>${ymLabel(x.ym, true)}</td><td>${compact(x.income)}</td><td>${compact(x.expense)}</td><td class="${x.surplus >= 0 ? 'up' : 'down'}">${compact(x.surplus)}</td><td>${compact(x.total)}</td></tr>`);
  } else {
    const ys = {};
    for (const x of r.rows) { const y = x.ym.slice(0, 4); ys[y] = ys[y] || { income: 0, expense: 0, surplus: 0, total: 0 }; ys[y].income += x.income; ys[y].expense += x.expense; ys[y].surplus += x.surplus; ys[y].total = x.total; }
    trs = Object.entries(ys).map(([y, x]) => `<tr><td>${y}</td><td>${compact(x.income)}</td><td>${compact(x.expense)}</td><td class="${x.surplus >= 0 ? 'up' : 'down'}">${compact(x.surplus)}</td><td>${compact(x.total)}</td></tr>`);
  }
  $('#simtable').innerHTML = `<table class="table num" style="margin-top:12px"><tr><th>${r.rows.length <= 24 ? 'Ay' : 'Yıl'}</th><th>Gelir</th><th>Gider</th><th>Artan</th><th>Varlık</th></tr>${trs.join('')}</table>`;
}
let simT, dsimT;
function simChanged() {
  const p = simP();
  const ic = $('#incCalc'); if (ic) ic.innerHTML = hourlyText(p);
  const et = $('#exptotal'); if (et) et.textContent = money(p.expenses.reduce((s, e) => s + (+e.amount || 0), 0), { mask: false });
  Store.save(); clearTimeout(simT); simT = setTimeout(() => renderSimResults(false), 140);
}

/* ---------- Görünüm tabloları ---------- */
const VIEWS = { home: viewHome, tx: viewTx, assets: viewAssets, sim: viewSim };
const BODIES = { tx: txBody, assets: assetsBody };
const AFTER = {
  sim: () => { renderSimResults(true); renderDebtSim(); },
  assets: () => { if (UI.assetMode !== 'investment') return; if (UI.invMode === 'ipo') { Prices.ipoList().then(() => { const p = $('[data-f=ipoload]'); if (p && UI.tab === 'assets') refreshBody(); }).catch(() => { const p = $('[data-f=ipoload]'); if (p) p.innerHTML = `<div>Takvim alınamadı${Native.isNative() ? '' : ' (tarayıcı engelliyor, telefonda çalışır)'}</div>`; }); return; } Prices.refreshMarket().then((ch) => { if (ch && UI.tab === 'assets' && UI.assetMode === 'investment') refreshBody(); }); },
};

/* ====================================================================== */
/*  ALT SAYFALAR (bottom sheets)                                           */
/* ====================================================================== */
const sheets = [];
function openSheet({ title, body, mount, replace = false }) {
  if (replace && sheets.length) sheets[sheets.length - 1].close(true);
  const app = $('#app');
  const bd = document.createElement('div'); bd.className = 'backdrop';
  const sh = document.createElement('div'); sh.className = 'sheet';
  sh.innerHTML = `<div class="sheet-head"><div class="grab"></div><div class="sheet-title"><h2>${title}</h2><button class="x-btn" data-close aria-label="Kapat">${icon('x')}</button></div></div><div class="sheet-body">${body}</div>`;
  app.append(bd, sh);
  let closed = false;
  const api = {
    el: sh,
    close(fromPop) {
      if (closed) return; closed = true;
      const i = sheets.indexOf(api); if (i > -1) sheets.splice(i, 1);
      bd.classList.add('out');
      sh.style.animation = 'none'; sh.style.transition = 'transform .3s cubic-bezier(.22,.9,.24,1)';
      requestAnimationFrame(() => (sh.style.transform = 'translateY(105%)'));
      setTimeout(() => { bd.remove(); sh.remove(); }, 320);
      if (!fromPop) releaseGuard();
    },
  };
  sheets.push(api); ensureGuard();
  bd.addEventListener('click', () => api.close());
  sh.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) api.close(); });
  // Aşağı kaydırarak kapatma
  const head = $('.sheet-head', sh); let y0 = null, dy = 0;
  head.addEventListener('pointerdown', (e) => { if (e.target.closest('button')) return; y0 = e.clientY; dy = 0; sh.style.animation = 'none'; sh.style.transition = 'none'; head.setPointerCapture(e.pointerId); });
  head.addEventListener('pointermove', (e) => { if (y0 === null) return; dy = Math.max(0, e.clientY - y0); sh.style.transform = `translateY(${dy}px)`; });
  const end = () => { if (y0 === null) return; y0 = null; if (dy > 90) api.close(); else { sh.style.transition = 'transform .35s cubic-bezier(.34,1.4,.5,1)'; sh.style.transform = ''; } };
  head.addEventListener('pointerup', end); head.addEventListener('pointercancel', end);
  mount && mount(sh, api);
  return api;
}
function confirmSheet(msg, ok = 'Sil', danger = true) {
  return new Promise((res) => {
    let done = false;
    const s = openSheet({
      title: 'Emin misin?',
      body: `<div class="muted" style="font-size:14.5px;line-height:1.5">${msg}</div><div class="btn-row"><button class="btn ghost" data-c="0">Vazgeç</button><button class="btn ${danger ? 'danger' : ''}" data-c="1">${ok}</button></div>`,
      mount(el, api) { el.addEventListener('click', (e) => { const b = e.target.closest('[data-c]'); if (b) { done = true; res(b.dataset.c === '1'); api.close(); } }); },
    });
    const oc = s.close; s.close = (f) => { if (!done) { done = true; res(false); } oc(f); };
  });
}

/* ---------- Hareket ekle / düzenle ---------- */
function catGrid(type, active) {
  return visibleCats(type).map((c) => `<button class="cat-opt ${c.id === active ? 'on' : ''}" style="--c:${c.color}" data-s="cat" data-v="${c.id}"><span class="avatar" style="--c:${c.color}">${icon(c.icon)}</span>${c.name}</button>`).join('');
}
function openTxSheet(t = null, preset = {}) {
  const edit = !!t;
  let type = t ? t.type : preset.type || 'out';
  let cat = t ? t.cat : type === 'out' ? 'market' : 'salary';
  openSheet({
    title: edit ? 'Hareketi Düzenle' : 'Yeni Hareket',
    body: `
      ${seg([['out', 'Gider'], ['in', 'Gelir']], type, '', 'light inout')}
      <div class="amount-inp ${type}"><span>₺</span><input class="num" inputmode="decimal" placeholder="0" data-f="amount" value="${t ? numInput(t.amount) : ''}"></div>
      <div class="cat-grid" data-f="cats">${catGrid(type, cat)}</div>
      <div class="two">
        <div class="field"><label>Tarih</label><input type="date" class="inp" data-f="date" value="${t ? t.date : todayISO()}"></div>
        <div class="field"><label>Açıklama</label><input class="inp" data-f="note" placeholder="Örn. Migros" value="${t ? esc(t.note) : ''}"></div>
      </div>
      <button class="btn" data-s="save">${icon('check')} ${edit ? 'Kaydet' : 'Ekle'}</button>
      ${edit ? `<button class="btn danger" data-s="del">${icon('trash')} Sil</button>` : ''}
      ${t && (t.src === 'sms' || t.src === 'notif') ? `<button class="btn ghost" data-s="ad">${icon('flag')} Bu bir kampanya / reklamdı</button><div class="tiny" style="text-align:center">Bu hareket bir ${t.src === 'sms' ? 'SMS' : 'banka bildirimi'}'nden otomatik oluşturuldu. Kampanya diye işaretlersen silinir ve benzerleri bir daha eklenmez.</div>` : ''}`,
    mount(el, api) {
      const amt = $('[data-f=amount]', el);
      if (!edit) setTimeout(() => amt.focus(), 420);
      el.addEventListener('click', async (e) => {
        const segb = e.target.closest('.seg button');
        if (segb) {
          segSet(segb); type = segb.dataset.v; cat = type === 'out' ? 'market' : 'salary';
          $('.amount-inp', el).className = 'amount-inp ' + type;
          const g = $('[data-f=cats]', el); g.innerHTML = catGrid(type, cat); g.classList.remove('fade-in'); void g.offsetWidth; g.classList.add('fade-in');
          return;
        }
        const b = e.target.closest('[data-s]'); if (!b) return;
        if (b.dataset.s === 'cat') { cat = b.dataset.v; $$('.cat-opt', el).forEach((x) => x.classList.toggle('on', x === b)); }
        if (b.dataset.s === 'save') {
          const amount = parseNum(amt.value);
          if (!(amount > 0)) { amt.focus(); toast('Tutar gir'); return; }
          const data = { type, amount, cat, date: $('[data-f=date]', el).value || todayISO(), note: $('[data-f=note]', el).value.trim() };
          if (edit) Object.assign(t, data); else S().tx.push({ id: uid(), src: 'manual', ...data });
          Store.save(); api.close(); refresh(); toast(edit ? 'Güncellendi' : 'Hareket eklendi');
        }
        if (b.dataset.s === 'ad') { learnAd(t.body); S().tx = S().tx.filter((x) => x.id !== t.id); Store.save(); api.close(); refresh(); toast(t.body ? 'Kampanya olarak öğrenildi' : 'Silindi', { icon: 'flag' }); return; }
        if (b.dataset.s === 'del') {
          if (await confirmSheet('Bu hareket kalıcı olarak silinecek.')) {
            S().tx = S().tx.filter((x) => x.id !== t.id); Store.save(); api.close(); refresh(); toast('Silindi');
          }
        }
      });
    },
  });
}

/* ---------- SMS ---------- */
const SAMPLE_SMS = `ISBANK: 4512 ile biten kartinizla 14.11.2026 tarihinde MIGROS TICARET adli isyerinden 1.245,90 TL harcama yapilmistir. Kullanilabilir limitiniz 38.540,10 TL.

Hesabiniza 15.11.2026 tarihinde FAST ile 52.000,00 TL gelmistir. Gonderen: ABC TEKNOLOJI AS. Aciklama: KASIM MAAS

GARANTI BBVA: Kartinizdan 15/11/2026 tarihinde 189,99 TL tutarinda NETFLIX.COM islemi yapilmistir.

Hesabinizdan 16.11.2026 tarihinde 2.500,00 TL EFT gonderilmistir. Alici: AYSE YILMAZ

Dogrulama kodunuz: 482913. Bu kodu kimseyle paylasmayiniz.`;

function catOptions(type, active) { return [...visibleCats(type), ...(visibleCats(type).some((c) => c.id === active) ? [] : [catById(active)])].map((c) => `<option value="${c.id}" ${c.id === active ? 'selected' : ''}>${c.name}</option>`).join(''); }
function parsedCard(r, i) {
  if (!r.ok) return `<div class="parsed bad off"><div class="top"><span class="avatar" style="--c:#94a3b8">${icon('x')}</span><div class="mid"><b style="font-size:13.5px">Atlandı</b><div class="tiny">${r.reason}</div></div></div><div class="src">${esc(r.body)}</div></div>`;
  const dup = !!r.possibleDup;
  const srcLbl = r.src === 'notif' ? `Bildirim${r.sender ? ' · ' + esc(r.sender) : ''}` : r.src === 'sms' ? `SMS${r.sender ? ' · ' + esc(r.sender) : ''}` : '';
  return `<div class="parsed ${dup ? 'off' : ''}" data-i="${i}">
    <div class="top"><span class="avatar" style="--c:${r.type === 'in' ? '#10b77f' : '#ef4c5a'}" data-av>${icon(r.type === 'in' ? 'in' : 'out')}</span>
      <div style="flex:1;min-width:0"><b style="font-size:14px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(r.note)}</b>
      ${dup ? '<span class="conf lo">Benzer kayıt var</span>' : `<span class="conf ${r.confidence >= 0.6 ? 'hi' : 'lo'}">${r.confidence >= 0.6 ? 'Yüksek güven' : 'Kontrol et'}</span>`}
      ${srcLbl ? `<span class="tiny" style="margin-left:6px">${srcLbl}</span>` : ''}</div>
      <button class="ad-btn" data-ad title="Kampanya / reklam">${icon('flag')}</button>${sw('data-pf="on"', !dup)}</div>
    <div class="mini">
      <select class="inp" data-pf="type" style="flex:0 0 92px"><option value="out" ${r.type === 'out' ? 'selected' : ''}>Gider</option><option value="in" ${r.type === 'in' ? 'selected' : ''}>Gelir</option></select>
      <input class="inp num" data-pf="amount" inputmode="decimal" value="${numInput(r.amount)}" style="flex:1;min-width:0">
    </div>
    <div class="mini"><select class="inp" data-pf="cat" style="flex:1;min-width:0">${catOptions(r.type, r.cat)}</select><input type="date" class="inp" data-pf="date" value="${r.date}" style="flex:0 0 140px"></div>
    <div class="src">${esc(r.body)}</div></div>`;
}
function bindParsed(container, results) {
  container.addEventListener('click', (e) => {
    const b = e.target.closest('[data-ad]'); if (!b) return;
    const card = b.closest('.parsed[data-i]'); const r = results[+card.dataset.i];
    learnAd(r.body); card.style.transition = 'opacity .3s, transform .3s'; card.style.opacity = 0; card.style.transform = 'translateX(30px)'; setTimeout(() => card.remove(), 300);
    toast('Kampanya olarak öğrenildi — benzerleri artık eklenmeyecek', { icon: 'flag' });
  });
  container.addEventListener('change', (e) => {
    const card = e.target.closest('.parsed[data-i]'); if (!card) return;
    if (e.target.dataset.pf === 'on') card.classList.toggle('off', !e.target.checked);
    if (e.target.dataset.pf === 'type') { $('[data-pf=cat]', card).innerHTML = catOptions(e.target.value, e.target.value === 'in' ? 'otherIn' : 'otherOut'); }
  });
  return () => $$('.parsed[data-i]', container).map((card) => {
    const r = results[+card.dataset.i];
    if (!$('[data-pf=on]', card).checked) return { r, skip: true };
    return { r, tx: { id: uid(), src: r.src || 'sms', hash: r.hash, ts: r.ts || 0, body: r.body, note: r.note, type: $('[data-pf=type]', card).value, amount: parseNum($('[data-pf=amount]', card).value), cat: $('[data-pf=cat]', card).value, date: $('[data-pf=date]', card).value } };
  });
}
function timeAgo(ms) {
  const d = (Date.now() - ms) / 60e3;
  if (d < 1) return 'az önce'; if (d < 60) return `${Math.round(d)} dk önce`; if (d < 1440) return `${Math.round(d / 60)} sa önce`;
  return new Date(ms).toLocaleDateString('tr-TR');
}
function openSmsSheet() {
  const native = Native.isNative(); const s = S().settings;
  openSheet({
    title: 'Banka Hareketleri',
    body: `
      ${native ? `<div class="src-grid">
          <div class="src-card"><span class="avatar" style="--c:#1f6bff">${icon('msg')}</span><div><b>SMS</b><span>${s.lastSmsScan ? timeAgo(s.lastSmsScan) : 'Henüz taranmadı'}</span></div></div>
          <div class="src-card"><span class="avatar" style="--c:#10b77f">${icon('bell')}</span><div><b>Bildirimler</b><span data-f="nacc">…</span></div></div>
        </div>
        <button class="btn" data-s="scan">${icon('sync')} Şimdi tara</button>
        <div class="tiny" style="text-align:center;margin-top:-4px">Aynı harcama hem SMS hem bildirim olarak gelse de bir kez kaydedilir.</div>`
        : `<div class="note-box"><b>Önizleme modu:</b> Telefonda uygulama banka SMS'lerini ve banka uygulaması bildirimlerini kendisi okur; aynı harcama iki kez yazılmaz. Burada denemek için banka mesajlarını aşağı yapıştır (aralarında boş satır bırak).</div>`}
      <div class="section-t">Elle yapıştır</div>
      <div class="field"><textarea class="inp" data-f="txt" placeholder="Banka SMS'ini ya da bildirim metnini buraya yapıştır…"></textarea></div>
      <div class="btn-row"><button class="btn ghost" data-s="sample">${icon('msg')} Örnekler</button><button class="btn ${native ? 'ghost' : ''}" data-s="parse">${icon('sparkle')} Çözümle</button></div>
      <div data-f="res" style="display:flex;flex-direction:column;gap:10px"></div>`,
    mount(el, api) {
      let getVals = null, results = [];
      const res = $('[data-f=res]', el);
      const nacc = $('[data-f=nacc]', el);
      if (nacc && Native.akis()) Native.akis().notifAccess().then((r) => { nacc.innerHTML = r.enabled ? 'Erişim açık' : '<u data-s="perm">İzin ver</u>'; }).catch(() => { nacc.textContent = '—'; });
      el.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-s]'); if (!b) return;
        if (b.dataset.s === 'perm') openPermissions();
        if (b.dataset.s === 'sample') { $('[data-f=txt]', el).value = SAMPLE_SMS; }
        if (b.dataset.s === 'parse') {
          const parts = SMS.splitPasted($('[data-f=txt]', el).value);
          if (!parts.length) { toast('Önce bir mesaj yapıştır', { tone: 'error' }); return; }
          results = parts.map((p) => { const r = SMS.parse(p, { date: Date.now() }); if (r.ok) { r.ts = 0; r.src = 'sms'; r.possibleDup = !!findDuplicate(r); } return r; });
          const okN = results.filter((r) => r.ok).length;
          res.innerHTML = `<div class="section-t">${okN} hareket bulundu</div>${results.map(parsedCard).join('')}${okN ? `<button class="btn green" data-s="addAll">${icon('check')} Seçilenleri ekle</button>` : ''}`;
          res.classList.remove('fade-in'); void res.offsetWidth; res.classList.add('fade-in');
          getVals = bindParsed(res, results);
          setTimeout(() => res.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
        }
        if (b.dataset.s === 'addAll' && getVals) {
          const vals = getVals().filter((v) => !v.skip && v.tx.amount > 0);
          const have = new Set(S().tx.map((t) => t.hash));
          const fresh = vals.filter((v) => !have.has(v.tx.hash));
          S().tx.push(...fresh.map((v) => v.tx)); Store.save(); api.close(); refresh();
          toast(fresh.length ? `${fresh.length} hareket eklendi` : 'Bunlar zaten eklenmiş');
        }
        if (b.dataset.s === 'scan') {
          b.disabled = true;
          const { n, errs } = await scanAllSources({ manual: true });
          api.close(); refresh();
          if (errs.length && !n) toast(errs[0], { tone: 'error', title: 'Tarama' });
          else toast(n ? `${n} yeni hareket bulundu` : 'Yeni banka hareketi yok', { icon: 'sync' });
          if (n && !S().settings.smsAutoApprove) setTimeout(openPendingSheet, 400);
        }
      });
    },
  });
}
function openPendingSheet() {
  const list = S().pending;
  if (!list.length) { toast('Onay bekleyen hareket yok'); return; }
  openSheet({
    title: list.some((p) => p.otherApp) ? 'Gidere ekleyeyim mi?' : 'Onay Bekleyenler',
    body: `<div class="tiny">SMS ve banka bildirimlerinden bulunan hareketleri kontrol et. Kapattıkların eklenmez.</div>
      <div data-f="res" style="display:flex;flex-direction:column;gap:10px">${list.map(parsedCard).join('')}</div>
      <div class="btn-row"><button class="btn danger" data-s="clear">Tümünü yoksay</button><button class="btn green" data-s="ok">${icon('check')} Onayla</button></div>`,
    mount(el, api) {
      const getVals = bindParsed($('[data-f=res]', el), list);
      el.addEventListener('click', (e) => {
        const b = e.target.closest('[data-s]'); if (!b) return;
        if (b.dataset.s === 'ok') { const v = getVals().filter((x) => !x.skip && x.tx.amount > 0); S().tx.push(...v.map((x) => x.tx)); S().pending = []; Store.save(); api.close(); refresh(); toast(`${v.length} hareket eklendi`); }
        if (b.dataset.s === 'clear') { S().pending = []; Store.save(); api.close(); refresh(); toast('Yoksayıldı'); }
      });
    },
  });
}
function typeGrid(kind, active) {
  return ASSET_TYPES[kind].map((t) => `<button class="cat-opt ${t.id === active ? 'on' : ''}" style="--c:${t.color}" data-s="type" data-v="${t.id}"><span class="avatar" style="--c:${t.color}">${icon(t.icon)}</span>${t.name}</button>`).join('');
}
function instrOptions(sel) {
  const groups = [['Altın', (i) => i.type === 'gold'], ['Gümüş & Maden', (i) => i.type === 'silver'], ['Döviz', (i) => i.type === 'fx'], ['Kripto', (i) => i.type === 'crypto'], ['Borsa İstanbul', (i) => i.type === 'stock'], ['Yatırım Fonları (TEFAS)', (i) => i.type === 'fund']];
  return `<option value="">Takip yok — değeri ben gireceğim</option>` + groups.map(([g, f]) => `<optgroup label="${g}">${INSTRUMENTS.filter(f).map((i) => `<option value="${i.id}" ${i.id === sel ? 'selected' : ''}>${i.name}</option>`).join('')}</optgroup>`).join('');
}
function openAssetForm(a = null, kind = 'savings', replace = false, preset = '') {
  const edit = !!a; kind = a ? a.kind : kind;
  let instr = a && a.track ? a.track.id : preset;
  let type = a ? a.type : instrById(instr) ? instrById(instr).type : ASSET_TYPES[kind][0].id;
  let fund = a && a.track && a.track.src === 'tf' ? { c: a.track.sym, n: a.fundName || a.name } : null; let buyPrice = 0;
  const savFields = () => `<div class="cat-grid" data-f="types">${typeGrid('savings', type)}</div>
       <div class="two"><div class="field"><label>Tutar</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="value" value="${a ? numInput(a.value) : ''}"><em>₺</em></div></div>
       <div class="field"><label>Yıllık faiz</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="rate" value="${a ? numInput(a.rate) : ''}" placeholder="0"><em>%</em></div></div></div>
       <div class="field"><label>Hedef tutar (isteğe bağlı)</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="target" value="${a && a.target ? numInput(a.target) : ''}" placeholder="Örn. 100.000"><em>₺</em></div></div>`;
  const invFields = () => {
    const I = instrById(instr);
    const head = `<div class="field"><label>Canlı fiyat takibi</label><select class="inp" data-f="instr">${instrOptions(instr)}</select></div>`;
    if (!I) return head + `<div class="cat-grid" data-f="types">${typeGrid('investment', ASSET_TYPES.investment.some((t) => t.id === type) ? type : 'gold')}</div>
       <div class="two"><div class="field"><label>Miktar</label><input class="inp num" inputmode="decimal" data-f="qty" value="${a && a.qty ? numInput(a.qty) : ''}" placeholder="Örn. 10"></div>
       <div class="field"><label>Birim</label><input class="inp" data-f="unit" value="${a ? esc(a.unit || '') : ''}" placeholder="gr, adet, lot…"></div></div>
       <div class="two"><div class="field"><label>Toplam maliyet</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="cost" value="${a ? numInput(a.cost) : ''}"><em>₺</em></div></div>
       <div class="field"><label>Güncel değer</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="value" value="${a ? numInput(a.value) : ''}" placeholder="= maliyet"><em>₺</em></div></div></div>`;
    if (I.fund) return head + `<div class="field"><label>Fon (kod ya da ad)</label><input class="inp" data-f="fq" placeholder="Örn. TTE, altın, teknoloji…" autocomplete="off" value="${fund ? esc(fund.c + ' — ' + fund.n) : ''}"><div class="fund-res" data-f="fres"></div></div>
       <div class="two"><div class="field"><label>Yatırdığın tutar</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="cost" value="${a && a.cost ? numInput(a.cost) : ''}" placeholder="0"><em>₺</em></div></div>
       <div class="field"><label>Alış tarihi</label><input type="date" class="inp" data-f="bdate" value="${(a && a.buyDate) || todayISO()}"></div></div>
       <div class="field"><label>Pay adedi (biliyorsan)</label><div class="input-unit wide"><input class="inp num" inputmode="decimal" data-f="qty" value="${a && a.qty ? numInput(a.qty) : ''}" placeholder="Otomatik hesaplanır"><em>pay</em></div></div>
       <div class="live-box" data-f="preview">Fon seç</div>`;
    return head + `${I.symbol ? `<div class="field"><label>Hisse kodu</label><input class="inp" data-f="sym" placeholder="Örn. THYAO" value="${a && a.track ? esc(a.track.sym || '') : ''}" style="text-transform:uppercase"></div>` : ''}
       <div class="two"><div class="field"><label>Miktar</label><div class="input-unit wide"><input class="inp num" inputmode="decimal" data-f="qty" value="${a && a.qty ? numInput(a.qty) : ''}" placeholder="0"><em>${I.unit}</em></div></div>
       <div class="field"><label>Toplam maliyet</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="cost" value="${a && a.cost ? numInput(a.cost) : ''}" placeholder="İsteğe bağlı"><em>₺</em></div></div></div>
       <div class="live-box" data-f="preview"><span class="live-dot"></span>Fiyat alınıyor…</div>`;
  };
  openSheet({
    replace,
    title: edit ? 'Varlığı Düzenle' : 'Yeni Varlık',
    body: `
      ${edit ? '' : seg([['savings', 'Birikim'], ['investment', 'Yatırım']], kind, '', 'light')}
      <div class="field"><label>İsim</label><input class="inp" data-f="name" value="${a ? esc(a.name) : ''}" placeholder="İsteğe bağlı"></div>
      <div data-f="fields" style="display:flex;flex-direction:column;gap:14px">${kind === 'savings' ? savFields() : invFields()}</div>
      <button class="btn" data-s="save">${icon('check')} ${edit ? 'Kaydet' : 'Ekle'}</button>`,
    mount(el, api) {
      let unitPrice = 0, pTimer;
      const preview = async () => {
        const box = $('[data-f=preview]', el); const I = instrById(instr); if (!box || !I) return;
        if (I.fund) {
          if (!fund) { box.innerHTML = 'Fon seç'; unitPrice = 0; return; }
          box.innerHTML = '<span class="live-dot"></span>Fon fiyatı alınıyor…';
          try {
            const bd = $('[data-f=bdate]', el).value || todayISO(); const mo = (Date.now() - new Date(bd).getTime()) / (30 * 864e5);
            const per = [1, 3, 6, 12, 36, 60].find((x) => x >= mo + 0.2) || 60;
            const fp = await Prices.fundPrice(fund.c, per); unitPrice = fp.p;
            const hb = fp.history.filter((x) => x.tarih <= bd); buyPrice = (hb[hb.length - 1] || fp.history[0]).fiyat;
            const cost = parseNum($('[data-f=cost]', el).value); const qIn = parseNum($('[data-f=qty]', el).value); const q = qIn || (cost && buyPrice ? cost / buyPrice : 0);
            box.innerHTML = `<span class="live-dot"></span>1 pay = <b>${money(unitPrice, { mask: false })}</b> (${fp.date.split('-').reverse().join('.')})${q ? `<br>Alış fiyatı ${money(buyPrice, { mask: false })} · ≈ ${q.toLocaleString('tr-TR', { maximumFractionDigits: 2 })} pay · Bugünkü değer <b>${money(unitPrice * q, { mask: false })}</b> <span class="${unitPrice >= buyPrice ? 'up' : 'down'}">(${unitPrice >= buyPrice ? '+' : ''}${(((unitPrice - buyPrice) / buyPrice) * 100).toLocaleString('tr-TR', { maximumFractionDigits: 2 })}%)</span>` : ''}`;
          } catch (e) { unitPrice = 0; box.innerHTML = `${icon('info', 'mini-ic')} Fon fiyatı alınamadı${Native.isNative() ? '' : ' (tarayıcı engelliyor, telefonda çalışır)'}`; }
          return;
        }
        const sym = $('[data-f=sym]', el) ? $('[data-f=sym]', el).value.trim().toUpperCase() : '';
        if (I.symbol && !sym) { box.innerHTML = 'Hisse kodunu yaz'; unitPrice = 0; return; }
        try {
          unitPrice = await Prices.quote({ src: I.src, id: I.id, sym });
          const q = parseNum($('[data-f=qty]', el).value);
          box.innerHTML = `<span class="live-dot"></span>1 ${I.unit} = <b>${money(unitPrice, { mask: false })}</b>${q ? ` · Değerin <b>${money(unitPrice * q, { mask: false })}</b>` : ''}`;
        } catch (e) { unitPrice = 0; box.innerHTML = `${icon('info', 'mini-ic')} Fiyat şu an alınamadı${I.src === 'yh' && !Native.isNative() ? ' (tarayıcı engelliyor, telefonda çalışır)' : ''}`; }
      };
      const rerender = () => { const f = $('[data-f=fields]', el); f.innerHTML = kind === 'savings' ? savFields() : invFields(); f.classList.remove('fade-in'); void f.offsetWidth; f.classList.add('fade-in'); preview(); };
      preview();
      el.addEventListener('change', (e) => { if (e.target.dataset.f === 'instr') { instr = e.target.value; const I = instrById(instr); if (I) type = I.type; rerender(); } });
      let fTimer;
      el.addEventListener('input', async (e) => {
        if (e.target.dataset.f !== 'fq') return;
        clearTimeout(fTimer); const q = SMS.norm(e.target.value.trim()); const res = $('[data-f=fres]', el);
        if (q.length < 2) { res.innerHTML = ''; return; }
        fTimer = setTimeout(async () => {
          res.innerHTML = '<div class="tiny">Fonlar yükleniyor…</div>';
          try {
            const L = await Prices.fundList(); const up = q.toUpperCase();
            const hits = L.filter((x) => x.c.startsWith(up)).concat(L.filter((x) => !x.c.startsWith(up) && SMS.norm(x.n).includes(q))).slice(0, 8);
            res.innerHTML = hits.length ? hits.map((x) => `<button class="fund-opt" data-fund="${x.c}"><b>${x.c}</b><span>${esc(x.n)}</span><small>${esc(x.t)}${x.y != null ? ' · 1 yıl %' + Number(x.y).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : ''}</small></button>`).join('') : '<div class="tiny">Fon bulunamadı</div>';
          } catch (err) { res.innerHTML = `<div class="tiny">Fon listesi alınamadı${Native.isNative() ? '' : ' (tarayıcı engelliyor, telefonda çalışır)'}</div>`; }
        }, 250);
      });
      el.addEventListener('click', (e) => {
        const fo = e.target.closest('[data-fund]'); if (!fo) return;
        const L = S().fundList || []; const x = L.find((y) => y.c === fo.dataset.fund); fund = { c: fo.dataset.fund, n: x ? x.n : fo.dataset.fund };
        $('[data-f=fq]', el).value = fund.c + ' — ' + fund.n; $('[data-f=fres]', el).innerHTML = ''; preview();
      });
      el.addEventListener('change', (e) => { if (e.target.dataset.f === 'bdate') preview(); });
      el.addEventListener('input', (e) => { if (e.target.dataset.f === 'qty' || e.target.dataset.f === 'sym' || (e.target.dataset.f === 'cost' && fund)) { clearTimeout(pTimer); pTimer = setTimeout(preview, e.target.dataset.f === 'sym' ? 600 : 150); } });
      el.addEventListener('click', (e) => {
        const segb = e.target.closest('.seg button');
        if (segb) { segSet(segb); kind = segb.dataset.v; type = ASSET_TYPES[kind][0].id; instr = ''; rerender(); return; }
        const b = e.target.closest('[data-s]'); if (!b) return;
        if (b.dataset.s === 'type') { type = b.dataset.v; $$('.cat-opt', el).forEach((x) => x.classList.toggle('on', x === b)); }
        if (b.dataset.s === 'save') {
          const g = (k) => { const x = $(`[data-f=${k}]`, el); return x ? x.value : ''; };
          const I = kind === 'investment' ? instrById(instr) : null;
          let d;
          if (kind === 'savings') d = { kind, type, value: parseNum(g('value')), rate: parseNum(g('rate')), target: parseNum(g('target')), track: null };
          else if (I && I.fund) {
            if (!fund) { toast('Bir fon seç', { tone: 'error' }); return; }
            const cost = parseNum(g('cost')); const qty = parseNum(g('qty')) || (cost && buyPrice ? cost / buyPrice : 0);
            if (!(qty > 0)) { toast('Yatırdığın tutarı gir', { tone: 'error' }); return; }
            const val = unitPrice ? Math.round(unitPrice * qty * 100) / 100 : cost;
            d = { kind, type: 'fund', qty: Math.round(qty * 10000) / 10000, unit: 'pay', track: { src: 'tf', id: 'FUND', sym: fund.c }, cost: cost || val, value: val, buyDate: g('bdate'), fundName: fund.n };
            if (unitPrice) S().prices[priceKey(d.track)] = { p: unitPrice, t: Date.now() };
          } else if (I) {
            const qty = parseNum(g('qty')); const sym = g('sym').trim().toUpperCase();
            if (!(qty > 0)) { toast('Miktarı gir', { tone: 'error' }); return; }
            if (I.symbol && !sym) { toast('Hisse kodunu gir', { tone: 'error' }); return; }
            const val = unitPrice ? Math.round(unitPrice * qty * 100) / 100 : (a && a.value) || parseNum(g('cost'));
            d = { kind, type: I.type, qty, unit: I.unit, track: { src: I.src, id: I.id, sym }, cost: parseNum(g('cost')) || val, value: val };
            if (unitPrice) S().prices[priceKey(d.track)] = { p: unitPrice, t: Date.now() };
          } else {
            const cost = parseNum(g('cost'));
            d = { kind, type, qty: parseNum(g('qty')), unit: g('unit').trim(), cost, value: g('value').trim() ? parseNum(g('value')) : cost, track: null };
          }
          d.name = g('name').trim() || (I && I.fund ? fund.c + ' · ' + fund.n.split(' ').slice(0, 4).join(' ') : I ? I.name + (I.symbol ? ' ' + d.track.sym : '') : assetTypeById(d.type).name);
          if (!(d.value > 0) && !(d.cost > 0)) { toast('Tutar gir', { tone: 'error' }); return; }
          if (edit) Object.assign(a, d);
          else S().assets.push({ id: uid(), history: [{ id: uid(), amount: d.kind === 'savings' ? d.value : d.cost || d.value, note: 'Açılış', date: todayISO() }], ...d });
          Store.save(); api.close(); refresh(); Prices.syncNative(); toast(edit ? 'Güncellendi' : 'Varlık eklendi');
        }
      });
    },
  });
}
function openAssetDetail(a, replace = false) {
  const t = assetTypeById(a.type); const isInv = a.kind === 'investment';
  const pl = (a.value || 0) - (a.cost || 0);
  const hist = [...(a.history || [])].sort((x, y) => y.date.localeCompare(x.date));
  const I = a.track ? instrById(a.track.id) : null;
  const pr = a.track ? S().prices[priceKey(a.track)] : null;
  const al = a.alert || {};
  const alertTxt = al.below || al.above
    ? `${al.below ? `▼ ${money(al.below, { mask: false })}` : ''}${al.below && al.above ? ' · ' : ''}${al.above ? `▲ ${money(al.above, { mask: false })}` : ''} <span class="tiny">(${al.basis === 'total' ? 'toplam değer' : 'birim fiyat'})</span>`
    : 'Kurulu alarm yok';
  openSheet({
    replace,
    title: esc(a.name),
    body: `
      <div style="display:flex;align-items:center;gap:14px">
        <span class="avatar" style="--c:${t.color};width:52px;height:52px;border-radius:17px">${icon(t.icon)}</span>
        <div><div class="tiny">${I ? `<span class="live-dot"></span>${I.name}` : t.name}${isInv && a.qty ? ` · ${Number(a.qty).toLocaleString('tr-TR', { maximumFractionDigits: 4 })} ${esc(a.unit || '')}` : ''}</div>
        <div style="font-size:26px;font-weight:800" class="num">${money(a.value)}</div>
        ${pr ? `<div class="tiny">1 ${esc(a.unit)} = ${money(pr.p, { mask: false })} · ${timeAgo(pr.t)}</div>` : ''}</div></div>
      <div class="kpis">
        ${isInv ? `<div class="kpi"><div class="t">Maliyet</div><div class="v num">${money(a.cost)}</div></div>
          <div class="kpi"><div class="t">Kâr / Zarar</div><div class="v num ${pl >= 0 ? 'up' : 'down'}">${money(pl, { sign: true })}</div><div class="d ${pl >= 0 ? 'up' : 'down'}">${a.cost ? pct((pl / a.cost) * 100) : ''}</div></div>`
        : `<div class="kpi"><div class="t">Yıllık faiz</div><div class="v num">${a.rate ? pct(a.rate) : '—'}</div></div>
          <div class="kpi"><div class="t">Aylık getiri (tahmini)</div><div class="v num up">${money(a.value * (Math.pow(1 + (a.rate || 0) / 100, 1 / 12) - 1), { sign: true })}</div></div>
          ${a.target ? `<div class="kpi" style="grid-column:span 2"><div class="t">Hedef: ${money(a.target)}</div><div class="track" style="margin-top:8px"><i style="width:${Math.min(100, (a.value / a.target) * 100)}%;background:${t.color}"></i></div><div class="d muted">${pct(Math.min(100, (a.value / a.target) * 100), 0)} tamamlandı · Kalan ${money(Math.max(0, a.target - a.value))}</div></div>` : ''}`}
      </div>
      ${a.track && a.track.src === 'tf' ? '<div data-f="infl" class="infl"><div class="tiny">Enflasyon karşılaştırması yükleniyor…</div></div>' : ''}
      ${isInv ? (a.track ? `<button class="alert-row" data-s="alert"><span class="avatar" style="--c:#f5a524">${icon('bell')}</span><div class="mid"><b>Stop & Alarm</b><span>${alertTxt}</span></div>${icon('chevR')}</button>`
        : `<div class="tiny" style="text-align:center">Canlı fiyat takibini açarsan (Düzenle) stop/alarm kurabilirsin.</div>`) : ''}
      <div class="btn-row ${isInv && !a.track ? 'three' : ''}">
        <button class="btn green sm" data-s="dep">${icon('plus')} ${isInv ? 'Alım' : 'Para Ekle'}</button>
        <button class="btn danger sm" data-s="wd">${icon('minus')} ${isInv ? 'Satış' : 'Para Çek'}</button>
        ${isInv && !a.track ? `<button class="btn sm" data-s="upd">${icon('refresh')} Değer</button>` : ''}
      </div>
      <div class="section-t">Geçmiş</div>
      <div class="rows">${hist.length ? hist.map((h) => `<div class="row" style="padding:8px 2px"><div class="mid"><div class="ttl" style="font-size:13.5px">${esc(h.note)}</div><div class="meta">${dayLabel(h.date)}</div></div><div class="amt num ${h.amount >= 0 ? 'in' : ''}" style="font-size:13.5px">${money(h.amount, { sign: true })}</div></div>`).join('') : '<div class="tiny">Kayıt yok</div>'}</div>
      <div class="btn-row"><button class="btn ghost" data-s="edit">${icon('edit')} Düzenle</button><button class="btn danger" data-s="del">${icon('trash')} Sil</button></div>`,
    mount(el, api) {
      if (a.track && a.track.src === 'tf') fundInflation($('[data-f=infl]', el), a);
      el.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-s]'); if (!b) return;
        const k = b.dataset.s;
        if (k === 'edit') openAssetForm(a, a.kind, true);
        if (k === 'alert') openAlertSheet(a);
        if (k === 'dep' || k === 'wd' || k === 'upd') openMoveSheet(a, k);
        if (k === 'del' && (await confirmSheet(`<b>${esc(a.name)}</b> ve geçmişi silinecek.`))) {
          S().assets = S().assets.filter((x) => x.id !== a.id); Store.save(); api.close(); refresh(); Prices.syncNative(); toast('Silindi');
        }
      });
    },
  });
}
function openAlertSheet(a) {
  const al = { basis: 'unit', below: 0, above: 0, ...(a.alert || {}) };
  const cur = () => (al.basis === 'total' ? a.value : Prices.unitPrice(a));
  const chips = (dir) => (dir === 'below' ? [-5, -10, -20] : [5, 10, 20]).map((p) => `<button class="chip" data-pc="${p}" data-dir="${dir}">${p > 0 ? '+' : ''}${p}%</button>`).join('');
  openSheet({
    replace: true,
    title: 'Stop & Alarm',
    body: `
      <div class="tiny">${esc(a.name)} için seviye belirle. Fiyat bu seviyeye gelince sana bildirim gelir; sürekli takip etmen gerekmez.</div>
      ${seg([['unit', 'Birim fiyat'], ['total', 'Toplam değer']], al.basis, '', 'light')}
      <div class="live-box" data-f="cur"></div>
      <div class="field"><label>${icon('trendDown', 'mini-ic')} Şunun altına düşerse (stop)</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="below" value="${al.below ? numInput(al.below) : ''}" placeholder="Boş bırakabilirsin"><em>₺</em></div>
        <div class="chip-row">${chips('below')}</div></div>
      <div class="field"><label>${icon('trend', 'mini-ic')} Şunun üstüne çıkarsa (kâr al)</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="above" value="${al.above ? numInput(al.above) : ''}" placeholder="Boş bırakabilirsin"><em>₺</em></div>
        <div class="chip-row">${chips('above')}</div></div>
      <div class="note-box">Telefonda fiyatlar arka planda yaklaşık <b>15 dakikada bir</b> kontrol edilir. Seviye aşılınca tek bir bildirim gelir; fiyat geri dönerse alarm yeniden kurulur.</div>
      <div class="btn-row"><button class="btn danger" data-s="off">Alarmı kaldır</button><button class="btn" data-s="save">${icon('check')} Kaydet</button></div>`,
    mount(el, api) {
      const showCur = () => { $('[data-f=cur]', el).innerHTML = `<span class="live-dot"></span>Şu an ${al.basis === 'total' ? 'toplam değer' : `1 ${esc(a.unit || '')}`}: <b>${money(cur(), { mask: false })}</b>`; };
      showCur();
      el.addEventListener('click', (e) => {
        const segb = e.target.closest('.seg button');
        if (segb) { segSet(segb); al.basis = segb.dataset.v; showCur(); $('[data-f=below]', el).value = ''; $('[data-f=above]', el).value = ''; return; }
        const c = e.target.closest('[data-pc]');
        if (c) { const v = cur() * (1 + +c.dataset.pc / 100); $(`[data-f=${c.dataset.dir}]`, el).value = numInput(Math.round(v * 100) / 100); return; }
        const b = e.target.closest('[data-s]'); if (!b) return;
        if (b.dataset.s === 'off') { delete a.alert; }
        else {
          const below = parseNum($('[data-f=below]', el).value), above = parseNum($('[data-f=above]', el).value);
          if (!below && !above) { toast('En az bir seviye gir', { tone: 'error' }); return; }
          if (below && below >= cur()) { toast('Stop seviyesi şu anki değerin altında olmalı', { tone: 'error' }); return; }
          if (above && above <= cur()) { toast('Üst seviye şu anki değerin üstünde olmalı', { tone: 'error' }); return; }
          a.alert = { basis: al.basis, below, above, firedBelow: false, firedAbove: false };
        }
        Store.save(); Prices.syncNative(); refresh();
        toast(a.alert ? 'Alarm kuruldu' : 'Alarm kaldırıldı', { icon: 'bell' });
        openAssetDetail(a, true);
      });
    },
  });
}
function openMoveSheet(a, mode) {
  const isInv = a.kind === 'investment';
  const title = mode === 'upd' ? 'Güncel Değeri Gir' : mode === 'dep' ? (isInv ? 'Alım Ekle' : 'Para Ekle') : isInv ? 'Satış' : 'Para Çek';
  openSheet({
    replace: true,
    title,
    body: `
      <div class="amount-inp ${mode === 'wd' ? 'out' : 'in'}"><span>₺</span><input class="num" inputmode="decimal" placeholder="0" data-f="amt" value="${mode === 'upd' ? numInput(a.value) : ''}"></div>
      ${isInv && mode !== 'upd' ? `<div class="field"><label>Miktar (${esc(a.unit || 'adet')})${a.track ? '' : ' — isteğe bağlı'}</label><input class="inp num" inputmode="decimal" data-f="qty" placeholder="Örn. 5"></div>` : ''}
      ${mode !== 'upd' ? `<div class="field"><label>Not</label><input class="inp" data-f="note" placeholder="${mode === 'dep' ? 'Örn. Aylık birikim' : 'Örn. Acil ihtiyaç'}"></div>
        <div class="opt-row"><div class="l"><b>Hesap bakiyesine yansıt</b><span>${mode === 'dep' ? 'Hesaptan düşülür' : 'Hesaba eklenir'} (analizde gider sayılmaz)</span></div>${sw('data-f="link"', true)}</div>` : '<div class="tiny" style="text-align:center">Yatırımının bugünkü toplam piyasa değerini gir</div>'}
      <button class="btn ${mode === 'wd' ? 'danger' : 'green'}" data-s="ok">${icon('check')} Onayla</button>`,
    mount(el, api) {
      setTimeout(() => $('[data-f=amt]', el).focus(), 420);
      el.addEventListener('click', (e) => {
        if (!e.target.closest('[data-s=ok]')) return;
        const v = parseNum($('[data-f=amt]', el).value);
        if (!(v > 0)) { toast('Tutar gir'); return; }
        a.history = a.history || [];
        if (mode === 'upd') {
          a.history.push({ id: uid(), amount: v - a.value, note: 'Değer güncellemesi', date: todayISO() }); a.value = v;
        } else {
          const q = $('[data-f=qty]', el) ? parseNum($('[data-f=qty]', el).value) : 0;
          const note = $('[data-f=note]', el).value.trim();
          if (a.track && !(q > 0)) { toast('Miktarı da gir', { tone: 'error' }); return; }
          if (mode === 'dep') {
            a.value += v; if (isInv) { a.cost = (a.cost || 0) + v; a.qty = (a.qty || 0) + q; }
            a.history.push({ id: uid(), amount: v, note: note || (isInv ? 'Alım' : 'Para eklendi'), date: todayISO() });
          } else if (a.track) {
            const share = Math.min(1, q / (a.qty || q));
            a.cost = (a.cost || 0) * (1 - share); a.qty = Math.max(0, (a.qty || 0) - q);
            a.history.push({ id: uid(), amount: -v, note: note || 'Satış', date: todayISO() });
          } else {
            const take = Math.min(v, a.value);
            if (isInv && a.value > 0) { a.cost = (a.cost || 0) * (1 - take / a.value); a.qty = Math.max(0, (a.qty || 0) - q); }
            a.value -= take;
            a.history.push({ id: uid(), amount: -take, note: note || (isInv ? 'Satış' : 'Para çekildi'), date: todayISO() });
          }
          if (a.track) { const pr = S().prices[priceKey(a.track)]; if (pr) a.value = Math.round(pr.p * a.qty * 100) / 100; Prices.syncNative(); }
          if ($('[data-f=link]', el).checked) {
            S().tx.push({ id: uid(), src: 'manual', type: mode === 'dep' ? 'out' : 'in', amount: v, cat: mode === 'dep' ? 'toSavings' : 'fromSavings', date: todayISO(), note: `${a.name} — ${mode === 'dep' ? 'aktarım' : 'çekim'}` });
          }
        }
        Store.save(); refresh(); toast('Kaydedildi');
        openAssetDetail(a, true);
      });
    },
  });
}

/* ---------- Ayarlar ---------- */
function openSettings() {
  const s = S().settings; const native = Native.isNative();
  if (s.theme === 'auto') s.theme = 'system';
  const apps = Object.entries(S().notifApps || {});
  openSheet({
    title: 'Ayarlar',
    body: `
      <div class="section-t">Profil</div>
      <div class="two"><div class="field"><label>Adın</label><input class="inp" data-set="name" value="${esc(s.name)}" placeholder="Sana nasıl hitap edelim?"></div>
      <div class="field"><label>Hesap açılış bakiyesi</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-set="openingBalance" value="${numInput(s.openingBalance)}" placeholder="0"><em>₺</em></div></div></div>
      <div class="tiny" style="margin-top:-6px">Açılış bakiyesi + tüm gelir − tüm gider = hesap bakiyen.</div>
      <div class="section-t">Görünüm</div>
      <div class="field"><label>Mod</label>${seg([['system', 'Telefon'], ['time', 'Saate göre'], ['light', 'Açık'], ['dark', 'Koyu']], s.theme, '', 'light theme-seg')}
        <div class="tiny">Telefon: telefonunun açık/koyu moduna uyar. Saate göre: sabah aydınlık, öğlen gündüz, akşam gece teması.</div></div>
      <div class="field"><label>Tema</label><div class="pal-grid">${PALETTES.map((p) => `<button class="pal ${(s.palette || 'navy') === p.id ? 'on' : ''}" data-pal="${p.id}"><span class="pal-sky" style="--p1:${p.c[0]};--p2:${p.c[1]};--p3:${p.c[2]}"><i></i><i></i></span><b>${p.name}</b><span>${p.desc}</span></button>`).join('')}</div></div>
      <button class="perm-btn" data-s="layout"><span class="avatar" style="--c:var(--blue)">${icon('list')}</span><div class="mid"><b>Düzen</b><span>Ana sayfa bölümleri, menü boyu, kart aralığı, yazı boyutu</span></div>${icon('chevR')}</button>

      <div class="section-t">Banka hareketleri</div>
      ${native ? `<button class="perm-btn" data-s="perm"><span class="avatar" style="--c:#10b77f">${icon('shield')}</span><div class="mid"><b>İzinler</b><span>SMS, banka bildirimleri ve bildirim gönderme</span></div>${icon('chevR')}</button>` : ''}
      <div>
        <div class="opt-row"><div class="l"><b>SMS'leri oku</b><span>Banka SMS'lerinden hareket çıkar</span></div>${sw('data-set="smsAuto"', s.smsAuto)}</div>
        <div class="opt-row"><div class="l"><b>Banka bildirimlerini oku</b><span>Banka uygulamalarının bildirimlerinden hareket çıkar</span></div>${sw('data-set="notifAuto"', s.notifAuto)}</div>
        <div class="opt-row"><div class="l"><b>Otomatik onayla</b><span>Kapalıysa önce senin onayına sunulur</span></div>${sw('data-set="smsAutoApprove"', s.smsAutoApprove)}</div>
      </div>
      ${apps.length ? `<div class="field"><label>Bildirim kaynakları</label><div class="card" style="box-shadow:none;background:var(--surface-2);padding:4px 14px">${apps.map(([pkg, v]) => `<div class="opt-row"><div class="l"><b>${esc(v.label || pkg)}</b><span>${esc(pkg)}</span></div>${sw(`data-app="${esc(pkg)}"`, notifAppAllowed(pkg, v.label))}</div>`).join('')}</div></div>` : ''}
      <div class="field"><label>Banka SMS gönderici adları (virgülle)</label><textarea class="inp" data-set="smsSenders" style="min-height:80px">${esc(s.smsSenders)}</textarea></div>
      ${native ? `<button class="btn ghost" data-s="rescan">${icon('refresh')} Taramayı sıfırla</button>` : ''}

      <div class="section-t">Bildirimler</div>
      <div>
        <div class="opt-row"><div class="l"><b>Yatırım alarmları</b><span>Stop ve hedef seviyeleri aşılınca haber ver</span></div>${sw('data-set="priceAlerts"', s.priceAlerts)}</div>
        <div class="opt-row"><div class="l"><b>Kart ödeme hatırlatmaları</b><span>Son ödemeye 7, 3, 1 gün kala ve son gün</span></div>${sw('data-set="cardReminders"', s.cardReminders !== false)}</div>
        <div class="opt-row"><div class="l"><b>Yeni halka arz bildirimi</b><span>Takvime yeni şirket eklenince</span></div>${sw('data-set="ipoNotify"', s.ipoNotify !== false)}</div>
        ${isBetul() ? `<div class="opt-row"><div class="l"><b>Günaydın & iyi geceler ❤</b><span>Her sabah 09.00 ve her gece 23.00</span></div>${sw('data-set="sweetNotifs"', s.sweetNotifs)}</div>` : ''}
      </div>
      <button class="btn ghost" data-s="testNotif">${icon('bell')} Bildirimleri dene</button>

      <div class="field"><label>Kampanya filtresi</label><button class="btn ghost" data-s="cleanAds">${icon('flag')} Yanlışlıkla eklenen kampanyaları temizle</button><div class="tiny">Kampanya, reklam ve teklif mesajları otomatik ayıklanır. Kaçan olursa harekete dokunup "Bu bir kampanyaydı" de; benzerleri bir daha eklenmez.</div></div>

      <div class="section-t">Güncellemeler</div>
      <div class="field"><label>Güncelleme adresi (update.json)</label><input class="inp" data-set="updateUrl" value="${esc(s.updateUrl || '')}" placeholder="${DEFAULT_UPDATE_URL}" inputmode="url"><div class="tiny">Boş bırakırsan varsayılan adres kullanılır.</div></div>
      <div class="btn-row"><button class="btn ghost" data-s="upd">${icon('refresh')} Denetle</button><button class="btn ghost" data-s="builtin">Yerleşik sürüm</button></div>
      <div class="tiny" data-f="ver">Sürüm ${APP_VERSION}</div>

      <div class="section-t">Veri</div>
      <div class="btn-row"><button class="btn ghost" data-s="export">${icon('download')} Yedek al</button><button class="btn ghost" data-s="import">${icon('upload')} Yedek yükle</button></div>
      <button class="btn ghost" data-s="guide">${icon('bell')} Banka bildirim rehberi</button>
      <button class="btn ghost" data-s="demo">${icon('sparkle')} Demo verilerle dene</button>
      <button class="btn danger" data-s="reset">${icon('refresh')} Uygulamayı sıfırla</button>
      <div class="tiny" style="margin-top:-6px">Sıfırlayınca tüm hareketler, kartlar, varlıklar ve ayarlar silinir; uygulama ilk açılıştaki gibi baştan başlar.</div>
      <div class="tiny" style="text-align:center;margin-top:4px">Akış · sürüm ${APP_VERSION} · Veriler yalnızca bu cihazda saklanır</div>`,
    mount(el, api) {
      el.addEventListener('input', (e) => {
        const k = e.target.dataset.set; if (!k) return;
        if (e.target.type === 'checkbox') s[k] = e.target.checked;
        else if (k === 'openingBalance' || k === 'smsFirstDays') s[k] = parseNum(e.target.value);
        else s[k] = e.target.value;
        Store.save();
      });
      el.addEventListener('change', (e) => {
        const app = e.target.dataset.app;
        if (app) { S().notifApps[app] = { ...(S().notifApps[app] || {}), on: e.target.checked }; Store.save(); return; }
        const k = e.target.dataset.set; if (!k) return;
        if (k === 'name' || k === 'sweetNotifs') setupNotifications();
        if (k === 'priceAlerts') Prices.syncNative();
        if (k === 'cardReminders') syncCardReminders();
        if (k === 'ipoNotify' && Native.isNative()) Native.akis().setIpoWatch({ on: s.ipoNotify !== false }).catch(() => {});
        refresh();
      });
      el.addEventListener('click', async (e) => {
        const segb = e.target.closest('.seg button');
        if (segb) { segSet(segb); auraSwitch(e.clientX, e.clientY, () => { s.theme = segb.dataset.v; Store.save(); applyTheme(); refresh(); }); return; }
        const pal = e.target.closest('[data-pal]');
        if (pal) { if (s.palette === pal.dataset.pal) return; auraSwitch(e.clientX, e.clientY, () => { s.palette = pal.dataset.pal; $$('[data-pal]', el).forEach((p) => p.classList.toggle('on', p === pal)); Store.save(); applyTheme(); refresh(); }); return; }
        const b = e.target.closest('[data-s]'); if (!b) return;
        const k = b.dataset.s;
        if (k === 'perm') openPermissions();
        if (k === 'upd') checkUpdates({ manual: true });
        if (k === 'builtin' && Native.isNative() && (await confirmSheet('Uygulama, telefona kurulu APK içindeki sürüme döner. Verilerin silinmez.', 'Dön', false))) Native.akis().resetBundle();
        if (k === 'cleanAds') { b.disabled = true; const n = await cleanupAds(); b.disabled = false; refresh(); toast(n ? `Kampanya olan ${n} kayıt silindi` : 'Kampanya kaydı bulunamadı', { icon: 'flag' }); }
        if (k === 'layout') openLayoutSheet();
        if (k === 'rescan') { s.lastSmsScan = 0; s.lastNotifScan = 0; S().seen = []; Store.save(); toast('Bir sonraki tarama baştan yapılacak'); }
        if (k === 'testNotif') openNotifTest();
        if (k === 'export') openBackupSheet();
        if (k === 'import') openRestoreSheet();
        if (k === 'demo' && (await confirmSheet('Mevcut verilerin demo verileriyle <b>değiştirilecek</b>.', 'Yükle', false))) { loadDemo(); api.close(); }
        if (k === 'guide') openBankGuide();
        if (k === 'reset' && (await confirmSheet('Tüm hareketler, kartlar, borçlar, varlıklar ve ayarlar silinecek; uygulama baştan başlayacak. <b>Bu işlem geri alınamaz.</b> İstersen önce "Yedek al" ile yedekle.', 'Sıfırla'))) resetApp();
      });
    },
  });
}
function openBackupSheet() {
  const json = Store.exportJSON();
  openSheet({
    title: 'Yedek Al',
    body: `<div class="tiny">Bu metni kopyalayıp güvenli bir yere (Notlar, e-posta taslağı vb.) kaydet. Geri yüklemek için "Yedek yükle"ye yapıştırman yeterli.</div>
      <textarea class="inp" readonly style="min-height:180px;font-family:monospace;font-size:11px">${esc(json)}</textarea>
      <button class="btn" data-s="copy">${icon('check')} Panoya kopyala</button>`,
    mount(el) {
      el.addEventListener('click', async (e) => {
        if (!e.target.closest('[data-s=copy]')) return;
        try { await navigator.clipboard.writeText(json); toast('Kopyalandı'); }
        catch { const ta = $('textarea', el); ta.select(); document.execCommand('copy'); toast('Kopyalandı'); }
      });
    },
  });
}
function openRestoreSheet() {
  openSheet({
    title: 'Yedek Yükle',
    body: `<textarea class="inp" data-f="j" placeholder="Yedek metnini buraya yapıştır" style="min-height:180px;font-family:monospace;font-size:11px"></textarea><button class="btn" data-s="ok">${icon('upload')} Geri yükle</button>`,
    mount(el, api) {
      el.addEventListener('click', (e) => {
        if (!e.target.closest('[data-s=ok]')) return;
        try { const o = JSON.parse($('[data-f=j]', el).value); if (!o || !Array.isArray(o.tx)) throw 0; Store.replace(o); applyTheme(); api.close(); render(); toast('Yedek yüklendi'); }
        catch { toast('Geçersiz yedek metni'); }
      });
    },
  });
}
function loadDemo() {
  const d = buildDemo(); const st = S();
  st.tx = d.tx; st.assets = d.assets; st.settings.openingBalance = d.openingBalance; st.pending = []; st.sim = null; st.onboarded = true;
  Store.save(); render(); toast('Demo verileri yüklendi');
}
/* ====================================================================== */
/*  BORÇLAR                                                                */
/* ====================================================================== */
function openDebtChooser(replace = false) {
  openSheet({
    replace,
    title: 'Ne eklemek istersin?',
    body: `<div class="choose">
      <button class="choose-opt" data-s="card"><span class="avatar" style="--c:var(--blue)">${icon('card')}</span><div><b>Kredi kartı</b><span>Dönem borcu, asgari ödeme ve son ödeme tarihi</span></div>${icon('chevR')}</button>
      <button class="choose-opt" data-s="debt"><span class="avatar" style="--c:#f5a524">${icon('receipt')}</span><div><b>Borç</b><span>Kredi, taksit ya da birine olan borç</span></div>${icon('chevR')}</button>
    </div>`,
    mount(el) { el.addEventListener('click', (e) => { const b = e.target.closest('[data-s]'); if (!b) return; if (b.dataset.s === 'card') openCardForm(null, true); else openDebtForm(null, true); }); },
  });
}
function bindBankPicker(el, onPick) {
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-bank]'); if (!b) return;
    $$('.bank-opt', el).forEach((x) => x.classList.toggle('on', x === b));
    onPick(b.dataset.bank);
  });
}
function openDebtForm(x = null, replace = false) {
  const edit = !!x; let bank = x ? x.bank || '' : '';
  openSheet({
    replace,
    title: edit ? 'Borcu Düzenle' : 'Borç Ekle',
    body: `
      <div class="amount-inp out"><span>₺</span><input class="num" inputmode="decimal" placeholder="0" data-f="amount" value="${x ? numInput(x.remaining) : ''}"></div>
      <div class="field"><label>Kime / ne için</label><input class="inp" data-f="name" placeholder="Örn. İhtiyaç kredisi, Ahmet, Taksit" value="${x ? esc(x.name) : ''}"></div>
      <div class="field"><label>Banka (isteğe bağlı)</label>${bankPicker(bank)}</div>
      <div class="two"><div class="field"><label>Son ödeme tarihi</label><input type="date" class="inp" data-f="due" value="${x ? x.due || '' : ''}"></div>
      <div class="field"><label>Not</label><input class="inp" data-f="note" placeholder="İsteğe bağlı" value="${x ? esc(x.note || '') : ''}"></div></div>
      <button class="btn" data-s="save">${icon('check')} ${edit ? 'Kaydet' : 'Ekle'}</button>`,
    mount(el, api) {
      const amt = $('[data-f=amount]', el); if (!edit) setTimeout(() => amt.focus(), 420);
      bindBankPicker(el, (id) => { bank = bank === id ? '' : id; if (!bank) $$('.bank-opt', el).forEach((o) => o.classList.remove('on')); });
      el.addEventListener('click', (e) => {
        if (!e.target.closest('[data-s=save]')) return;
        const v = parseNum(amt.value); if (!(v > 0)) { toast('Tutar gir', { tone: 'error' }); return; }
        const d = { name: $('[data-f=name]', el).value.trim() || (bank ? bankById(bank).name : 'Borç'), due: $('[data-f=due]', el).value, note: $('[data-f=note]', el).value.trim(), bank };
        if (edit) { const diff = v - x.remaining; Object.assign(x, d, { remaining: v, amount: Math.max(x.amount + Math.max(0, diff), v) }); }
        else S().debts.push({ id: uid(), amount: v, remaining: v, history: [{ id: uid(), amount: v, note: 'Borç eklendi', date: todayISO() }], ...d });
        Store.save(); api.close(); refresh(); toast(edit ? 'Güncellendi' : 'Borç eklendi', { icon: 'receipt' });
      });
    },
  });
}
/* ---------- Kredi kartları ---------- */
function cardVisual(c) {
  const b = bankById(c.bank);
  const used = c.limit ? Math.min(100, ((Number(c.current) || 0) / c.limit) * 100) : 0;
  return `<div class="ccard" style="--b1:${b.bg};--b2:${b.bg2};--bf:${b.fg}">
    <div class="ccard-top">${bankBadge(c.bank, 40)}<span class="ccard-bank">${esc(b.name)}</span></div>
    <div class="ccard-name">${esc(c.name || 'Kredi Kartı')}</div>
    <div class="ccard-num">•••• •••• •••• ${esc(c.last4 || '••••')}</div>
    ${c.limit ? `<div class="ccard-lim"><div class="ccard-bar"><i style="width:${used}%"></i></div><span>Limit ${money(c.limit)} · Kullanılabilir ${money(Math.max(0, c.limit - (c.current || 0)))}</span></div>` : ''}
  </div>`;
}
function openCardForm(c = null, replace = false) {
  const edit = !!c; let bank = c ? c.bank : 'garanti';
  const v = (k) => (c && c[k] ? numInput(c[k]) : '');
  openSheet({
    replace,
    title: edit ? 'Kartı Düzenle' : 'Kredi Kartı Ekle',
    body: `
      <div class="field"><label>Banka</label>${bankPicker(bank)}</div>
      <label class="logo-up"><input type="file" accept="image/*" data-f="logo" hidden>${icon('upload')} <span>Bu banka için kendi logonu yükle</span></label>
      <div class="two"><div class="field"><label>Kart adı</label><input class="inp" data-f="name" placeholder="Örn. Bonus" value="${c ? esc(c.name || '') : ''}"></div>
        <div class="field"><label>Son 4 hane</label><input class="inp num" inputmode="numeric" maxlength="4" data-f="last4" placeholder="İsteğe bağlı" value="${c ? esc(c.last4 || '') : ''}"></div></div>
      <div class="two"><div class="field"><label>Kart limiti</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="limit" value="${v('limit')}" placeholder="0"><em>₺</em></div></div>
        <div class="field"><label>Güncel toplam borç</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="current" value="${v('current')}" placeholder="0"><em>₺</em></div></div></div>
      <div class="field"><label>Dönem (ekstre) borcu</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="statement" value="${v('statement')}" placeholder="Son ekstredeki borç"><em>₺</em></div></div>
      <div class="two"><div class="field"><label>Hesap kesim günü</label><div class="input-unit wide"><input class="inp num" inputmode="numeric" data-f="cutDay" value="${c && c.cutDay ? c.cutDay : ''}" placeholder="Örn. 15"><em>. gün</em></div></div>
        <div class="field"><label>Son ödeme günü</label><div class="input-unit wide"><input class="inp num" inputmode="numeric" data-f="dueDay" value="${c && c.dueDay ? c.dueDay : ''}" placeholder="Örn. 25"><em>. gün</em></div></div></div>
      <div class="two"><div class="field"><label>Asgari oranı</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="minRate" value="${v('minRate')}" placeholder="Otomatik"><em>%</em></div></div>
        <div class="field"><label>Ya da asgari tutar</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="minPay" value="${v('minPay')}" placeholder="Ekstredeki"><em>₺</em></div></div></div>
      <div class="tiny">Otomatik asgari: limit 50.000 ₺'ye kadar dönem borcunun %20'si, üstünde %40'ı. Ekstrendeki tutar farklıysa onu yaz.</div>
      <button class="btn" data-s="save">${icon('check')} ${edit ? 'Kaydet' : 'Kartı ekle'}</button>`,
    mount(el, api) {
      bindBankPicker(el, (id) => { bank = id; });
      $('[data-f=logo]', el).addEventListener('change', async (e) => {
        const f = e.target.files && e.target.files[0]; if (!f) return;
        try { S().bankLogos[bank] = await readLogoFile(f); Store.save(); $$('.bank-opt', el).forEach((o) => { if (o.dataset.bank === bank) o.querySelector('.bank-badge').outerHTML = bankBadge(bank, 38); }); toast(`${bankById(bank).name} logosu kaydedildi`); }
        catch { toast('Görsel okunamadı', { tone: 'error' }); }
      });
      el.addEventListener('click', (e) => {
        if (!e.target.closest('[data-s=save]')) return;
        const g = (k) => $(`[data-f=${k}]`, el).value;
        const day = (k) => Math.max(0, Math.min(31, Math.round(parseNum(g(k)))));
        const d = {
          bank, name: g('name').trim(), last4: g('last4').replace(/\D/g, '').slice(-4), limit: parseNum(g('limit')), current: parseNum(g('current')),
          statement: parseNum(g('statement')), cutDay: day('cutDay'), dueDay: day('dueDay'), minRate: parseNum(g('minRate')), minPay: parseNum(g('minPay')),
        };
        if (!d.current && !d.statement && !d.limit) { toast('Borç ya da limit gir', { tone: 'error' }); return; }
        if (edit) { if (d.statement !== c.statement) d.paid = 0; Object.assign(c, d); }
        else S().cards.push({ id: uid(), paid: 0, history: [{ id: uid(), amount: d.current, note: 'Kart eklendi', date: todayISO() }], ...d });
        Store.save(); api.close(); refresh(); toast(edit ? 'Kart güncellendi' : 'Kart eklendi', { icon: 'card' });
      });
    },
  });
}
function openCardDetail(c, replace = false) {
  const n = nextDue(c); const min = cardMinimum(c);
  const hist = [...(c.history || [])].reverse();
  openSheet({
    replace,
    title: esc(c.name || bankById(c.bank).name),
    body: `
      ${cardVisual(c)}
      <div class="kpis">
        <div class="kpi"><div class="t">Güncel borç</div><div class="v num down">${money(c.current)}</div></div>
        <div class="kpi"><div class="t">Dönem borcu</div><div class="v num">${money(c.statement)}</div>${c.paid ? `<div class="d up">Ödenen ${money(c.paid)}</div>` : ''}</div>
        <div class="kpi"><div class="t">Asgari ödeme</div><div class="v num">${money(min)}</div><div class="d muted">${c.minPay ? 'Ekstredeki tutar' : pct(cardMinRate(c), 0) + ' oranla'}</div></div>
        <div class="kpi"><div class="t">Son ödeme</div><div class="v num ${n && n.days <= 3 ? 'down' : ''}">${n ? `${n.date.getDate()} ${MONTHS_S[n.date.getMonth()]}` : '—'}</div><div class="d muted">${n ? (n.days === 0 ? 'bugün' : n.days + ' gün kaldı') : ''}</div></div>
      </div>
      ${c.current > 0 ? `<div class="field"><label>Ödeme yap</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="pay" placeholder="Tutar"><em>₺</em></div></div>
      <div class="chip-row">${min > 0 ? `<button class="chip" data-fill="${min}">Asgari ${money(min, { mask: false })}</button>` : ''}${c.statement - (c.paid || 0) > 0 ? `<button class="chip" data-fill="${Math.max(0, c.statement - (c.paid || 0))}">Dönem borcu</button>` : ''}<button class="chip" data-fill="${c.current}">Tamamı</button></div>
      <div class="opt-row" style="padding:0"><div class="l"><b>Hesap bakiyesinden düş</b><span>Gider olarak "Kredi / Kart" kategorisine yazılır</span></div>${sw('data-f="link"', true)}</div>
      <button class="btn green" data-s="pay">${icon('check')} Öde</button>` : '<div class="note-box"><b>Bu kartta borç yok.</b></div>'}
      <div class="section-t">Geçmiş</div>
      <div class="rows">${hist.map((h) => `<div class="row" style="padding:8px 2px"><div class="mid"><div class="ttl" style="font-size:13.5px">${esc(h.note)}</div><div class="meta">${dayLabel(h.date)}</div></div><div class="amt num" style="font-size:13.5px">${money(h.amount)}</div></div>`).join('')}</div>
      <div class="btn-row"><button class="btn ghost" data-s="edit">${icon('edit')} Düzenle</button><button class="btn danger" data-s="del">${icon('trash')} Sil</button></div>`,
    mount(el, api) {
      el.addEventListener('click', async (e) => {
        const f = e.target.closest('[data-fill]'); if (f) { $('[data-f=pay]', el).value = numInput(+f.dataset.fill); return; }
        const b = e.target.closest('[data-s]'); if (!b) return; const k = b.dataset.s;
        if (k === 'pay') {
          const v = Math.min(c.current, parseNum($('[data-f=pay]', el).value));
          if (!(v > 0)) { toast('Tutar gir', { tone: 'error' }); return; }
          c.current = Math.round((c.current - v) * 100) / 100; c.paid = Math.round(((c.paid || 0) + v) * 100) / 100;
          (c.history = c.history || []).push({ id: uid(), amount: v, note: 'Kart ödemesi', date: todayISO() });
          if ($('[data-f=link]', el).checked) S().tx.push({ id: uid(), src: 'manual', type: 'out', amount: v, cat: 'debt', date: todayISO(), note: `${c.name || bankById(c.bank).name} kart ödemesi` });
          Store.save(); refresh(); toast(cardMinimum(c) <= 0 && c.statement ? 'Asgari ödeme tamam' : 'Ödeme kaydedildi', { icon: 'check' });
          openCardDetail(c, true);
        }
        if (k === 'edit') openCardForm(c, true);
        if (k === 'del' && (await confirmSheet('Bu kart silinecek.'))) { S().cards = S().cards.filter((x) => x.id !== c.id); Store.save(); api.close(); refresh(); toast('Silindi'); }
      });
    },
  });
}
function openDebtsList() {
  const cards = S().cards || [];
  const list = (S().debts || []).slice().sort((a, b) => (b.remaining > 0) - (a.remaining > 0) || (a.due || '9').localeCompare(b.due || '9'));
  const minTotal = cards.reduce((a, c) => a + cardMinimum(c), 0);
  openSheet({
    title: 'Borçlarım',
    body: `<div class="kpis"><div class="kpi"><div class="t">Toplam borç</div><div class="v num down">${money(Calc.debtTotal())}</div></div><div class="kpi"><div class="t">Kartların asgarisi</div><div class="v num">${money(minTotal)}</div></div></div>
      <div class="section-t">Kredi kartları</div>
      <div class="rows">${cards.length ? cards.map(cardRow).join('') : '<div class="tiny">Kart eklenmedi</div>'}</div>
      <div class="section-t">Diğer borçlar</div>
      <div class="rows">${list.length ? list.map(debtRow).join('') : '<div class="tiny">Borç yok</div>'}</div>
      <div class="btn-row"><button class="btn ghost" data-s="card">${icon('card')} Kart ekle</button><button class="btn" data-s="add">${icon('plus')} Borç ekle</button></div>`,
    mount(el) {
      el.addEventListener('click', (e) => {
        const r = e.target.closest('[data-action=debtOpen]'); if (r) { const x = S().debts.find((d) => d.id === r.dataset.id); if (x) openDebtDetail(x, true); return; }
        const cr = e.target.closest('[data-action=cardOpen]'); if (cr) { const c = S().cards.find((d) => d.id === cr.dataset.id); if (c) openCardDetail(c, true); return; }
        if (e.target.closest('[data-s=add]')) { if (isBetul()) openBetulDebt(); else openDebtForm(null, true); }
        if (e.target.closest('[data-s=card]')) openCardForm(null, true);
      });
    },
  });
}
function openDebtDetail(x, replace = false) {
  const hist = [...(x.history || [])].reverse();
  const paidPct = x.amount ? Math.min(100, ((x.amount - x.remaining) / x.amount) * 100) : 0;
  openSheet({
    replace,
    title: esc(x.name),
    body: `
      <div style="display:flex;gap:12px;align-items:center">${x.bank ? bankBadge(x.bank, 48) : ''}<div><div class="tiny">Kalan borç</div><div style="font-size:28px;font-weight:800" class="num ${x.remaining > 0 ? 'down' : 'up'}">${money(x.remaining)}</div>
        <div class="tiny">${x.due ? 'Son ödeme: ' + dayLabel(x.due) : 'Vade yok'}${x.note ? ' · ' + esc(x.note) : ''}</div></div></div>
      <div><div class="track"><i style="width:${paidPct}%;background:var(--in)"></i></div><div class="tiny" style="margin-top:6px">${pct(paidPct, 0)} ödendi · Toplam ${money(x.amount)}</div></div>
      ${x.remaining > 0 ? `<div class="field"><label>Ödeme yap</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="pay" placeholder="Tutar"><em>₺</em></div></div>
        <div class="opt-row" style="padding:0"><div class="l"><b>Hesap bakiyesinden düş</b><span>Gider olarak "Kredi / Kart" kategorisine yazılır</span></div>${sw('data-f="link"', true)}</div>
        <div class="btn-row"><button class="btn ghost" data-s="all">Tamamını öde</button><button class="btn green" data-s="pay">${icon('check')} Öde</button></div>` : '<div class="note-box"><b>Bu borç kapandı.</b></div>'}
      <div class="section-t">Geçmiş</div>
      <div class="rows">${hist.map((h) => `<div class="row" style="padding:8px 2px"><div class="mid"><div class="ttl" style="font-size:13.5px">${esc(h.note)}</div><div class="meta">${dayLabel(h.date)}</div></div><div class="amt num" style="font-size:13.5px">${money(h.amount)}</div></div>`).join('')}</div>
      <div class="btn-row"><button class="btn ghost" data-s="edit">${icon('edit')} Düzenle</button><button class="btn danger" data-s="del">${icon('trash')} Sil</button></div>`,
    mount(el, api) {
      el.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-s]'); if (!b) return; const k = b.dataset.s;
        if (k === 'pay' || k === 'all') {
          const v = k === 'all' ? x.remaining : Math.min(x.remaining, parseNum($('[data-f=pay]', el).value));
          if (!(v > 0)) { toast('Tutar gir', { tone: 'error' }); return; }
          x.remaining = Math.round((x.remaining - v) * 100) / 100;
          (x.history = x.history || []).push({ id: uid(), amount: v, note: x.remaining <= 0 ? 'Son ödeme — borç kapandı' : 'Ödeme', date: todayISO() });
          if ($('[data-f=link]', el).checked) S().tx.push({ id: uid(), src: 'manual', type: 'out', amount: v, cat: 'debt', date: todayISO(), note: `${x.name} — borç ödemesi` });
          Store.save(); refresh(); toast(x.remaining <= 0 ? 'Borç kapandı' : 'Ödeme kaydedildi', { icon: 'check' });
          openDebtDetail(x, true);
        }
        if (k === 'edit') openDebtForm(x, true);
        if (k === 'del' && (await confirmSheet(`<b>${esc(x.name)}</b> borcu silinecek.`))) { S().debts = S().debts.filter((d) => d.id !== x.id); Store.save(); api.close(); refresh(); toast('Silindi'); }
      });
    },
  });
}
/* ====================================================================== */
/*  BİREYSEL EMEKLİLİK (BES)                                               */
/* ====================================================================== */
function besBody() {
  const b = S().bes;
  if (!b) return `<div class="card"><div class="empty" style="padding:20px 6px">${icon('umbrella')}<div style="color:var(--text);font-weight:700;font-size:15px;margin-bottom:6px">Bireysel emekliliğini takip et</div>
    <div>Birikimini, devlet katkını ve hak ediş oranını tek yerde gör; emekliliğe kadar ne kadar biriktireceğini hesapla.</div></div>
    <button class="btn" data-action="besEdit">${icon('plus')} BES bilgilerimi gir</button></div>`;
  const c = besCalc(b);
  const yrs = Math.min(10, c.years);
  const stages = [[3, 15], [6, 35], [10, 60]];
  return `
    <div class="card">
      <div class="card-h"><h3>${esc(b.company || 'Bireysel Emeklilik')}</h3><button class="link" data-action="besEdit">${icon('edit')} Düzenle</button></div>
      <div class="tiny">Bugün çıksan eline geçecek (tahmini)</div>
      <div class="sim-hero-v num">${money(c.nowTotal)}</div>
      <div class="kpis" style="margin-top:12px">
        <div class="kpi"><div class="t">Kendi birikimin</div><div class="v num">${money(b.fund)}</div><div class="d ${c.gain >= 0 ? 'up' : 'down'}">Getiri ${money(c.gain, { sign: true })}</div></div>
        <div class="kpi"><div class="t">Ödediğin katkı</div><div class="v num">${money(b.paid)}</div><div class="d muted">Aylık ${money(b.monthly)}</div></div>
        <div class="kpi"><div class="t">Devlet katkısı birikimi</div><div class="v num">${money(b.state)}</div><div class="d muted">Oran ${pct(b.stateRate, 0)}</div></div>
        <div class="kpi"><div class="t">Hak ettiğin kısım</div><div class="v num up">${money(c.vestedState)}</div><div class="d muted">${pct(c.vest, 0)} hak ediş</div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Devlet Katkısı Hak Edişi</h3><span class="tiny">${c.months ? `${Math.floor(c.months / 12)} yıl ${c.months % 12} ay` : 'Başlangıç tarihi yok'}</span></div>
      <div class="vest">
        <div class="vest-bar"><i style="width:${(yrs / 10) * 100}%"></i>${stages.map(([y]) => `<span class="vest-mark ${c.years >= y ? 'on' : ''}" style="left:${y * 10}%"></span>`).join('')}</div>
        <div class="vest-lbl">${stages.map(([y, p]) => `<span style="left:${y * 10}%" class="${c.years >= y ? 'on' : ''}"><b>${pct(p, 0)}</b>${y}. yıl</span>`).join('')}</div>
      </div>
      <div class="tiny" style="margin-top:10px">10 yıl dolup 56 yaşına girince devlet katkısının <b>%100</b>'ü senin olur.${c.age ? ` Şu an ${c.age} yaşındasın.` : ''}</div>
    </div>
    <div class="card">
      <div class="card-h"><h3>Emeklilikte</h3><span class="tiny">${c.left ? `${MONTHS[c.end.getMonth()]} ${c.end.getFullYear()}` : 'Hak kazanıldı'}</span></div>
      <div class="kpis">
        <div class="kpi"><div class="t">Kendi birikimin</div><div class="v num">${compact(c.projFund)}</div></div>
        <div class="kpi"><div class="t">Devlet katkısı</div><div class="v num up">${compact(c.projState)}</div></div>
        <div class="kpi" style="grid-column:span 2"><div class="t">Toplam (tahmini)</div><div class="v num">${money(c.projFund + c.projState, { mask: false })}</div><div class="d muted">${pct(b.ret, 0)} yıllık getiri ve aylık ${money(b.monthly, { mask: false })} katkıyla · ${Math.round(c.left / 12)} yıl</div></div>
      </div>
    </div>
    <div class="tiny" style="text-align:center;padding:0 10px">Güncel değerleri e-Devlet'ten ya da BES şirketinin uygulamasından alıp "Düzenle" ile girebilirsin. Devlet katkısı oranını güncel mevzuata göre ayarla.</div>`;
}
function openBesForm() {
  const b = { ...besDefaults(), ...(S().bes || {}) };
  const f = (label, key, unit, ph = '0') => `<div class="field"><label>${label}</label><div class="input-unit ${unit.length > 1 ? 'wide' : ''}"><input class="inp num" inputmode="decimal" data-b="${key}" value="${b[key] ? numInput(b[key]) : ''}" placeholder="${ph}"><em>${unit}</em></div></div>`;
  openSheet({
    title: 'Bireysel Emeklilik',
    body: `
      <div class="field"><label>Şirket / plan adı</label><input class="inp" data-b="company" value="${esc(b.company)}" placeholder="Örn. Anadolu Hayat"></div>
      <div class="two"><div class="field"><label>Sisteme giriş</label><input type="month" class="inp" data-b="start" value="${b.start}"></div>
        <div class="field"><label>Doğum yılı</label><input class="inp num" inputmode="numeric" data-b="birthYear" value="${b.birthYear || ''}" placeholder="Örn. 1997"></div></div>
      <div class="two">${f('Aylık katkı payı', 'monthly', '₺')}${f('Ödenen toplam katkı', 'paid', '₺')}</div>
      <div class="two">${f('Kendi birikim değeri', 'fund', '₺')}${f('Devlet katkısı birikimi', 'state', '₺')}</div>
      <div class="two">${f('Devlet katkı oranı', 'stateRate', '%', '30')}${f('Beklenen yıllık getiri', 'ret', '%')}</div>
      ${f('Yıllık devlet katkısı üst sınırı (isteğe bağlı)', 'yearlyCap', '₺', 'Sınırsız')}
      <button class="btn" data-s="save">${icon('check')} Kaydet</button>
      ${S().bes ? `<button class="btn danger" data-s="del">${icon('trash')} BES kaydını sil</button>` : ''}`,
    mount(el, api) {
      el.addEventListener('click', async (e) => {
        const btn = e.target.closest('[data-s]'); if (!btn) return;
        if (btn.dataset.s === 'save') {
          const o = {};
          $$('[data-b]', el).forEach((i) => { const k = i.dataset.b; o[k] = k === 'company' || k === 'start' ? i.value.trim() : parseNum(i.value); });
          if (!o.stateRate && $('[data-b=stateRate]', el).value === '') o.stateRate = 30;
          o.retireAge = 56;
          S().bes = o; Store.save(); api.close(); UI.assetMode = 'bes'; refresh(); toast('BES bilgileri kaydedildi', { icon: 'umbrella' });
        }
        if (btn.dataset.s === 'del' && (await confirmSheet('BES bilgilerin silinecek.'))) { S().bes = null; Store.save(); api.close(); refresh(); }
      });
    },
  });
}
/* ---------- Simülasyon dönemleri ---------- */
function openSimSettings() {
  const draw = () => [...S().simHorizons].sort((a, b) => a - b).map((m) => `<span class="chip on hz">${horizonLabel(m)}<button data-del="${m}" aria-label="Kaldır">${icon('x')}</button></span>`).join('');
  openSheet({
    title: 'Simülasyon Dönemleri',
    body: `<div class="tiny">Üstte görünen dönem düğmelerini burada belirle.</div>
      <div class="chip-row" style="flex-wrap:wrap" data-f="list">${draw()}</div>
      <div class="field"><label>Yeni dönem</label><div style="display:grid;grid-template-columns:1fr 150px;gap:10px"><input class="inp num" inputmode="numeric" data-f="n" placeholder="Örn. 18">${seg([['m', 'Ay'], ['y', 'Yıl']], 'm', '', 'light')}</div></div>
      <button class="btn" data-s="add">${icon('plus')} Ekle</button>`,
    mount(el) {
      let unit = 'm';
      const redraw = () => { $('[data-f=list]', el).innerHTML = draw(); Store.save(); if (UI.tab === 'sim') refresh(); };
      el.addEventListener('click', (e) => {
        const segb = e.target.closest('.seg button'); if (segb) { segSet(segb); unit = segb.dataset.v; return; }
        const d = e.target.closest('[data-del]');
        if (d) { if (S().simHorizons.length <= 1) { toast('En az bir dönem kalmalı', { tone: 'error' }); return; } S().simHorizons = S().simHorizons.filter((m) => m !== +d.dataset.del); redraw(); return; }
        if (e.target.closest('[data-s=add]')) {
          const n = Math.round(parseNum($('[data-f=n]', el).value)); const m = unit === 'y' ? n * 12 : n;
          if (!(m > 0) || m > 600) { toast('1 ay ile 50 yıl arasında bir değer gir', { tone: 'error' }); return; }
          if (!S().simHorizons.includes(m)) S().simHorizons.push(m);
          $('[data-f=n]', el).value = ''; redraw();
        }
      });
    },
  });
}
/* ---------- Telefon bildirimleri ---------- */
async function setupNotifications() {
  if (!Native.isNative()) return;
  const A = Native.akis(); if (!A) return;
  const items = isBetul() && S().settings.sweetNotifs ? [
    { id: 9001, hour: 9, minute: 0, title: 'Günaydın hayatım 🤍', body: '' },
    { id: 9002, hour: 23, minute: 0, title: 'İlacını içtin mi hayatım? 🤍', body: 'Seni seviyorum. İyi geceler.' },
  ] : [];
  try { await A.setDaily({ items }); } catch (e) { /* sessiz */ }
}
function notifSamples() {
  const list = [
    { k: 'stop', ic: 'trendDown', c: '#ef4c5a', label: 'Yatırım alarmı — stop', title: 'Gram Altın ▼ ₺5.980', body: 'Stop ₺6.000 altında · Toplam ₺119.600' },
    { k: 'target', ic: 'trend', c: '#10b77f', label: 'Yatırım alarmı — hedef', title: 'Bitcoin ▲ ₺3.450.000', body: 'Hedef ₺3.400.000 aşıldı · Toplam ₺34.500' },
    { k: 'card', ic: 'card', c: '#1f6bff', label: 'Kart ödeme hatırlatması', title: 'Kart ödemesi: 7 gün kaldı', body: 'Bonus · Asgari ₺4.980 · 25 Kas' },
    { k: 'ipo', ic: 'rocket', c: '#8b5cf6', label: 'Yeni halka arz', title: 'Yeni halka arz: NETGL', body: '9-10-11 Eylül 2026 · Net Global Endüstriyel' },
  ];
  if (isBetul()) list.push(
    { k: 'morning', ic: 'sun', c: '#f5a524', label: 'Sabah 09.00', title: 'Günaydın hayatım 🤍', body: '' },
    { k: 'night', ic: 'moon', c: '#7c4dff', label: 'Gece 23.00', title: 'İlacını içtin mi hayatım? 🤍', body: 'Seni seviyorum. İyi geceler.' },
  );
  return list;
}
async function sendTestNotification(sample) {
  const A = Native.akis(); if (!A) return;
  try {
    const r = await A.requestPost();
    if (!r.granted) { toast('Bildirim izni verilmedi', { tone: 'error' }); return; }
    const x = sample || notifSamples()[0];
    await A.showNow({ title: x.title, body: x.body, delay: 2000 });
    toast('2 saniye içinde gelecek', { icon: 'bell' });
  } catch (e) { toast(String(e.message || e), { tone: 'error' }); }
}
function openNotifTest() {
  const native = Native.isNative(); const list = notifSamples();
  openSheet({
    title: 'Bildirimleri dene',
    body: `<div class="tiny">${native ? 'Birine dokun; 2 saniye sonra telefonun bildirimi olarak gelir (uygulamanın sesiyle).' : 'Önizlemede yalnızca uygulama içi kart gösterilir; telefon bildirimleri Android uygulamasında çalışır.'}</div>
      <div class="choose">${list.map((x) => `<button class="choose-opt" data-n="${x.k}"><span class="avatar" style="--c:${x.c}">${icon(x.ic)}</span><div><b>${x.label}</b><span>${esc(x.title)}${x.body ? ' — ' + esc(x.body) : ''}</span></div>${icon('bell')}</button>`).join('')}
        <button class="choose-opt" data-n="island"><span class="avatar" style="--c:var(--blue)">${icon('sparkle')}</span><div><b>Uygulama içi bildirim</b><span>Uygulama açıkken üstten kayan kart</span></div>${icon('chevD')}</button>
      </div>`,
    mount(el) {
      el.addEventListener('click', (e) => {
        const b = e.target.closest('[data-n]'); if (!b) return;
        if (b.dataset.n === 'island') { toast('3 yeni hareket onay bekliyor', { title: 'Banka hareketleri', icon: 'sync', ms: 4000 }); return; }
        const x = list.find((s) => s.k === b.dataset.n);
        if (native) sendTestNotification(x);
        else toast(x.body || ' ', { title: x.title, icon: 'bell', tone: x.k === 'stop' ? 'error' : 'ok', ms: 4500 });
      });
    },
  });
}
function openWelcome() {
  openSheet({
    title: '',
    body: `<div class="welcome"><div class="logo">${icon('trend')}</div><h2>Akış'a hoş geldin</h2><p>Para giriş çıkışlarını, birikim ve yatırımlarını tek yerden takip et; geleceğini simüle et.</p></div>
      <div class="field"><label>Sana nasıl hitap edelim?</label><input class="inp name-inp" data-f="name" placeholder="Adın" autocomplete="given-name" enterkeyhint="go"></div>
      <button class="btn" data-s="go" disabled>Başla ${icon('chevR')}</button>
      <div class="tiny" style="text-align:center">Her şey sıfırdan başlar; ayarları sen yaparsın. Verilerin yalnızca bu cihazda kalır.</div>`,
    mount(el, api) {
      const inp = $('[data-f=name]', el), go = $('[data-s=go]', el);
      setTimeout(() => inp.focus(), 450);
      inp.addEventListener('input', () => { go.disabled = !inp.value.trim(); });
      const start = () => {
        const name = inp.value.trim(); if (!name) return;
        S().settings.name = name; S().onboarded = true; Store.save();
        api.close(); render(); setupNotifications();
        S().settings.trackSince = Date.now(); S().settings.lastSmsScan = Date.now(); S().settings.lastNotifScan = Date.now(); Store.save();
        setTimeout(() => { if (isBetul()) openBetulWelcome(); else openBankGuide(() => { if (Native.isNative()) openPermissions(); }); }, 420);
      };
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') start(); });
      go.addEventListener('click', start);
    },
  });
}
function openBetulWelcome() {
  openSheet({
    title: '',
    body: `<div class="love"><div class="hearts">${'<i>❤</i>'.repeat(9)}</div>
      <div class="love-heart">❤</div>
      <h2>Hoş geldin benim bütün varlığım.</h2></div>
      <button class="btn love-btn" data-close>Başlayalım</button>`,
    mount(el, api) {
      const oc = api.close; api.close = (f) => { oc(f); setTimeout(() => openBankGuide(() => { if (Native.isNative()) openPermissions(); }), 420); };
    },
  });
}
function openBetulDebt() {
  openSheet({
    title: '',
    body: `<div class="love"><div class="hearts">${'<i>❤</i>'.repeat(7)}</div><div class="love-heart">❤</div>
      <h2>Senin borcun olamaz, sevgilin öder.</h2></div>
      <button class="btn love-btn" data-close>Tamam</button>
      <button class="link" style="align-self:center" data-s="anyway">Yine de kaydet</button>`,
    mount(el, api) { el.addEventListener('click', (e) => { if (e.target.closest('[data-s=anyway]')) openDebtChooser(true); }); },
  });
}
function openPermissions() {
  if (!Native.isNative()) { toast('İzinler telefondaki uygulamada ayarlanır', { icon: 'shield' }); return; }
  const row = (id, ic, c, title, sub) => `<div class="perm-row" data-p="${id}"><span class="avatar" style="--c:${c}">${icon(ic)}</span><div class="mid"><b>${title}</b><span>${sub}</span></div><button class="btn sm" data-s="${id}">İzin ver</button></div>`;
  openSheet({
    title: 'İzinler',
    body: `<div class="tiny">Akış'ın hareketlerini kendiliğinden yakalaması için bu izinlere ihtiyacı var. Verilerin telefondan çıkmaz.</div>
      ${row('sms', 'msg', '#1f6bff', 'SMS okuma', 'Banka SMS\'lerinden harcama ve para girişi')}
      ${row('nacc', 'bell', '#10b77f', 'Banka bildirimleri', 'Banka uygulamalarının bildirimlerini okuma')}
      ${row('post', 'sparkle', '#a855f7', 'Bildirim gönderme', 'Yatırım alarmları ve hatırlatmalar')}
      <div class="note-box"><b>"Kısıtlı ayar" uyarısı çıkarsa:</b><ol><li>Aşağıdaki düğmeyle uygulama bilgisine git</li><li>Sağ üstteki ⋮ menüsüne dokun</li><li>"Kısıtlı ayarlara izin ver"i seç, sonra buraya dönüp tekrar dene</li></ol></div>
      <button class="btn ghost" data-s="appinfo">${icon('settings')} Uygulama bilgisini aç</button>`,
    mount(el, api) {
      const upd = async () => {
        const set = (id, ok) => { const r = $(`[data-p=${id}]`, el); if (!r) return; const b = $('button', r); b.textContent = ok ? 'Açık' : 'İzin ver'; b.className = 'btn sm ' + (ok ? 'ok' : ''); b.disabled = ok; };
        try { const p = await Native.plugin().checkPermissions(); set('sms', p.sms === 'granted'); } catch (e) {}
        try { const n = await Native.akis().notifAccess(); set('nacc', n.enabled); } catch (e) {}
        try { const l = await Native.akis().postStatus(); set('post', l.granted); } catch (e) {}
      };
      upd(); permRefresh = upd;
      const oc = api.close; api.close = (f) => { permRefresh = null; oc(f); };
      el.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-s]'); if (!b) return;
        try {
          if (b.dataset.s === 'sms') { await Native.plugin().requestPermissions({ permissions: ['sms'] }); syncSources(true); }
          if (b.dataset.s === 'nacc') await Native.akis().openNotifAccess();
          if (b.dataset.s === 'post') { await Native.akis().requestPost(); setupNotifications(); }
          if (b.dataset.s === 'appinfo') await Native.akis().openAppSettings();
        } catch (err) { toast(String(err.message || err), { tone: 'error' }); }
        setTimeout(upd, 400);
      });
    },
  });
}
let permRefresh = null;
function openLayoutSheet() {
  const s = S().settings; const L = s.layout;
  const opt = (key, items) => seg(items, L[key], '', 'light lay-' + key);
  const secList = () => homeSections().map((x, i, arr) => `<div class="sec-row ${x.on ? '' : 'off'}" data-sec="${x.id}">
      <div class="sec-move"><button data-mv="-1" ${i === 0 ? 'disabled' : ''}>${icon('chevL')}</button><button data-mv="1" ${i === arr.length - 1 ? 'disabled' : ''}>${icon('chevR')}</button></div>
      <b>${SECTION_NAMES[x.id]}</b>${sw(`data-son="${x.id}"`, x.on)}</div>`).join('');
  openSheet({
    title: 'Görünüm & Düzen',
    body: `
      <div class="section-t">Ana sayfa bölümleri</div>
      <div class="tiny">Okla sırasını değiştir, anahtarla gizle/göster.</div>
      <div class="sec-list" data-f="secs">${secList()}</div>
      <div class="field"><label>Son hareketlerde kaç satır</label>${opt('recentCount', [[3, '3'], [5, '5'], [8, '8'], [12, '12']])}</div>
      <div class="section-t">Alt menü</div>
      <div class="field"><label>Menü yüksekliği</label>${opt('tabbar', [['short', 'Kısa'], ['normal', 'Normal'], ['tall', 'Uzun']])}</div>
      <div class="opt-row"><div class="l"><b>Menü yazıları</b><span>Kapalıysa sadece ikonlar görünür</span></div>${sw('data-lay="tabLabels"', L.tabLabels !== false)}</div>
      <div class="section-t">Sayfalar</div>
      <div class="field"><label>Üst alan (başlık) boyu</label>${opt('hero', [['short', 'Kısa'], ['normal', 'Normal'], ['tall', 'Geniş']])}</div>
      <div class="field"><label>Kart aralığı</label>${opt('density', [['compact', 'Sıkı'], ['normal', 'Normal'], ['comfy', 'Ferah']])}</div>
      <div class="field"><label>Köşeler</label>${opt('radius', [['sharp', 'Keskin'], ['normal', 'Normal'], ['round', 'Yuvarlak']])}</div>
      <div class="field"><label>Yazı ve öğe boyutu</label>${opt('scale', [['small', 'Küçük'], ['normal', 'Normal'], ['large', 'Büyük']])}</div>
      <div class="field"><label>Hareketler açılışta</label>${opt('txDefault', [['list', 'Liste'], ['analysis', 'Analiz']])}</div>
      <div class="field"><label>Varlıklar açılışta</label>${opt('assetsDefault', [['all', 'Tümü'], ['savings', 'Birikim'], ['investment', 'Yatırım'], ['bes', 'BES']])}</div>
      <button class="btn ghost" data-s="reset">${icon('refresh')} Varsayılan düzene dön</button>`,
    mount(el, api) {
      const apply = () => { Store.save(); applyTheme(); refresh(); };
      el.addEventListener('click', (e) => {
        const segb = e.target.closest('.seg button');
        if (segb) {
          segSet(segb); const key = [...segb.closest('.seg').classList].find((c) => c.startsWith('lay-')).slice(4);
          L[key] = key === 'recentCount' ? +segb.dataset.v : segb.dataset.v;
          if (key === 'txDefault') UI.txMode = L.txDefault; if (key === 'assetsDefault') UI.assetMode = L.assetsDefault;
          apply(); return;
        }
        const mv = e.target.closest('[data-mv]');
        if (mv) {
          const id = mv.closest('[data-sec]').dataset.sec; const arr = homeSections(); const i = arr.findIndex((x) => x.id === id); const j = i + +mv.dataset.mv;
          if (j < 0 || j >= arr.length) return; [arr[i], arr[j]] = [arr[j], arr[i]]; L.home = arr;
          $('[data-f=secs]', el).innerHTML = secList(); apply(); return;
        }
        if (e.target.closest('[data-s=reset]')) { s.layout = Store.defaultsLayout(); api.close(); applyTheme(); refresh(); toast('Varsayılan düzen'); }
      });
      el.addEventListener('change', (e) => {
        const son = e.target.dataset.son; if (son) { const x = homeSections().find((h) => h.id === son); x.on = e.target.checked; e.target.closest('.sec-row').classList.toggle('off', !x.on); apply(); return; }
        if (e.target.dataset.lay === 'tabLabels') { L.tabLabels = e.target.checked; apply(); }
      });
    },
  });
}
/* + tuşu: hızlı ekleme menüsü */
function openAddMenu() {
  const tiles = [
    ['in', 'plus', 'Gelir', '#10b77f'], ['out', 'minus', 'Gider', '#ef4c5a'], ['card', 'card', 'Kredi kartı', 'var(--blue)'],
    ['debt', 'receipt', 'Borç', '#f5a524'], ['recv', 'handCoins', 'Alacak', '#14b8a6'], ['asset', 'wallet', 'Varlık', '#8b5cf6'],
  ];
  openSheet({
    title: 'Ne eklemek istersin?',
    body: `<div class="add-grid">${tiles.map(([k, ic, l, c], i) => `<button class="add-tile" data-k="${k}" style="--c:${c};animation-delay:${i * 35}ms"><span class="add-ic">${icon(ic)}</span><b>${l}</b></button>`).join('')}</div>`,
    mount(el) {
      el.addEventListener('click', (e) => {
        const b = e.target.closest('[data-k]'); if (!b) return; const k = b.dataset.k;
        if (k === 'in' || k === 'out') { sheets[sheets.length - 1].close(true); openTxSheet(null, { type: k }); }
        if (k === 'card') openCardForm(null, true);
        if (k === 'debt') { if (isBetul()) { sheets[sheets.length - 1].close(true); openBetulDebt(); } else openDebtForm(null, true); }
        if (k === 'recv') openRecvForm(null, true);
        if (k === 'asset') openAssetForm(null, 'investment', true);
      });
    },
  });
}
/* ---------- Alacaklar ---------- */
function recvRow(x) {
  const late = x.due && x.due < todayISO();
  const got = x.amount ? Math.min(100, ((x.amount - x.remaining) / x.amount) * 100) : 0;
  return `<button class="row" data-action="recvOpen" data-id="${x.id}">
    <div class="avatar" style="--c:${late ? '#ef4c5a' : '#14b8a6'}">${icon('handCoins')}</div>
    <div class="mid"><div class="ttl">${esc(x.name)}</div><div class="meta">${x.due ? (late ? 'Günü geçti · ' : '') + dayLabel(x.due) : esc(x.note || 'Tarih yok')}</div>
      ${got ? `<div class="track goal-bar"><i style="width:${got}%;background:#14b8a6"></i></div>` : ''}</div>
    <div class="amt num up">${money(x.remaining)}</div></button>`;
}
function openRecvForm(x = null, replace = false) {
  const edit = !!x;
  openSheet({
    replace,
    title: edit ? 'Alacağı Düzenle' : 'Alacak Ekle',
    body: `
      <div class="amount-inp in"><span>₺</span><input class="num" inputmode="decimal" placeholder="0" data-f="amount" value="${x ? numInput(x.remaining) : ''}"></div>
      <div class="field"><label>Kimden</label><input class="inp" data-f="name" placeholder="Örn. Ahmet" value="${x ? esc(x.name) : ''}"></div>
      <div class="two"><div class="field"><label>Ne zaman (isteğe bağlı)</label><input type="date" class="inp" data-f="due" value="${x ? x.due || '' : ''}"></div>
        <div class="field"><label>Not</label><input class="inp" data-f="note" placeholder="Örn. Akşam yemeği" value="${x ? esc(x.note || '') : ''}"></div></div>
      <button class="btn green" data-s="save">${icon('check')} ${edit ? 'Kaydet' : 'Ekle'}</button>`,
    mount(el, api) {
      const amt = $('[data-f=amount]', el); if (!edit) setTimeout(() => amt.focus(), 420);
      el.addEventListener('click', (e) => {
        if (!e.target.closest('[data-s=save]')) return;
        const v = parseNum(amt.value); if (!(v > 0)) { toast('Tutar gir', { tone: 'error' }); return; }
        const name = $('[data-f=name]', el).value.trim(); if (!name) { toast('Kimden alacağını yaz', { tone: 'error' }); return; }
        const d = { name, due: $('[data-f=due]', el).value, note: $('[data-f=note]', el).value.trim() };
        if (edit) Object.assign(x, d, { remaining: v, amount: Math.max(x.amount, v) });
        else S().receivables.push({ id: uid(), amount: v, remaining: v, history: [{ id: uid(), amount: v, note: 'Alacak eklendi', date: todayISO() }], ...d });
        Store.save(); api.close(); refresh(); toast(edit ? 'Güncellendi' : 'Alacak eklendi', { icon: 'in' });
      });
    },
  });
}
function openRecvDetail(x, replace = false) {
  const hist = [...(x.history || [])].reverse();
  openSheet({
    replace,
    title: esc(x.name),
    body: `
      <div><div class="tiny">Alacağın</div><div style="font-size:28px;font-weight:800" class="num up">${money(x.remaining)}</div>
        <div class="tiny">${x.due ? dayLabel(x.due) : 'Tarih yok'}${x.note ? ' · ' + esc(x.note) : ''}</div></div>
      ${x.remaining > 0 ? `<div class="field"><label>Tahsil et</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="got" placeholder="Tutar"><em>₺</em></div></div>
        <div class="opt-row" style="padding:0"><div class="l"><b>Hesabıma ekle</b><span>Gelir olarak "Diğer" kategorisine yazılır</span></div>${sw('data-f="link"', true)}</div>
        <div class="btn-row"><button class="btn ghost" data-s="all">Tamamı geldi</button><button class="btn green" data-s="got">${icon('check')} Tahsil et</button></div>` : '<div class="note-box"><b>Bu alacak kapandı.</b></div>'}
      <div class="section-t">Geçmiş</div>
      <div class="rows">${hist.map((h) => `<div class="row" style="padding:8px 2px"><div class="mid"><div class="ttl" style="font-size:13.5px">${esc(h.note)}</div><div class="meta">${dayLabel(h.date)}</div></div><div class="amt num" style="font-size:13.5px">${money(h.amount)}</div></div>`).join('')}</div>
      <div class="btn-row"><button class="btn ghost" data-s="edit">${icon('edit')} Düzenle</button><button class="btn danger" data-s="del">${icon('trash')} Sil</button></div>`,
    mount(el, api) {
      el.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-s]'); if (!b) return; const k = b.dataset.s;
        if (k === 'got' || k === 'all') {
          const v = k === 'all' ? x.remaining : Math.min(x.remaining, parseNum($('[data-f=got]', el).value));
          if (!(v > 0)) { toast('Tutar gir', { tone: 'error' }); return; }
          x.remaining = Math.round((x.remaining - v) * 100) / 100;
          (x.history = x.history || []).push({ id: uid(), amount: v, note: x.remaining <= 0 ? 'Tamamı tahsil edildi' : 'Tahsilat', date: todayISO() });
          if ($('[data-f=link]', el).checked) S().tx.push({ id: uid(), src: 'manual', type: 'in', amount: v, cat: 'otherIn', date: todayISO(), note: `${x.name} — alacak` });
          Store.save(); refresh(); toast(x.remaining <= 0 ? 'Alacak kapandı' : 'Tahsilat kaydedildi', { icon: 'check' });
          openRecvDetail(x, true);
        }
        if (k === 'edit') openRecvForm(x, true);
        if (k === 'del' && (await confirmSheet(`<b>${esc(x.name)}</b> alacağı silinecek.`))) { S().receivables = S().receivables.filter((d) => d.id !== x.id); Store.save(); api.close(); refresh(); toast('Silindi'); }
      });
    },
  });
}
function openRecvList() {
  const list = (S().receivables || []).slice().sort((a, b) => (b.remaining > 0) - (a.remaining > 0) || (a.due || '9').localeCompare(b.due || '9'));
  openSheet({
    title: 'Alacaklarım',
    body: `<div class="kpis"><div class="kpi" style="grid-column:span 2"><div class="t">Toplam alacak</div><div class="v num up">${money(Calc.recvTotal())}</div></div></div>
      <div class="rows">${list.length ? list.map(recvRow).join('') : '<div class="empty">Alacak yok</div>'}</div>
      <button class="btn green" data-s="add">${icon('plus')} Alacak ekle</button>`,
    mount(el) {
      el.addEventListener('click', (e) => {
        const r = e.target.closest('[data-action=recvOpen]'); if (r) { const x = S().receivables.find((d) => d.id === r.dataset.id); if (x) openRecvDetail(x, true); return; }
        if (e.target.closest('[data-s=add]')) openRecvForm(null, true);
      });
    },
  });
}
/* ---------- Yatırımlar: portföy görünümü ---------- */
function chgChip(ch) {
  if (!ch) return '<span class="chg flat">%0,00</span>';
  return `<span class="chg ${ch > 0 ? 'pos' : 'neg'}">${ch > 0 ? '▲' : '▼'} %${Math.abs(ch).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>`;
}
function rangeBar(a) {
  const al = a.alert; if (!al || (!al.below && !al.above)) return '';
  const v = Prices.alertValue(a); if (!v) return '';
  const lo = al.below || v * 0.9, hi = al.above || v * 1.1;
  const min = Math.min(lo, v), max = Math.max(hi, v), span = max - min || 1;
  const pos = ((v - min) / span) * 100;
  return `<div class="range">
    <div class="range-bar"><i class="range-dot" style="left:${pos}%"></i></div>
    <div class="range-lbl"><span>${al.below ? '▼ ' + compact(al.below) : ''}</span><span>${al.above ? '▲ ' + compact(al.above) : ''}</span></div></div>`;
}
function holdingCard(a) {
  const t = assetTypeById(a.type); const I = a.track ? instrById(a.track.id) : null;
  const pl = (a.value || 0) - (a.cost || 0), p = a.cost ? (pl / a.cost) * 100 : 0;
  const ch = Prices.change(a); const unit = a.track ? Prices.unitPrice(a) : 0;
  return `<button class="hold" data-action="asset" data-id="${a.id}">
    <div class="hold-top">
      <span class="avatar" style="--c:${t.color}">${icon(t.icon)}</span>
      <div class="mid"><div class="ttl">${esc(a.name)}</div>
        <div class="meta">${a.qty ? `${Number(a.qty).toLocaleString('tr-TR', { maximumFractionDigits: 4 })} ${esc(a.unit || '')}` : t.name}${unit ? ` · ${money(unit, { mask: false })}` : ''}</div></div>
      <div class="amt num">${money(a.value)}${a.track ? chgChip(ch) : '<span class="chg flat">elle</span>'}</div>
    </div>
    <div class="hold-foot"><span>Kâr / zarar</span><b class="num ${pl >= 0 ? 'up' : 'down'}">${money(pl, { sign: true })} <small>${a.cost ? '%' + Math.abs(p).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : ''}</small></b>
      ${a.alert && (a.alert.below || a.alert.above) ? `<span class="bell-on">${icon('bell')}</span>` : ''}</div>
    ${rangeBar(a)}
  </button>`;
}
function investBody() {
  const sub = seg([['port', 'Portföy'], ['ipo', 'Halka Arz']], UI.invMode || 'port', 'invMode', 'light');
  if (UI.invMode === 'ipo') return sub + ipoBody();
  const st = S(); const inv = st.assets.filter((a) => a.kind === 'investment').sort((a, b) => b.value - a.value);
  const value = inv.reduce((s, a) => s + a.value, 0), cost = inv.reduce((s, a) => s + (a.cost || 0), 0), pl = value - cost;
  const today = inv.reduce((s, a) => { const ch = Prices.change(a); return s + (ch ? a.value - a.value / (1 + ch / 100) : 0); }, 0);
  const byType = {}; for (const a of inv) byType[a.type] = (byType[a.type] || 0) + a.value;
  const alloc = Object.entries(byType).map(([id, v]) => ({ t: assetTypeById(id), v })).sort((a, b) => b.v - a.v);
  const mk = st.market || {};
  const quick = [['FUND', 'Fon'], ['GRA', 'Altın'], ['GUMUS', 'Gümüş'], ['USD', 'Döviz'], ['bitcoin', 'Kripto'], ['BIST', 'Hisse'], ['', 'Diğer']];
  return `
    ${sub}
    <div class="ticker">${Prices.MARKET.map(([k, n]) => { const x = mk[k]; return `<div class="tick"><span>${n}</span><b class="num">${x ? money(x.p, { mask: false }) : '—'}</b>${x ? chgChip(x.ch) : ''}</div>`; }).join('')}</div>
    <div class="card port">
      <div class="tiny">Portföy değeri</div>
      <div class="sim-hero-v num">${money(value)}</div>
      <div class="port-row">
        <div><span>Bugün</span><b class="num ${today >= 0 ? 'up' : 'down'}">${money(today, { sign: true })}</b></div>
        <div><span>Toplam kâr/zarar</span><b class="num ${pl >= 0 ? 'up' : 'down'}">${money(pl, { sign: true })} <small>${cost ? '%' + (Math.abs(pl / cost) * 100).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : ''}</small></b></div>
      </div>
      ${alloc.length ? `<div class="alloc">${alloc.map((x) => `<i style="flex:${x.v};background:${x.t.color}"></i>`).join('')}</div>
        <div class="alloc-lg">${alloc.map((x) => `<span><i style="background:${x.t.color}"></i>${x.t.name} ${pct((x.v / value) * 100, 0)}</span>`).join('')}</div>` : ''}
    </div>
    <div class="chip-row">${quick.map(([id, l]) => `<button class="chip qadd" data-action="invAdd" data-instr="${id}">${icon('plus', 'mini-ic')} ${l}</button>`).join('')}</div>
    ${inv.length ? `<div class="holds">${inv.map(holdingCard).join('')}</div>`
      : `<div class="card empty">${icon('trend')}<div>Henüz yatırım yok.<br>Yukarıdan türünü seç; miktarı gir, değeri canlı fiyatla güncellensin.</div></div>`}
    <div class="tiny" style="text-align:center">Fiyatlar: Türkiye piyasası (altın/döviz), CoinGecko (kripto), Yahoo (BIST). Gecikmeli olabilir.</div>`;
}
/* ---------- Uygulama içi güncelleme ----------
   update.json örneği:
   { "web": { "version": "0.3.1", "url": "https://…/web-0.3.1.zip", "notes": "…" },
     "apk": { "versionCode": 4, "version": "0.4", "url": "https://…/Akis-0.4.apk", "notes": "…" } } */
const APP_VERSION = '0.5.0';
const DEFAULT_UPDATE_URL = 'https://emirhankitiroglu.github.io/akis-guncelleme/update.json';
const verGt = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) > (y[i] || 0)) return true; if ((x[i] || 0) < (y[i] || 0)) return false; } return false; };
async function checkUpdates({ manual = false } = {}) {
  const s = S().settings; const url = (s.updateUrl || '').trim() || DEFAULT_UPDATE_URL;
  if (!url) { if (manual) toast('Önce güncelleme adresini gir', { tone: 'error' }); return; }
  if (!manual && Date.now() - (s.lastUpdateCheck || 0) < 6 * 3600e3) return;
  s.lastUpdateCheck = Date.now(); Store.save();
  let j;
  try { j = await Prices.fetchJSON(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now()); }
  catch (e) { if (manual) toast('Güncelleme adresine ulaşılamadı', { tone: 'error' }); return; }
  const A = Native.akis(); const native = Native.isNative() && A;
  // 1) Yeni APK gerekiyorsa (yerel kod değiştiyse)
  if (j.apk && native) {
    const info = await A.appInfo().catch(() => ({}));
    if (info.versionCode && +j.apk.versionCode > +info.versionCode) {
      openSheet({
        title: 'Yeni uygulama sürümü',
        body: `<div class="note-box"><b>Akış ${esc(j.apk.version || '')}</b> hazır. Bu sürüm yeni telefon özellikleri içerdiği için bir kez APK olarak kurulmalı; verilerin silinmez.</div>
          ${j.apk.notes ? `<div class="tiny">${esc(j.apk.notes)}</div>` : ''}
          <button class="btn" data-s="dl">${icon('download')} İndir ve kur</button>`,
        mount(el, api) { el.addEventListener('click', (e) => { if (e.target.closest('[data-s=dl]')) { A.openUrl({ url: j.apk.url }); api.close(); } }); },
      });
      return;
    }
  }
  // 2) Web paketi (çoğu güncelleme): APK'sız, arka planda iner
  if (j.web && verGt(j.web.version, APP_VERSION)) {
    if (!native) { if (manual) toast(`Yeni sürüm ${j.web.version} var (önizlemede sayfayı yenile)`); return; }
    try {
      const { path } = await A.downloadBundle({ url: j.web.url, version: j.web.version });
      openSheet({
        title: 'Güncelleme hazır',
        body: `<div class="welcome"><div class="logo">${icon('sparkle')}</div><h2>Akış ${esc(j.web.version)}</h2><p>${esc(j.web.notes || 'Yeni özellikler ve iyileştirmeler.')}</p></div>
          <button class="btn" data-s="go">${icon('refresh')} Şimdi yeniden başlat</button><button class="btn ghost" data-close>Sonra</button>`,
        mount(el) { el.addEventListener('click', (e) => { if (e.target.closest('[data-s=go]')) A.applyBundle({ path }); }); },
      });
    } catch (e) { if (manual) toast(String(e.message || e), { tone: 'error' }); }
    return;
  }
  if (manual) toast(`Güncelsin · ${APP_VERSION}`, { icon: 'check' });
}
/* ---------- Halka arz ---------- */
const TR_MONTHS = ['ocak', 'subat', 'mart', 'nisan', 'mayis', 'haziran', 'temmuz', 'agustos', 'eylul', 'ekim', 'kasim', 'aralik'];
function ipoDates(when) {
  const n = SMS.norm(when || ''); const y = +(n.match(/(20\d\d)/) || [])[1];
  if (!y) return null;
  const parts = []; let m;
  const re = /(\d{1,2})|([a-z]+)/g; const nums = []; let lastMonth = -1; const seq = [];
  while ((m = re.exec(n))) { if (m[1]) nums.push(+m[1]); else { const k = TR_MONTHS.indexOf(m[2]); if (k > -1) { for (const d of nums) if (d <= 31) seq.push([d, k]); nums.length = 0; lastMonth = k; } } }
  if (!seq.length) return null;
  const first = new Date(y, seq[0][1], seq[0][0]), last = new Date(y, seq[seq.length - 1][1], seq[seq.length - 1][0], 23, 59);
  return { first, last };
}
function ipoStatus(it) {
  if (/ertelen/i.test(SMS.norm(it.when))) return { k: 'post', l: 'Ertelendi' };
  const d = ipoDates(it.when); if (!d) return { k: 'draft', l: 'SPK onayında' };
  const now = new Date();
  if (now < d.first) { const days = Math.ceil((d.first - now) / 864e5); return { k: 'soon', l: days <= 1 ? 'Yarın başlıyor' : `${days} gün sonra` }; }
  if (now <= d.last) return { k: 'live', l: 'Talep toplanıyor' };
  return { k: 'done', l: 'Tamamlandı' };
}
function ipoCard(it) {
  const s = ipoStatus(it);
  return `<button class="ipo-card ${s.k}" data-action="ipoOpen" data-link="${esc(it.link)}">
    <span class="ipo-logo">${it.logo ? `<img src="${esc(it.logo)}" alt="" loading="lazy" onerror="this.remove()">` : ''}<b>${esc((it.code || it.name.replace(/[^A-Za-zÇĞİÖŞÜ]/g, '')).slice(0, 4).toUpperCase())}</b></span>
    <div class="mid"><div class="ttl">${it.code ? esc(it.code) : `<span class="ipo-nm">${esc(it.name)}</span>`} <span class="ipo-st ${s.k}">${s.l}</span></div>${it.code ? `<div class="meta">${esc(it.name)}</div>` : ''}<div class="meta">${icon('calendar', 'mini-ic')} ${esc(it.when || 'Tarih henüz açıklanmadı')}</div></div>
    ${icon('chevR', 'chev')}</button>`;
}
function ipoBody() {
  const st = S(); const L = (st.ipo && st.ipo.list) || [];
  const mine = st.assets.filter((a) => a.ipo).sort((a, b) => b.value - a.value);
  const active = L.filter((x) => ['soon', 'live'].includes(ipoStatus(x).k));
  const done = L.filter((x) => ipoStatus(x).k === 'done').slice(0, 8);
  const drafts = L.filter((x) => ipoStatus(x).k === 'draft');
  return `
    <div class="card ipo-head">
      <div class="opt-row" style="padding:0"><div class="l"><b>Yeni halka arz bildirimi</b><span>Takvime yeni şirket eklenince haber ver</span></div>${sw('data-ipo-notify', st.settings.ipoNotify !== false)}</div>
    </div>
    ${mine.length ? `<div class="section-t">Katıldıklarım</div><div class="holds">${mine.map(holdingCard).join('')}</div>` : ''}
    <div class="section-t">Talep toplayan ve yaklaşan</div>
    ${!L.length ? `<div class="card empty" data-f="ipoload">${icon('rocket')}<div>Halka arz takvimi yükleniyor…</div></div>`
      : active.length ? `<div class="ipo-list">${active.map(ipoCard).join('')}</div>` : '<div class="card empty" style="padding:16px">Şu an talep toplayan ya da yaklaşan halka arz yok. Yeni bir arz eklenince sana bildirim gelir.</div>'}
    ${drafts.length ? `<div class="section-t">SPK onayı bekleyenler</div><div class="ipo-list">${drafts.map(ipoCard).join('')}</div>` : ''}
    ${done.length ? `<div class="section-t">Son tamamlananlar</div><div class="ipo-list">${done.map(ipoCard).join('')}</div>` : ''}
    <div class="tiny" style="text-align:center">Kaynak: halkarz.com takvimi${st.ipo ? ' · ' + timeAgo(st.ipo.at) : ''}</div>`;
}
function openIpoDetail(link) {
  const it = ((S().ipo && S().ipo.list) || []).find((x) => x.link === link); if (!it) return;
  const s = ipoStatus(it);
  openSheet({
    title: esc(it.code || it.name),
    body: `<div style="display:flex;gap:12px;align-items:center"><span class="ipo-logo big">${it.logo ? `<img src="${esc(it.logo)}" alt="" onerror="this.remove()">` : ''}<b>${esc((it.code || '?').slice(0, 5))}</b></span>
        <div><b style="font-size:15px">${esc(it.name)}</b><div class="tiny"><span class="ipo-st ${s.k}">${s.l}</span> ${esc(it.when)}</div></div></div>
      <div data-f="det" class="ipo-det"><div class="tiny">Ayrıntılar yükleniyor…</div></div>
      <button class="btn" data-s="join" disabled>${icon('plus')} Katıldım — pay ekle</button>
      <button class="link" style="align-self:center" data-s="web">halkarz.com'da aç ${icon('chevR')}</button>`,
    mount(el, api) {
      let det = null;
      Prices.ipoDetail(link).then((d) => {
        det = d;
        const rows = [['Tarih', d.when], ['Fiyat', d.price], ['Dağıtım', d.method], ['Pay', d.lots], ['Aracı kurum', d.broker], ['BIST kodu', d.code], ['Pazar', d.market], ['İlk işlem', d.firstTrade]].filter(([, v]) => v);
        $('[data-f=det]', el).innerHTML = rows.map(([k, v]) => `<div><span>${k}</span><b>${esc(v)}</b></div>`).join('');
        $('[data-s=join]', el).disabled = false;
      }).catch(() => { $('[data-f=det]', el).innerHTML = `<div class="tiny">Ayrıntılar alınamadı${Native.isNative() ? '' : ' (tarayıcı engelliyor, telefonda çalışır)'}</div>`; $('[data-s=join]', el).disabled = false; });
      el.addEventListener('click', (e) => {
        const b = e.target.closest('[data-s]'); if (!b) return;
        if (b.dataset.s === 'web' && Native.isNative()) Native.akis().openUrl({ url: link });
        if (b.dataset.s === 'web' && !Native.isNative()) window.open(link, '_blank');
        if (b.dataset.s === 'join') openIpoJoin(it, det);
      });
    },
  });
}
function openIpoJoin(it, det) {
  const code = ((det && det.code) || it.code || '').trim().toUpperCase();
  openSheet({
    replace: true,
    title: `${esc(code || it.name)} — katılım`,
    body: `<div class="two"><div class="field"><label>Aldığın lot</label><div class="input-unit wide"><input class="inp num" inputmode="decimal" data-f="lot" placeholder="Örn. 12"><em>lot</em></div></div>
        <div class="field"><label>Lot fiyatı</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-f="px" value="${det && det.priceNum ? numInput(det.priceNum) : ''}"><em>₺</em></div></div></div>
      <div class="field"><label>BIST kodu</label><input class="inp" data-f="code" value="${esc(code)}" style="text-transform:uppercase"></div>
      <div class="live-box" data-f="sum">Toplam: —</div>
      <div class="note-box">Hisse borsada işlem görmeye başlayınca değeri canlı fiyatla güncellenir; stop/hedef alarmı da kurabilirsin.</div>
      <button class="btn green" data-s="ok">${icon('check')} Portföyüme ekle</button>`,
    mount(el, api) {
      const upd = () => { const t = parseNum($('[data-f=lot]', el).value) * parseNum($('[data-f=px]', el).value); $('[data-f=sum]', el).innerHTML = `Toplam: <b>${t ? money(t, { mask: false }) : '—'}</b>`; };
      el.addEventListener('input', upd);
      el.addEventListener('click', (e) => {
        if (!e.target.closest('[data-s=ok]')) return;
        const lot = parseNum($('[data-f=lot]', el).value), px = parseNum($('[data-f=px]', el).value), sym = $('[data-f=code]', el).value.trim().toUpperCase();
        if (!(lot > 0) || !(px > 0) || !sym) { toast('Lot, fiyat ve kodu gir', { tone: 'error' }); return; }
        const cost = Math.round(lot * px * 100) / 100;
        S().assets.push({ id: uid(), kind: 'investment', type: 'stock', name: `${sym} (halka arz)`, qty: lot, unit: 'lot', cost, value: cost, track: { src: 'yh', id: 'BIST', sym }, ipo: { name: it.name, when: it.when, price: px, link: it.link }, history: [{ id: uid(), amount: cost, note: `Halka arz: ${lot} lot × ${money(px, { mask: false })}`, date: todayISO() }] });
        Store.save(); api.close(); refresh(); Prices.refresh({ force: true }).then(() => refresh()); toast('Halka arz portföyüne eklendi', { icon: 'rocket' });
      });
    },
  });
}
/* ---------- Kart ekstresi önerileri ---------- */
function matchCard(sg) {
  const cards = S().cards || [];
  return cards.find((c) => c.bank === sg.bank && sg.last4 && c.last4 === sg.last4) || (cards.filter((c) => c.bank === sg.bank).length === 1 ? cards.find((c) => c.bank === sg.bank) : null);
}
function openCardSuggest() {
  const list = S().cardSuggest || []; if (!list.length) return;
  list.forEach((x) => (x.asked = true)); Store.save();
  openSheet({
    title: 'Kart ekstresi bulundu',
    body: `<div class="tiny">SMS ya da banka bildiriminden kredi kartı ekstresi yakalandı. İstersen kartına ekleyeyim; son ödeme gününden önce sana hatırlatırım.</div>
      <div class="sg-list">${list.map((sg) => { const m = matchCard(sg); const b = bankById(sg.bank); return `<div class="sg" data-id="${sg.id}">
        <div class="sg-top">${bankBadge(sg.bank, 40)}<div class="mid"><b>${m ? esc(m.name || b.name) : esc(b.name)}${sg.last4 ? ` •••• ${esc(sg.last4)}` : ''}</b><span>${m ? 'Kayıtlı kartın güncellenecek' : 'Yeni kart olarak eklenecek'}</span></div></div>
        <div class="sg-kpi">${sg.total ? `<div><span>Dönem borcu</span><b class="num">${money(sg.total, { mask: false })}</b></div>` : ''}${sg.min ? `<div><span>Asgari</span><b class="num">${money(sg.min, { mask: false })}</b></div>` : ''}${sg.dueISO ? `<div><span>Son ödeme</span><b>${dayLabel(sg.dueISO)}</b></div>` : ''}</div>
        <div class="btn-row"><button class="btn ghost sm" data-sg="skip">Yoksay</button><button class="btn sm" data-sg="add">${icon('check')} ${m ? 'Güncelle' : 'Ekle'}</button></div></div>`; }).join('')}</div>`,
    mount(el, api) {
      el.addEventListener('click', (e) => {
        const b = e.target.closest('[data-sg]'); if (!b) return;
        const box = b.closest('[data-id]'); const sg = S().cardSuggest.find((x) => x.id === box.dataset.id); if (!sg) return;
        if (b.dataset.sg === 'add') {
          let c = matchCard(sg);
          if (!c) { c = { id: uid(), bank: sg.bank, name: bankById(sg.bank).name, last4: sg.last4 || '', limit: 0, current: 0, statement: 0, paid: 0, minRate: 0, minPay: 0, cutDay: 0, dueDay: 0, history: [] }; S().cards.push(c); }
          if (sg.total) { c.statement = sg.total; c.current = Math.max(Number(c.current) || 0, sg.total); }
          if (sg.min) { c.minPay = sg.min; }
          if (sg.dueDay) c.dueDay = sg.dueDay;
          c.paid = 0; (c.history = c.history || []).push({ id: uid(), amount: sg.total || sg.min, note: 'Ekstre (otomatik)', date: todayISO(), sig: `${sg.total}|${sg.min}|${sg.dueISO}` });
          toast('Kart güncellendi', { icon: 'card' });
        }
        S().cardSuggest = S().cardSuggest.filter((x) => x.id !== sg.id); Store.save();
        box.style.transition = 'opacity .3s, transform .3s'; box.style.opacity = 0; box.style.transform = 'scale(.96)';
        setTimeout(() => { box.remove(); if (!S().cardSuggest.length) api.close(); refresh(); }, 300);
      });
    },
  });
}
/* ---------- Kart son ödeme hatırlatmaları (7, 3, 1 gün önce ve son gün) ---------- */
let remT;
function syncCardReminders() {
  clearTimeout(remT);
  remT = setTimeout(async () => {
    const A = Native.isNative() && Native.akis(); if (!A) return;
    const items = [];
    if (S().settings.cardReminders !== false) {
      (S().cards || []).forEach((c, i) => {
        const n = nextDue(c); if (!n) return;
        const min = cardMinimum(c), rest = Math.max(0, (Number(c.statement) || 0) - (Number(c.paid) || 0));
        if (min <= 0 && rest <= 0) return;
        // Kısa ve tek satıra sığan metinler: başlık durumu, gövde kartı ve tutarı söyler
        const nm = (c.name || bankById(c.bank).short).slice(0, 14);
        const amt = min ? `Asgari ${money(min, { mask: false, short: true })}` : `Borç ${money(rest, { mask: false, short: true })}`;
        const day = `${n.date.getDate()} ${MONTHS_S[n.date.getMonth()]}`;
        [[7, 10, 'Kart ödemesi: 7 gün kaldı'], [3, 10, 'Kart ödemesi: 3 gün kaldı'], [1, 19, 'Kart ödemesi yarın'], [0, 9.5, 'Kart ödemesi bugün']].forEach(([d, h, title], k) => {
          const at = new Date(n.date); at.setDate(at.getDate() - d); at.setHours(Math.floor(h), (h % 1) * 60, 0, 0);
          if (at.getTime() > Date.now()) items.push({ id: 9200 + i * 4 + k, at: at.getTime(), title, body: `${nm} · ${amt}${d > 1 ? ' · ' + day : ''}` });
        });
      });
    }
    try { await A.setReminders({ items }); } catch (e) { /* eski sürüm */ }
  }, 800);
}
/* Açılış ekranı: Hoş geldiniz (Betül için: Seni seviyorum.) + kısa kullanım ipucu */
function showSplash() {
  return new Promise((done) => {
    const el = document.createElement('div'); el.id = 'splash';
    const betul = isBetul(); const name = displayName();
    el.innerHTML = `<div class="sp-in">
      <div class="sp-logo">${betul ? '<span class="sp-heart">🤍</span>' : icon('trend')}</div>
      <h1>${betul ? 'Seni seviyorum.' : 'Hoş geldiniz'}</h1>
      ${name && !betul ? `<p class="sp-name">${esc(name)}</p>` : ''}
      <div class="sp-tip">${icon('bell')}<span>En doğru takip için bankanın <b>harcama ve gelir SMS'lerini</b> ve <b>uygulama bildirimlerini</b> açık tut; Akış hareketlerini kendisi kaydeder.</span></div>
    </div>`;
    $('#app').appendChild(el);
    let gone = false;
    const hide = () => { if (gone) return; gone = true; el.classList.add('out'); setTimeout(() => { el.remove(); done(); }, 520); };
    el.addEventListener('click', hide);
    setTimeout(hide, 2800);
  });
}
/* İlk kurulumda: verilerin kendiliğinden gelmesi için bankadan bildirim/SMS açma rehberi */
function openBankGuide(next) {
  openSheet({
    title: 'Hareketlerin kendiliğinden gelsin',
    body: `<div class="tiny">Akış harcamalarını ve gelirlerini bankanın mesajlarından okur. En tutarlı kullanım için bunları aç:</div>
      <div class="guide">
        <div class="g-step"><span class="g-n">1</span><div><b>Banka uygulamasında bildirimler</b><span>Banka uygulaması → Ayarlar → Bildirimler: <i>harcama, para girişi ve para çıkışı</i> bildirimlerini aç.</span></div></div>
        <div class="g-step"><span class="g-n">2</span><div><b>Bankadan SMS bilgilendirmesi</b><span>Kart harcaması, havale/EFT ve maaş SMS'lerinin açık olduğundan emin ol (bankanın uygulamasından ya da müşteri hizmetlerinden).</span></div></div>
        <div class="g-step"><span class="g-n">3</span><div><b>Akış'a izin ver</b><span>Sonraki adımda SMS'leri ve bildirimleri okuma izni ver. Verilerin telefondan çıkmaz.</span></div></div>
      </div>
      <div class="note-box">Akış yalnızca <b>bundan sonra</b> gelen mesajları kaydeder; eski mesajlardan geriye dönük hesap çıkarmaz.</div>
      <button class="btn" data-s="go">Anladım, devam ${icon('chevR')}</button>`,
    mount(el, api) { el.addEventListener('click', (e) => { if (e.target.closest('[data-s=go]')) { api.close(); if (next) setTimeout(next, 420); } }); },
  });
}
/* Uygulamayı sıfırla: tüm veriler, zamanlanmış bildirimler ve alarmlar silinir; kurulum baştan başlar */
async function resetApp() {
  const A = Native.isNative() && Native.akis();
  if (A) { try { await A.setReminders({ items: [] }); await A.setDaily({ items: [] }); await A.syncAlerts({ alerts: [] }); await A.setIpoWatch({ on: false }); } catch (e) {} }
  Store.reset();
  setTimeout(() => location.reload(), 250);
}
/* Ana sayfa göstergesi: bu ayın geleni/gideni + alacaklar + borçlar → gerçek durum */
function statusGauge(m, recv, debt) {
  if (!recv && !debt) return '';
  const plus = m.inc + recv, minus = m.out + debt, tot = plus + minus || 1;
  const real = plus - minus;
  return `<div class="gauge">
    <div class="g-head"><span>Borç ve alacak dahil durumun</span><b class="num ${real >= 0 ? 'up' : 'down'}">${money(real, { sign: true })}</b></div>
    <div class="g-bar"><i class="g-in" style="flex:${m.inc}"></i><i class="g-recv" style="flex:${recv}"></i><i class="g-out" style="flex:${m.out}"></i><i class="g-debt" style="flex:${debt}"></i></div>
    <div class="g-lg">
      <span><i class="g-in"></i>Gelen ${money(m.inc, { short: true })}</span>
      <span><i class="g-recv"></i>Alacak ${money(recv, { short: true })}</span>
      <span><i class="g-out"></i>Giden ${money(m.out, { short: true })}</span>
      <span><i class="g-debt"></i>Borç ${money(debt, { short: true })}</span>
    </div>
    <div class="tiny">${real >= 0 ? `Alacaklarını alıp borçlarını kapatsan elinde <b class="up">${money(real, { short: true })}</b> kalır.` : `Borçların, bu ayın kazancı ve alacaklarından <b class="down">${money(-real, { short: true })}</b> fazla.`}</div>
  </div>`;
}
/* Part-time: aylık tahmini gelir */
function hourlyText(p) {
  const h = (Number(p.hoursPerDay) || 0) * (Number(p.daysPerWeek) || 0) * 52 / 12;
  const m = (Number(p.hourly) || 0) * h;
  return h ? `Ayda ≈ <b>${Math.round(h)} saat</b> · aylık gelir ≈ <b>${money(m, { mask: false })}</b>` : 'Saat ücretini, günlük saatini ve haftalık gün sayını gir.';
}
/* ---------- Borç kapanış simülasyonu ---------- */
function debtSimP() {
  const p = simP();
  if (!p.debtSim) {
    const cards = S().cards || [];
    p.debtSim = { amount: Math.round(Calc.debtTotal()), rate: 0, pay: Math.round(cards.reduce((a, c) => a + cardMinimum(c), 0)) };
  }
  return p.debtSim;
}
function dsimField(label, key, unit, val) {
  return `<div class="field"><label>${label}</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-dsim="${key}" value="${numInput(val)}" placeholder="0"><em>${unit}</em></div></div>`;
}
function renderDebtSim() {
  const box = $('#debtres'); if (!box) return;
  const d = debtSimP(); const r = debtPayoff(d.amount, d.rate, d.pay);
  if (!(d.amount > 0)) { box.innerHTML = '<div class="tiny">Borç tutarını gir.</div>'; return; }
  if (!(d.pay > 0)) { box.innerHTML = '<div class="tiny">Her ay ne kadar ödeyeceğini gir.</div>'; return; }
  if (r.never) { box.innerHTML = `<div class="warn-box">${icon('info')} Bu ödemeyle borç hiç bitmez: aylık faiz ${money(r.minPay, { mask: false })}. Her ay bundan fazlasını ödemelisin.</div>`; return; }
  const end = new Date(); end.setMonth(end.getMonth() + r.months);
  const yrs = Math.floor(r.months / 12), mos = r.months % 12;
  box.innerHTML = `<div class="debt-res">
      <div class="dr-big"><span>Borcun biter</span><b>${yrs ? yrs + ' yıl ' : ''}${mos ? mos + ' ay' : ''}${!yrs && !mos ? 'bu ay' : ''}</b><small>${MONTHS[end.getMonth()]} ${end.getFullYear()}</small></div>
      <div class="kpis"><div class="kpi"><div class="t">Toplam ödeyeceğin</div><div class="v num">${money(r.paid, { mask: false, short: true })}</div></div>
        <div class="kpi"><div class="t">Faize giden</div><div class="v num ${r.interest > 0 ? 'down' : ''}">${money(r.interest, { mask: false, short: true })}</div></div></div>
      <div id="debtchart"></div></div>`;
  const step = Math.max(1, Math.ceil(r.rows.length / 24));
  const pts = r.rows.filter((_, i) => i % step === 0 || i === r.rows.length - 1);
  const labels = pts.map((_, i) => { const t = new Date(); t.setMonth(t.getMonth() + Math.min(i * step, r.rows.length - 1)); return `${MONTHS_S[t.getMonth()]} ${String(t.getFullYear()).slice(2)}`; });
  Charts.line($('#debtchart'), { labels, series: [{ name: 'Kalan borç', color: '#f59e0b', values: pts, area: true, width: 2.6 }], height: 150 });
}
/* Fon getirisi enflasyonu yendi mi? Dönemsel getiriler (TEFAS) ve senin yatırımın, girilen yıllık enflasyonla karşılaştırılır */
async function fundInflation(box, a) {
  if (!box) return;
  let F = null;
  try { const L = await Prices.fundList(); F = L.find((x) => x.c === String(a.track.sym).toUpperCase()); } catch (e) { /* liste yoksa yalnızca kendi yatırımını göster */ }
  const draw = () => {
    const I = Number(S().settings.inflRef) || 0;
    const now = new Date(); const ytdM = now.getMonth() + now.getDate() / 30;
    const infl = (months) => (Math.pow(1 + I / 100, months / 12) - 1) * 100;
    const row = (label, f, months) => {
      if (f == null || isNaN(f)) return '';
      const inf = infl(months); const real = ((1 + f / 100) / (1 + inf / 100) - 1) * 100;
      return `<tr><td>${label}</td><td class="${f >= 0 ? 'up' : 'down'}">%${Number(f).toLocaleString('tr-TR', { maximumFractionDigits: 1 })}</td><td>${I ? '%' + inf.toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : '—'}</td><td class="${I ? (real >= 0 ? 'up' : 'down') : ''}">${I ? '%' + (real >= 0 ? '+' : '') + real.toLocaleString('tr-TR', { maximumFractionDigits: 1 }) : '—'}</td></tr>`;
    };
    let mine = '';
    if (a.cost > 0) {
      const days = a.buyDate ? Math.max(1, (Date.now() - new Date(a.buyDate).getTime()) / 864e5) : 0;
      const f = (a.value / a.cost - 1) * 100;
      if (days) {
        const inf = infl(days / 30.44); const keep = a.cost * (1 + inf / 100); const diff = a.value - keep;
        mine = `<div class="infl-mine ${I ? (diff >= 0 ? 'win' : 'lose') : ''}">
          <b>Senin yatırımın · ${Math.round(days)} gün</b>
          <span>Getiri <b class="${f >= 0 ? 'up' : 'down'}">%${f.toLocaleString('tr-TR', { maximumFractionDigits: 1 })}</b>${I ? ` · Enflasyon %${inf.toLocaleString('tr-TR', { maximumFractionDigits: 1 })}` : ''}</span>
          ${I ? `<span>${diff >= 0 ? 'Enflasyonu yendin' : 'Enflasyonun gerisinde kaldın'}: <b class="${diff >= 0 ? 'up' : 'down'}">${money(diff, { mask: false, sign: true })}</b> (alım gücü olarak)</span>` : ''}
        </div>`;
      }
    }
    box.innerHTML = `<div class="section-t">Enflasyona karşı</div>
      <div class="field"><label>Karşılaştırma için yıllık enflasyon</label><div class="input-unit"><input class="inp num" inputmode="decimal" data-infl value="${I ? numInput(I) : ''}" placeholder="Örn. TÜFE yıllık"><em>%</em></div></div>
      ${mine}
      ${F ? `<table class="table infl-t"><tr><th>Dönem</th><th>Fon</th><th>Enflasyon</th><th>Reel</th></tr>
        ${row('1 ay', F.a1, 1)}${row('3 ay', F.a3, 3)}${row('6 ay', F.a6, 6)}${row('Yılbaşından', F.yb, ytdM)}${row('1 yıl', F.y, 12)}</table>
        <div class="tiny">Reel = fon getirisinin enflasyondan arındırılmış hali. Artıysa fon enflasyonu yenmiş demektir. Fon getirileri TEFAS'tan.</div>`
        : '<div class="tiny">Fonun dönemsel getirileri alınamadı (telefonda internet gerekir).</div>'}`;
  };
  draw();
  box.addEventListener('input', (e) => {
    if (!e.target.hasAttribute('data-infl')) return;
    S().settings.inflRef = parseNum(e.target.value); Store.save();
    clearTimeout(box._t); box._t = setTimeout(() => { const pos = e.target.selectionStart; draw(); const inp = box.querySelector('[data-infl]'); if (inp) { inp.focus(); try { inp.setSelectionRange(pos, pos); } catch (er) {} } }, 500);
  });
}
/* ====================================================================== */
/*  OLAY YÖNETİMİ                                                          */
/* ====================================================================== */
const ACTIONS = {
  tab: (el) => go(el.dataset.tab),
  settings: openSettings,
  toggleHide: () => { S().settings.hide = !S().settings.hide; Store.save(); refresh(); },
  newTx: (el) => openTxSheet(null, { type: el.dataset.type }),
  editTx: (el) => { const t = S().tx.find((x) => x.id === el.dataset.id); if (t) openTxSheet(t); },
  sms: openSmsSheet,
  pending: openPendingSheet,
  debt: () => { if (isBetul()) openBetulDebt(); else openDebtChooser(); },
  cardOpen: (el) => { const c = S().cards.find((x) => x.id === el.dataset.id); if (c) openCardDetail(c); },
  layout: openLayoutSheet,
  debts: openDebtsList,
  addCard: () => openCardForm(),
  recvList: openRecvList,
  recvAdd: () => openRecvForm(),
  recvOpen: (el) => { const x = S().receivables.find((d) => d.id === el.dataset.id); if (x) openRecvDetail(x); },
  debtOpen: (el) => { const x = S().debts.find((d) => d.id === el.dataset.id); if (x) openDebtDetail(x); },
  besEdit: openBesForm,
  simSettings: openSimSettings,
  refreshPrices: async (el) => {
    el.classList.add('spin');
    const r = await Prices.refresh({ force: true }); el.classList.remove('spin');
    refresh(); afterPrices();
    toast(r.errors && r.errors.length ? r.errors[0] : 'Fiyatlar güncellendi', { tone: r.errors && r.errors.length ? 'error' : 'ok', icon: 'live' });
  },
  analysis: () => { UI.txMode = 'analysis'; UI.month = ymNow(); go('tx'); },
  txMode: (el) => { if (UI.txMode === el.dataset.v) return; segSet(el); UI.txMode = el.dataset.v; refreshBody(); },
  month: (el) => { UI.month = ymAdd(UI.month, +el.dataset.d); if (UI.month > ymNow()) UI.month = ymNow(); refresh(); const b = $('[data-body]', currentPage()); b && b.classList.add('fade-in'); },
  filter: (el) => { UI.filter = el.dataset.v; $$('.chip', el.parentElement).forEach((c) => c.classList.toggle('on', c === el)); $('#txlist').innerHTML = txListHTML(); $('#txlist').classList.remove('fade-in'); void $('#txlist').offsetWidth; $('#txlist').classList.add('fade-in'); },
  assetMode: (el) => { if (UI.assetMode === el.dataset.v) return; segSet(el); UI.assetMode = el.dataset.v; refreshBody(); },
  newAsset: (el) => openAssetForm(null, el.dataset.kind || (UI.assetMode === 'investment' ? 'investment' : 'savings')),
  invMode: (el) => { if ((UI.invMode || 'port') === el.dataset.v) return; segSet(el); UI.invMode = el.dataset.v; refreshBody(); },
  ipoOpen: (el) => openIpoDetail(el.dataset.link),
  cardSuggest: openCardSuggest,
  invAdd: (el) => openAssetForm(null, 'investment', false, el.dataset.instr),
  asset: (el) => { const a = S().assets.find((x) => x.id === el.dataset.id); if (a) openAssetDetail(a); },
  simIncomeMode: (el) => { const p = simP(); if ((p.incomeMode || 'fixed') === el.dataset.v) return; segSet(el); p.incomeMode = el.dataset.v; Store.save(); setTimeout(refresh, 250); },
  simRaiseType: (el) => { const p = simP(); if ((p.raiseType || 'pct') === el.dataset.v) return; segSet(el); p.raiseType = el.dataset.v; Store.save(); setTimeout(refresh, 250); },
  simInvestMode: (el) => { const p = simP(); if ((p.investMode || 'pct') === el.dataset.v) return; segSet(el); p.investMode = el.dataset.v; Store.save(); setTimeout(refresh, 250); },
  debtSimFill: () => { const p = simP(); p.debtSim = null; debtSimP(); Store.save(); refresh(); toast('Borçların ve kartlarının asgarisi dolduruldu'); },
  simH: (el) => { simP().horizon = +el.dataset.v; Store.save(); $$('[data-action=simH]').forEach((c) => { const on = c === el; c.style.background = on ? '#fff' : ''; c.style.color = on ? 'var(--navy-900)' : ''; }); renderSimResults(true); },
  simFill: () => {
    const avg = Calc.averages(3);
    if (!avg) { toast('Önce birkaç aylık hareket gerekli', { tone: 'error' }); return; }
    const p = simP();
    p.salary = Math.round(avg.salary || avg.income);
    p.expenses = avg.expenses.slice(0, 10).map((e) => ({ id: uid(), name: e.name, amount: e.amount }));
    Store.save(); refresh(); toast(`Son ${avg.months} ayın ortalaması kullanıldı`);
  },
  simAddExp: () => { const p = simP(); const e = { id: uid(), name: '', amount: 0 }; p.expenses.push(e); $('#explist').insertAdjacentHTML('beforeend', expRow(e)); $('#explist').lastElementChild.classList.add('fade-in'); $('#explist').lastElementChild.querySelector('input').focus(); Store.save(); },
  simDelExp: (el) => { const p = simP(); p.expenses = p.expenses.filter((e) => e.id !== el.dataset.id); el.closest('.exp-row').remove(); simChanged(); },
  simAddEvent: () => { const p = simP(); p.events.push({ id: uid(), label: '', ym: ymAdd(ymNow(), 6), amount: 0 }); Store.save(); refresh(); },
  simDelEv: (el) => { const p = simP(); p.events = p.events.filter((e) => e.id !== el.dataset.id); Store.save(); refresh(); },
  simTable: (el) => { UI.simTable = !UI.simTable; el.classList.toggle('open', UI.simTable); el.nextElementSibling.classList.toggle('open', UI.simTable); },
  simReset: async () => { if (await confirmSheet('Simülasyon varsayımların sıfırlanacak.', 'Sıfırla', false)) { S().sim = simDefaults(); Store.save(); refresh(); } },
};

/* Uzun basınca küçük ipucu (yazısız tuşlar için) */
let hintT = null, hintShown = false;
document.addEventListener('pointerdown', (e) => {
  const el = e.target.closest('[data-hint]'); if (!el) return;
  hintShown = false; clearTimeout(hintT);
  hintT = setTimeout(() => {
    hintShown = true;
    const r = el.getBoundingClientRect(), app = $('#app').getBoundingClientRect();
    const h = $('#hint'); h.textContent = el.dataset.hint;
    h.style.left = (r.left - app.left + r.width / 2) + 'px'; h.style.top = (r.top - app.top - 8) + 'px';
    h.classList.add('show'); if (navigator.vibrate) navigator.vibrate(12);
  }, 420);
});
['pointerup', 'pointercancel', 'pointerleave'].forEach((ev) => document.addEventListener(ev, () => { clearTimeout(hintT); setTimeout(() => $('#hint') && $('#hint').classList.remove('show'), 700); }, true));
document.addEventListener('contextmenu', (e) => { if (e.target.closest('[data-hint]')) e.preventDefault(); });

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-action]');
  if (!el || el.closest('.sheet')) return;
  if (hintShown && el.dataset.hint) { hintShown = false; return; }
  const fn = ACTIONS[el.dataset.action]; if (fn) fn(el, e);
});
document.addEventListener('input', (e) => {
  const t = e.target;
  if (t.closest('.sheet')) return;
  if (t.dataset.input === 'q') { UI.q = t.value; $('#txlist').innerHTML = txListHTML(); return; }
  const p = S().sim;
  if (t.dataset.dsim && p) { debtSimP()[t.dataset.dsim] = parseNum(t.value); Store.save(); clearTimeout(dsimT); dsimT = setTimeout(renderDebtSim, 160); return; }
  if (t.dataset.sim && p) {
    const k = t.dataset.sim;
    if (k === 'autoStart') { p.autoStart = t.checked; $('#startFields').style.display = t.checked ? 'none' : ''; }
    else if (k === 'raiseMode') p.raiseMode = t.value;
    else { p[k] = parseNum(t.value); if (k === 'investRatio') $('#ratioLbl').textContent = pct(p[k], 0); }
    simChanged(); return;
  }
  const er = t.closest('[data-exp]');
  if (er && p) { const x = p.expenses.find((e) => e.id === er.dataset.exp); if (x) { x[t.dataset.expf] = t.dataset.expf === 'amount' ? parseNum(t.value) : t.value; simChanged(); } return; }
  const ev = t.closest('[data-ev]');
  if (ev && p) { const x = p.events.find((e) => e.id === ev.dataset.ev); if (x) { x[t.dataset.evf] = t.dataset.evf === 'amount' ? parseNum(t.value) : t.value; simChanged(); } }
});
document.addEventListener('change', (e) => { if (e.target.hasAttribute && e.target.hasAttribute('data-ipo-notify')) { S().settings.ipoNotify = e.target.checked; Store.save(); if (Native.isNative()) Native.akis().setIpoWatch({ on: e.target.checked }).catch(() => {}); toast(e.target.checked ? 'Yeni halka arzlarda haber vereceğim' : 'Halka arz bildirimi kapalı', { icon: 'rocket' }); return; } if (e.target.dataset.evf === 'ym') e.target.dispatchEvent(new Event('input', { bubbles: true })); });

/* ---------- Senkronizasyon: SMS + bildirim + fiyatlar + alarmlar ---------- */
let lastSync = 0;
function afterPrices() {
  if (Native.isNative()) { const p = Native.akis(); if (p) p.checkNow().catch(() => {}); return; }
  if (!S().settings.priceAlerts) return;
  for (const f of Prices.checkAlertsInApp()) {
    const u = f.a.alert.basis === 'total' ? 'Toplam değerin' : `1 ${f.a.unit}`;
    toast(`${u} şu an ${money(f.v, { mask: false })}`, { title: `${f.a.name} ${f.dir === 'below' ? '▼ stop seviyesinin altında' : '▲ hedefine ulaştı'}`, icon: 'bell', tone: f.dir === 'below' ? 'error' : 'ok', ms: 5000 });
  }
}
async function syncSources(force = false) {
  if (!S().onboarded) return;
  if (!force && Date.now() - lastSync < 30000) return;
  lastSync = Date.now();
  let changed = false;
  if (Native.isNative()) {
    const { n } = await scanAllSources();
    if (n) { changed = true; toast(S().settings.smsAutoApprove ? `${n} yeni hareket eklendi` : `${n} yeni hareket onay bekliyor`, { icon: 'sync', title: 'Banka hareketleri' }); }
  }
  try { const r = await Prices.refresh(); if (r.updated) changed = true; afterPrices(); } catch (e) {}
  if (changed) refresh();
}
function init() {
  applyTheme();
  const L = S().settings.layout || {}; UI.txMode = L.txDefault || 'list'; UI.assetMode = L.assetsDefault || 'all';
  if (window.matchMedia) { const mq = matchMedia('(prefers-color-scheme: dark)'); const on = () => { applyTheme(); refresh(); }; mq.addEventListener ? mq.addEventListener('change', on) : mq.addListener(on); }
  $('#tabbar').innerHTML = [
    ['home', 'home', 'Ana Sayfa'], ['tx', 'list', 'Hareketler'], ['add', 'plus', ''], ['assets', 'wallet', 'Varlıklar'], ['sim', 'sim', 'Simülasyon'],
  ].map(([t, ic, l]) => t === 'add'
    ? `<div><button class="fab" data-action="tab" data-tab="add" aria-label="Yeni hareket">${icon(ic)}</button></div>`
    : `<button class="tab ${t === 'home' ? 'on' : ''}" data-action="tab" data-tab="${t}">${icon(ic)}<span>${l}</span></button>`).join('');
  render();
  const s0 = S().settings;
  // Geriye dönük tarama yok: takip, kurulumdan (ya da bu sürüme geçişten) itibaren başlar
  if (S().onboarded && !s0.trackSince) { s0.trackSince = s0.lastSmsScan || Date.now(); Store.save(); }
  const splash = showSplash();
  if (!S().onboarded) splash.then(() => setTimeout(openWelcome, 120));
  else {
    Promise.all([syncSources(true), splash]).then(async () => {
      syncCardReminders(); if (Native.isNative()) Native.akis().setIpoWatch({ on: S().settings.ipoNotify !== false }).catch(() => {});
      askOnOpen();
      if (!S().adCleanup && Native.isNative()) { const n = await cleanupAds(); if (n) { refresh(); toast(`Kampanya olan ${n} kayıt temizlendi`, { icon: 'flag', title: 'Kampanya filtresi' }); } }
      checkUpdates();
    });
    setupNotifications(); Prices.syncNative();
  }
  let tod = document.documentElement.dataset.tod;
  setInterval(() => { applyTheme(); if (document.documentElement.dataset.tod !== tod) { tod = document.documentElement.dataset.tod; refresh(); } }, 60e3);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    applyTheme(); if (permRefresh) permRefresh(); syncSources().then(askOnOpen);
  });
}
/* Uygulama açılınca: yeni yakalanan hareketleri (özellikle banka dışı uygulamalardan) ve kart ekstrelerini sor */
function askOnOpen() {
  if (sheets.length || !S().onboarded) return;
  const pend = S().pending || [];
  if (pend.some((p) => !p.asked)) { pend.forEach((p) => (p.asked = true)); Store.save(); openPendingSheet(); return; }
  if ((S().cardSuggest || []).some((x) => !x.asked)) openCardSuggest();
}
init();
