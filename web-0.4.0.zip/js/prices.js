/* Canlı fiyatlar ve yatırım alarmları */

const Prices = {
  async fetchJSON(url, ms = 9000) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error(r.status); return await r.json(); }
    finally { clearTimeout(t); }
  },

  /** Takip edilen tüm varlıkların birim fiyatlarını çeker ve değerlerini günceller */
  async refresh({ force = false } = {}) {
    const st = Store.state;
    const tracked = st.assets.filter((a) => a.track && a.track.src);
    if (!tracked.length) return { updated: 0 };
    if (!force && Date.now() - (st.pricesAt || 0) < 5 * 60e3) return { updated: 0, cached: true };
    const out = {}; const chg = {}; const errors = []; const jobs = [];
    const needTg = tracked.some((a) => a.track.src === 'tg');
    const cg = [...new Set(tracked.filter((a) => a.track.src === 'cg').map((a) => a.track.id))];
    const yh = [...new Set(tracked.filter((a) => a.track.src === 'yh').map((a) => String(a.track.sym || '').toUpperCase()).filter(Boolean))];
    const tf = [...new Set(tracked.filter((a) => a.track.src === 'tf').map((a) => String(a.track.sym || '').toUpperCase()).filter(Boolean))];
    for (const s of tf) jobs.push(this.fundPrice(s).then((x) => { out['tf:' + s] = x.p; chg['tf:' + s] = x.ch; }).catch(() => errors.push(`Fon ${s}: ${Native.isNative() ? 'alınamadı' : 'tarayıcıda engelli, telefonda güncellenir'}`)));
    if (needTg) jobs.push(this.fetchJSON('https://finans.truncgil.com/v4/today.json').then((j) => {
      for (const k in j) { const v = j[k]; if (v && typeof v === 'object') { const p = Number(v.Buying) || Number(v.Selling); if (p) { out['tg:' + k] = p; chg['tg:' + k] = Number(v.Change) || 0; } } }
    }).catch((e) => errors.push('Altın/döviz: ' + e.message)));
    if (cg.length) jobs.push(this.fetchJSON(`https://api.coingecko.com/api/v3/simple/price?ids=${cg.join(',')}&vs_currencies=try&include_24hr_change=true`).then((j) => {
      for (const id of cg) if (j[id] && j[id].try) { out['cg:' + id] = j[id].try; chg['cg:' + id] = Number(j[id].try_24h_change) || 0; }
    }).catch((e) => errors.push('Kripto: ' + e.message)));
    for (const s of yh) jobs.push(this.fetchJSON(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(s)}.IS?range=1d&interval=1d`).then((j) => {
      const meta = j.chart && j.chart.result && j.chart.result[0] && j.chart.result[0].meta; const p = meta && meta.regularMarketPrice; if (p) { out['yh:' + s] = p; const pc = meta.chartPreviousClose || meta.previousClose; if (pc) chg['yh:' + s] = ((p - pc) / pc) * 100; }
    }).catch(() => errors.push(`${s}: ${Native.isNative() ? 'alınamadı' : 'tarayıcıda engelli, telefonda güncellenir'}`)));
    await Promise.all(jobs);
    const now = Date.now(); let updated = 0;
    for (const k in out) st.prices[k] = { p: out[k], t: now, ch: chg[k] || 0 };
    for (const a of tracked) {
      const pr = st.prices[priceKey(a.track)];
      if (pr && a.qty > 0) { const v = Math.round(pr.p * a.qty * 100) / 100; if (v !== a.value) { a.value = v; updated++; } a.unitPrice = pr.p; a.priceAt = pr.t; }
    }
    if (Object.keys(out).length) st.pricesAt = now;
    Store.save();
    return { updated, errors };
  },

  /** Tek bir enstrümanın anlık birim fiyatı (₺) */
  async quote(track) {
    if (track.src === 'tg') {
      const j = await this.fetchJSON('https://finans.truncgil.com/v4/today.json');
      const v = j[track.id]; const p = v && (Number(v.Buying) || Number(v.Selling)); if (!p) throw new Error('fiyat yok'); return p;
    }
    if (track.src === 'tf') return (await this.fundPrice(track.sym)).p;
    if (track.src === 'cg') {
      const j = await this.fetchJSON(`https://api.coingecko.com/api/v3/simple/price?ids=${track.id}&vs_currencies=try`);
      if (!j[track.id]) throw new Error('fiyat yok'); return j[track.id].try;
    }
    const j = await this.fetchJSON(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(track.sym)}.IS?range=1d&interval=1d`);
    const p = j.chart && j.chart.result && j.chart.result[0] && j.chart.result[0].meta.regularMarketPrice; if (!p) throw new Error('fiyat yok'); return p;
  },

  /** Piyasa şeridi: gram altın, gümüş, dolar, euro, bitcoin (günlük değişimle) */
  MARKET: [['tg:GRA', 'Gram Altın'], ['tg:CEYREKALTIN', 'Çeyrek'], ['tg:GUMUS', 'Gümüş'], ['tg:USD', 'Dolar'], ['tg:EUR', 'Euro'], ['cg:bitcoin', 'Bitcoin']],
  async refreshMarket(force = false) {
    const st = Store.state;
    if (!force && Date.now() - (st.marketAt || 0) < 5 * 60e3) return false;
    const m = {};
    await Promise.all([
      this.fetchJSON('https://finans.truncgil.com/v4/today.json').then((j) => { for (const k of ['GRA', 'CEYREKALTIN', 'GUMUS', 'USD', 'EUR']) { const v = j[k]; if (v) m['tg:' + k] = { p: Number(v.Buying) || Number(v.Selling), ch: Number(v.Change) || 0 }; } }).catch(() => {}),
      this.fetchJSON('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=try&include_24hr_change=true').then((j) => { if (j.bitcoin) m['cg:bitcoin'] = { p: j.bitcoin.try, ch: Number(j.bitcoin.try_24h_change) || 0 }; }).catch(() => {}),
    ]);
    if (!Object.keys(m).length) return false;
    st.market = m; st.marketAt = Date.now(); Store.save(); return true;
  },
  change(a) { const pr = a.track && Store.state.prices[priceKey(a.track)]; return pr && pr.ch ? pr.ch : 0; },

  /* ---------- TEFAS fonları ---------- */
  async postJSON(url, body, ms = 12000) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
    try {
      const r = await fetch(url, { method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json', Accept: 'application/json, text/plain, */*' }, body: JSON.stringify(body) });
      if (!r.ok) throw new Error(r.status); return await r.json();
    } finally { clearTimeout(t); }
  },
  /** Fon fiyatı: son gün ve bir önceki güne göre değişim */
  async fundPrice(code, months = 1) {
    const j = await this.postJSON('https://www.tefas.gov.tr/api/funds/fonFiyatBilgiGetir', { fonKodu: String(code).toUpperCase(), dil: 'TR', periyod: months });
    const L = (j.resultList || []).filter((x) => x.fiyat > 0);
    if (!L.length) throw new Error('fon bulunamadı');
    const last = L[L.length - 1], prev = L[L.length - 2];
    return { p: last.fiyat, ch: prev ? ((last.fiyat - prev.fiyat) / prev.fiyat) * 100 : 0, date: last.tarih, name: last.fonUnvan, history: L };
  },
  /** Tüm fon listesi (kod + ad + tür), 24 saat önbellek */
  async fundList() {
    const st = Store.state;
    if (st.fundList && Date.now() - (st.fundListAt || 0) < 864e5) return st.fundList;
    const base = { dil: 'TR', kurucuKodu: null, sfonTurKod: null, fonTurAciklama: null, islem: 1, fonTurKod: null, fonGrubu: null, donemGetiri1a: '1', donemGetiri3a: '1', donemGetiri6a: '1', donemGetiri1y: '1', donemGetiriyb: '1', donemGetiri3y: '1', donemGetiri5y: '1', basTarih: null, bitTarih: null, calismaTipi: 2, getiriOrani: '1' };
    const all = [];
    for (const tip of ['YAT', 'EMK', 'BYF']) {
      try { const j = await this.postJSON('https://www.tefas.gov.tr/api/funds/fonGetiriBazliBilgiGetir', { ...base, fonTipi: tip }, 20000); for (const r of j.resultList || []) all.push({ c: r.fonKodu, n: r.fonUnvan, t: r.fonTurAciklama || '', k: tip, y: r.getiri1y }); } catch (e) { if (tip === 'YAT') throw e; }
    }
    st.fundList = all; st.fundListAt = Date.now(); Store.save(); return all;
  },

  /* ---------- Halka arz takvimi (halkarz.com) ---------- */
  async fetchText(url, ms = 15000) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
    try { const r = await fetch(url, { signal: ctl.signal }); if (!r.ok) throw new Error(r.status); return await r.text(); } finally { clearTimeout(t); }
  },
  async ipoList(force = false) {
    const st = Store.state;
    if (!force && st.ipo && Date.now() - (st.ipo.at || 0) < 3 * 3600e3) return st.ipo.list;
    const h = await this.fetchText('https://halkarz.com/');
    const dec = (s) => { const d = document.createElement('textarea'); d.innerHTML = s; return d.value; };
    const list = [...h.matchAll(/<article class="index-list">([\s\S]*?)<\/article>/g)].slice(0, 30).map((m) => {
      const a = m[1];
      const link = (a.match(/il-halka-arz-sirket"><a href="([^"]+)"/) || [])[1] || '';
      return {
        code: ((a.match(/il-bist-kod">\s*([^<]*?)\s*</) || [])[1] || '').trim(),
        name: dec((a.match(/il-halka-arz-sirket"><a href="[^"]+" title="([^"]+)"/) || [])[1] || ''),
        when: ((a.match(/datetime="([^"]*)"/) || [])[1] || '').trim(),
        logo: (a.match(/<img src="([^"]+)"/) || [])[1] || '',
        link,
      };
    }).filter((x) => x.link);
    if (!list.length) throw new Error('liste boş');
    st.ipo = { list, at: Date.now() }; Store.save(); return list;
  },
  async ipoDetail(link) {
    const h = await this.fetchText(link);
    const txt = h.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, '\n').replace(/&nbsp;/g, ' ').split('\n').map((s) => s.trim()).filter(Boolean);
    const val = (label) => { const i = txt.findIndex((s) => s.startsWith(label)); return i > -1 ? (txt[i].split(':').slice(1).join(':').trim() || txt[i + 1] || '') : ''; };
    const d = {
      when: val('Halka Arz Tarihi'), price: val('Halka Arz Fiyatı'), method: val('Dağıtım Yöntemi'), lots: val('Pay'),
      broker: val('Aracı Kurum'), code: val('Bist Kodu'), market: val('Pazar'), firstTrade: val('Bist İlk İşlem Tarihi'),
    };
    d.priceNum = parseNum((d.price.match(/[\d.,]+/) || [''])[0]);
    return d;
  },

  unitPrice(a) { const pr = a.track && Store.state.prices[priceKey(a.track)]; return pr ? pr.p : a.qty ? a.value / a.qty : 0; },
  alertValue(a) { return a.alert && a.alert.basis === 'total' ? a.value : this.unitPrice(a); },

  /** Tarayıcıda (önizleme) alarm kontrolü — telefonda bu iş arka planda yerel servisle yapılır */
  checkAlertsInApp() {
    const fired = [];
    for (const a of Store.state.assets) {
      const al = a.alert; if (!al || (!al.below && !al.above)) continue;
      const v = this.alertValue(a); if (!v) continue;
      if (al.below && v <= al.below && !al.firedBelow) { al.firedBelow = true; fired.push({ a, dir: 'below', v }); }
      if (al.below && v > al.below * 1.01) al.firedBelow = false;
      if (al.above && v >= al.above && !al.firedAbove) { al.firedAbove = true; fired.push({ a, dir: 'above', v }); }
      if (al.above && v < al.above * 0.99) al.firedAbove = false;
    }
    if (fired.length) Store.save();
    return fired;
  },

  /** Alarmları Android arka plan servisine bildirir */
  async syncNative() {
    if (!Native.isNative()) return;
    const p = Native.akis(); if (!p) return;
    const alerts = Store.state.settings.priceAlerts ? Store.state.assets.filter((a) => a.track && a.alert && (a.alert.below || a.alert.above)).map((a) => ({
      id: a.id, name: a.name, src: a.track.src, key: a.track.src === 'yh' || a.track.src === 'tf' ? String(a.track.sym || '').toUpperCase() : a.track.id,
      qty: a.qty || 0, unit: a.unit || '', basis: a.alert.basis || 'unit', below: a.alert.below || 0, above: a.alert.above || 0,
    })) : [];
    try { await p.syncAlerts({ alerts }); if (alerts.length) await p.checkNow(); } catch (e) { /* sessiz */ }
  },
};
