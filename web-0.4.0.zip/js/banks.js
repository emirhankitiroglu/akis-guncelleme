/* Türkiye'deki bilinen bankalar: marka rengiyle rozet. İstersen kendi logo görselini yükleyebilirsin. */
const BANKS = [
  { id: 'isbank', name: 'İş Bankası', short: 'İŞ', bg: '#0b4ea2', fg: '#fff', bg2: '#0a2f6e' },
  { id: 'garanti', name: 'Garanti BBVA', short: 'G', bg: '#00875a', fg: '#fff', bg2: '#004d33' },
  { id: 'akbank', name: 'Akbank', short: 'A', bg: '#e30613', fg: '#fff', bg2: '#8f0410' },
  { id: 'yapikredi', name: 'Yapı Kredi', short: 'YK', bg: '#004990', fg: '#fff', bg2: '#0b1f4d' },
  { id: 'ziraat', name: 'Ziraat Bankası', short: 'Z', bg: '#e30a17', fg: '#fff', bg2: '#7d0710' },
  { id: 'vakifbank', name: 'VakıfBank', short: 'V', bg: '#fdb913', fg: '#1d1d1b', bg2: '#c98a00' },
  { id: 'halkbank', name: 'Halkbank', short: 'H', bg: '#005ca9', fg: '#fff', bg2: '#003566' },
  { id: 'qnb', name: 'QNB', short: 'QNB', bg: '#5c2d91', fg: '#fff', bg2: '#33175a' },
  { id: 'enpara', name: 'Enpara.com', short: 'e', bg: '#7b2482', fg: '#fff', bg2: '#46104b' },
  { id: 'denizbank', name: 'DenizBank', short: 'D', bg: '#0068b4', fg: '#fff', bg2: '#003a66' },
  { id: 'teb', name: 'TEB', short: 'TEB', bg: '#00a651', fg: '#fff', bg2: '#006631' },
  { id: 'ing', name: 'ING', short: 'ING', bg: '#ff6200', fg: '#fff', bg2: '#b34500' },
  { id: 'kuveytturk', name: 'Kuveyt Türk', short: 'KT', bg: '#00843d', fg: '#fff', bg2: '#004d24' },
  { id: 'turkiyefinans', name: 'Türkiye Finans', short: 'TF', bg: '#00a19a', fg: '#fff', bg2: '#005f5b' },
  { id: 'albaraka', name: 'Albaraka', short: 'AL', bg: '#b5893a', fg: '#fff', bg2: '#6e5222' },
  { id: 'vakifkatilim', name: 'Vakıf Katılım', short: 'VK', bg: '#f2a900', fg: '#1d1d1b', bg2: '#a87500' },
  { id: 'ziraatkatilim', name: 'Ziraat Katılım', short: 'ZK', bg: '#c8102e', fg: '#fff', bg2: '#73091a' },
  { id: 'emlakkatilim', name: 'Emlak Katılım', short: 'EK', bg: '#00539f', fg: '#fff', bg2: '#002f5c' },
  { id: 'fibabanka', name: 'Fibabanka', short: 'F', bg: '#e4002b', fg: '#fff', bg2: '#80001a' },
  { id: 'sekerbank', name: 'Şekerbank', short: 'Ş', bg: '#009fe3', fg: '#fff', bg2: '#005f8a' },
  { id: 'odeabank', name: 'Odeabank', short: 'O', bg: '#6c2c91', fg: '#fff', bg2: '#3c1852' },
  { id: 'hsbc', name: 'HSBC', short: 'HSBC', bg: '#db0011', fg: '#fff', bg2: '#7a000a' },
  { id: 'anadolubank', name: 'Anadolubank', short: 'AB', bg: '#00529b', fg: '#fff', bg2: '#002e58' },
  { id: 'cepteteb', name: 'CEPTETEB', short: 'C', bg: '#00b26b', fg: '#fff', bg2: '#006b40' },
  { id: 'papara', name: 'Papara', short: 'P', bg: '#1c1c1c', fg: '#fff', bg2: '#000' },
  { id: 'other', name: 'Diğer', short: '₺', bg: '#64748b', fg: '#fff', bg2: '#334155' },
];
const bankById = (id) => BANKS.find((b) => b.id === id) || BANKS[BANKS.length - 1];

/** Banka rozeti: kullanıcının yüklediği logo varsa onu, yoksa marka renginde kısaltmayı gösterir */
function bankBadge(id, size = 40) {
  const b = bankById(id);
  const logo = (Store.state.bankLogos || {})[b.id];
  const fs = Math.round(size * (b.short.length > 2 ? 0.3 : b.short.length === 2 ? 0.38 : 0.48));
  return logo
    ? `<span class="bank-badge" style="width:${size}px;height:${size}px;background:#fff"><img src="${logo}" alt="${esc(b.name)}"></span>`
    : `<span class="bank-badge" style="width:${size}px;height:${size}px;background:${b.bg};color:${b.fg};font-size:${fs}px">${b.short}</span>`;
}
function bankPicker(active) {
  return `<div class="bank-grid">${BANKS.map((b) => `<button class="bank-opt ${b.id === active ? 'on' : ''}" data-bank="${b.id}">${bankBadge(b.id, 38)}<span>${b.name}</span></button>`).join('')}</div>`;
}
/** Seçilen görseli 128 px'e küçültüp veri adresine çevirir */
function readLogoFile(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onerror = rej;
    r.onload = () => {
      const img = new Image();
      img.onerror = rej;
      img.onload = () => {
        const s = 128, c = document.createElement('canvas'); c.width = s; c.height = s;
        const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, s, s);
        const k = Math.min(s / img.width, s / img.height), w = img.width * k, h = img.height * k;
        g.drawImage(img, (s - w) / 2, (s - h) / 2, w, h);
        res(c.toDataURL('image/png'));
      };
      img.src = r.result;
    };
    r.readAsDataURL(file);
  });
}

/* ---------- Kredi kartı hesapları ---------- */
/** Asgari ödeme oranı: kart limiti 50.000 ₺'ye kadar %20, üstü %40 (kart bazında değiştirilebilir) */
function cardMinRate(c) { return c.minRate > 0 ? c.minRate : (Number(c.limit) || 0) > 50000 ? 40 : 20; }
function cardMinimum(c) {
  const full = c.minPay > 0 ? c.minPay : (Number(c.statement) || 0) * cardMinRate(c) / 100;
  return Math.max(0, Math.round((full - (Number(c.paid) || 0)) * 100) / 100);
}
function nextDue(c) {
  if (!c.dueDay) return null;
  const now = new Date(); now.setHours(0, 0, 0, 0);
  const mk = (y, m) => { const last = new Date(y, m + 1, 0).getDate(); return new Date(y, m, Math.min(c.dueDay, last)); };
  let d = mk(now.getFullYear(), now.getMonth());
  if (d < now) d = mk(now.getFullYear(), now.getMonth() + 1);
  const days = Math.round((d - now) / 864e5);
  return { date: d, days, iso: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` };
}
function dueText(n) { if (!n) return 'Son ödeme günü yok'; return n.days === 0 ? 'Son ödeme bugün' : n.days === 1 ? 'Son ödeme yarın' : `Son ödemeye ${n.days} gün · ${n.date.getDate()} ${MONTHS[n.date.getMonth()]}`; }
