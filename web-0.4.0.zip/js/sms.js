/* Banka SMS'lerini çözümleyen motor + Android yerel SMS okuyucu köprüsü */

const SMS = (() => {
  const norm = (s) => String(s || '')
    .replace(/İ/g, 'i').replace(/I/g, 'ı').toLowerCase()
    .replace(/ı/g, 'i').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ş/g, 's').replace(/ö/g, 'o').replace(/ç/g, 'c');

  // Tutar: "1.250,50 TL", "TL 1.250,50", "250 TL", "₺99,90", "1,250.50 TRY"
  const NUM = '(\\d{1,3}(?:[.,]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?)';
  const AMT_RE = new RegExp(`(?:(?:TL|TRY|₺)\\s?${NUM})|(?:${NUM}\\s?(?:TL|TRY|₺))`, 'gi');

  function parseAmount(s) {
    s = s.trim();
    const lastDot = s.lastIndexOf('.'), lastCom = s.lastIndexOf(',');
    if (lastDot > -1 && lastCom > -1) {
      const dec = lastDot > lastCom ? '.' : ',';
      const th = dec === '.' ? ',' : '.';
      s = s.split(th).join('').replace(dec, '.');
    } else if (lastCom > -1) {
      s = /,\d{1,2}$/.test(s) ? s.replace(/,(?=\d{1,2}$)/, '.').replace(/,/g, '') : s.replace(/,/g, '');
    } else if (lastDot > -1) {
      if (/\.\d{3}$/.test(s)) s = s.replace(/\./g, '');
    }
    const n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }

  const SKIP = [/sifre/, /dogrulama/, /onay kodu/, /tek kullanimlik/, /kodunuz/, /\botp\b/, /guvenlik kodu/, /3d secure/];
  const STATEMENT = [/son odeme tarihi/, /hesap ozeti/, /ekstre/, /asgari odeme/, /donem borcu/];
  /* ---------- Kampanya / reklam ayırt edici ----------
     Gerçek işlem mesajları "geçmiş zaman" ve tamamlanmış ifade içerir (yapılmıştır, gelmiştir…).
     Kampanyalar ise teklif/koşul dili kullanır (… ve üzeri harcamanıza, … varan, kazanın, katılım için …). */
  const DONE = /(yapilmistir|yapildi|gerceklesmistir|gerceklesti|gelmistir|geldi\b|gonderilmistir|gonderildi|yatirilmistir|yatirildi|cekilmistir|cekildi|odenmistir|odendi\b|tahsil edilmistir|tahsil edildi|aktarilmistir|aktarildi|onaylanmistir|onaylandi|iade edilmistir|iade edildi|alinmistir|kesilmistir|gecmistir|harcamaniz|isleminiz|odemeniz alin|hesabiniza .{0,40}(gecti|yatti))/;
  const AD_STRONG = [
    /kampanya/, /firsat/, /kazan(in|abilir|ma sans|dir)/, /\bkatil\b/, /katilim icin/, /katilmak icin/, /yazip \d{3,5}/, /yazarak \d{3,5}/,
    /\bret\b/, /ret icin/, /iptal icin/, /listeden cik/, /ileti(si)? almak istemiyorsaniz/, /mersis/, /\bb0\d\d\b/, /\betk\b/,
    /ve uzeri/, /\b(ye|ya|e|a)? ?varan/, /'?(ye|ya|e|a) kadar (bonus|puan|chip|indirim|iade|taksit)/, /\d+ ?taksit/, /taksit firsati/, /faizsiz/,
    /indirim/, /hediye/, /cekilis/, /ayricalik/, /kacirma/, /son gun/, /simdi (basvur|al|kesfet|yukle)/, /hemen/,
    /https?:\/\//, /www\./, /\.com(\.tr)?\/\S/, /tikla/, /detayli bilgi/, /detaylar/, /basvur/, /on onayli/, /teklif/, /size ozel/,
    /(bonus|chip-?para|maxipuan|worldpuan|parafpara|puan|mil) (kazan|hediye|yuklen|firsat)/, /nakit avans/, /kredi (kampanya|firsat|teklif)/,
    /harcamaniza\b/, /harcamalariniza/, /alisverislerinizde/, /yapacaginiz/, /yaptiginiz takdirde/, /yapmaniz halinde/, /gecerli(dir)?\b/,
  ];
  const PUAN_AFTER = /^\s*['’]?(lik|ye|ya|e|a)?\s*(bonus|chip-?para|maxipuan|worldpuan|parafpara|puan|mil|indirim|iade firsati|hediye)/;
  function adScore(n) { return AD_STRONG.reduce((s, r) => s + (r.test(n) ? 1 : 0), 0); }
  /** Rakamlardan arındırılmış mesaj kalıbı (öğrenilen kampanyaları tanımak için) */
  /* ---------- Kredi kartı ekstre / son ödeme mesajı çözümleyici ---------- */
  const N = '(\\d{1,3}(?:[.,]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?)';
  const ST_TOTAL = new RegExp('(?:donem borcu|ekstre borcu|hesap ozeti borcu|ekstrenizin borcu|ekstre tutari|toplam borc(?:unuz)?|guncel borc(?:unuz)?|borcunuz)\\D{0,25}?' + N);
  const ST_MIN = new RegExp('asgari(?: odeme)?(?: tutari)?(?:niz)?\\D{0,20}?' + N);
  function parseStatement(n, fallbackMs) {
    const total = (n.match(ST_TOTAL) || [])[1], min = (n.match(ST_MIN) || [])[1];
    if (!total && !min) return null;
    let d = n.match(/son odeme(?: tarihi)?(?:niz)?\D{0,15}?(\d{1,2})[./](\d{1,2})[./](\d{2,4})/) || n.match(/(\d{1,2})[./](\d{1,2})[./](\d{2,4})\D{0,30}son odeme/);
    let dueISO = '', dueDay = 0;
    if (d) { const y = d[3].length === 2 ? '20' + d[3] : d[3]; dueISO = `${y}-${pad(+d[2])}-${pad(+d[1])}`; dueDay = +d[1]; }
    const l4 = (n.match(/(\d{4})\s*(?:ile biten|son dort|nolu|no'lu|no lu)/) || n.match(/\*{2,}\s?(\d{4})/) || [])[1] || '';
    return { total: total ? parseAmount(total) : 0, min: min ? parseAmount(min) : 0, dueISO, dueDay, last4: l4 };
  }
  const BANK_HINTS = [
    ['isbank', /isbank|is bankasi|iscep|pozitron|maximum/], ['garanti', /garanti|bonus/], ['akbank', /akbank|axess|wings/],
    ['yapikredi', /yapi ?kredi|ykb|worldcard|world kart/], ['ziraat', /ziraat|bankkart/], ['vakifbank', /vakif/], ['halkbank', /halkbank|paraf/],
    ['qnb', /qnb|finansbank|cardfinans/], ['enpara', /enpara/], ['denizbank', /deniz/], ['teb', /\bteb\b/], ['ing', /\bing\b|ingbank/],
    ['kuveytturk', /kuveyt/], ['turkiyefinans', /turkiye ?finans|happy ?card/], ['albaraka', /albaraka/], ['fibabanka', /fiba/], ['sekerbank', /seker/],
    ['odeabank', /odea/], ['hsbc', /hsbc/], ['papara', /papara/],
  ];
  function guessBank(str) { const s = norm(str); const h = BANK_HINTS.find(([, r]) => r.test(s)); return h ? h[0] : 'other'; }

  function signature(txt) { return hash(norm(txt).replace(/[\d.,:/-]+/g, '#').replace(/\s+/g, ' ').trim()); }

  const IN_WORDS = [
    [/hesabiniza/, 2], [/gelmistir/, 2], [/\bgelen\b/, 1.5], [/yatirildi/, 2], [/yatirilmistir/, 2], [/yatan/, 1],
    [/alacak/, 1.5], [/\biade\b/, 2.5], [/iade edil/, 2.5], [/\bmaas/, 2.5], [/gonderen\s*:/, 1.5], [/tarafindan.*gonderil/, 2],
    [/hesabiniza.*(eft|fast|havale)/, 2], [/(eft|fast|havale).*gelmis/, 2], [/odeme alinmistir/, 1], [/faiz.*yatir/, 1.5],
    [/para girisi/, 2], [/tahsilat/, 1],
  ];
  const OUT_WORDS = [
    [/harcama/, 2], [/\bodeme\b/, 1.2], [/odemeniz/, 1.5], [/cekil/, 2], [/gonderilmistir/, 1.5], [/gonderildi/, 1.5],
    [/hesabinizdan/, 2.5], [/kartinizdan/, 2], [/kartinizla/, 2], [/\bborc/, 1], [/islem yapilmistir/, 1.5], [/kesilmistir/, 2],
    [/alici\s*:/, 1.5], [/satin al/, 2], [/alisveris/, 1.5], [/\bpos\b/, 1], [/otomatik odeme/, 2.5], [/talimat/, 1],
    [/para cikisi/, 2], [/\batm\b/, 1], [/tahsil edilmistir/, 2], [/kesinti/, 1.5],
  ];

  // Satıcı / anahtar kelime -> kategori
  const CAT_RULES = [
    ['market', /migros|a101|\bbim\b|\bsok\b|sok market|carrefour|file market|macro ?center|happy center|onur market|tarim kredi|bizim toptan|metro gross|market|bakkal|manav|kasap|firin/],
    ['food', /yemeksepeti|getir|trendyol ?yemek|migros ?yemek|burger|mcdonald|kfc|domino|pizza|starbucks|kahve|coffee|cafe|kafe|restoran|restaurant|lokanta|doner|simit|baklava|tatli/],
    ['transport', /shell|opet|\bbp\b|petrol ofisi|\bpo\b|total|aytemiz|akaryakit|istanbulkart|ankarakart|kentkart|bitaksi|uber|marti|binbin|thy|turk hava|pegasus|ajet|otopark|hgs|ogs|tcdd|metro istanbul|ispark/],
    ['bills', /enerjisa|ck enerji|bedas|ayedas|igdas|baskentgaz|izmirgaz|iski|aski|izsu|turkcell|vodafone|turk ?telekom|superonline|turknet|fatura|elektrik|dogalgaz|\bsu\b idaresi|aidat/],
    ['subs', /netflix|spotify|youtube|disney|amazon prime|prime video|exxen|blutv|\bmax\b|apple\.com|icloud|google ?(one|play|storage)|chatgpt|openai|claude|anthropic|tod tv|beinsports|gain/],
    ['shopping', /trendyol|hepsiburada|amazon|n11|ciceksepeti|lc ?waikiki|defacto|koton|zara|h&m|mavi|boyner|decathlon|ikea|teknosa|mediamarkt|vatan|english home|watsons|gratis|rossmann/],
    ['health', /eczane|hastane|klinik|saglik|medical|dis hek|doktor|optik/],
    ['fun', /cinemaximum|sinema|biletix|passo|steam|playstation|xbox|epic games|konser|tiyatro/],
    ['edu', /udemy|coursera|kirtasiye|okul|universite|kurs|egitim|kitap|d&r|idefix/],
    ['rent', /\bkira\b/],
    ['debt', /kredi karti borc|kart borcu|kredi taksit|taksit odeme|kredi odeme/],
  ];
  const IN_CAT_RULES = [
    ['salary', /maas|ucret odemesi|personel odeme|bordro/],
    ['scholarship', /\bburs|kyk|kredi ve yurtlar/],
  ];

  const STOP = new Set(['TL', 'TRY', 'EFT', 'FAST', 'POS', 'ATM', 'IBAN', 'SAAT', 'NOLU', 'KART', 'KARTINIZ', 'HESAP', 'BILGI', 'MUSTERI', 'SAYIN', 'TARIH', 'TUTAR', 'ISLEM', 'BANKASI', 'BANK', 'NO', 'REF', 'VE', 'ILE', 'IPTAL', 'SMS', 'B001', 'MERSIS']);

  function findMerchant(text) {
    // Baştaki "BANKA ADI:" önekini at
    text = text.replace(/^[A-ZÇĞİÖŞÜ0-9 .&-]{2,30}:\s*/, '');
    // "... XYZ adlı işyerinden" -> öncesindeki son kelimeler
    const ad = text.match(/\s(?:adl[ıi]|isimli)\s+(?:i[sş]yeri|firma|kurum)/i);
    if (ad) {
      const words = text.slice(0, ad.index).trim().split(/\s+/); const out = [];
      while (words.length && out.length < 4) {
        const w = words.pop();
        if (/tarihinde|saat|^\d{1,2}[./]\d|kart[ıi]n[ıi]zla|^ile$|^de$|^da$|:$/i.test(w)) break;
        out.unshift(w);
      }
      if (out.length) return out.join(' ');
    }
    const pats = [
      /(?:i[sş]yeri|al[ıi]c[ıi]|g[oö]nderen|a[cç][ıi]klama|firma|kurum)\s*[:=\-]\s*([^\n,;]{2,40}?)(?=\s*(?:[,;.]|\s{2}|tutar|tarih|$|\s[A-Za-zçğıöşü]+:))/i,
      /\b([A-ZÇĞİÖŞÜ0-9&.\-*]{2,}(?:\s+[A-ZÇĞİÖŞÜ0-9&.\-*]{2,}){0,4})['’]?\s*(?:dan|den|tan|ten|'dan|'den)\b/,
    ];
    for (const p of pats) {
      const m = text.match(p);
      if (m && m[1]) {
        const v = m[1].replace(/\s+/g, ' ').trim();
        if (v.length >= 2 && !/^\d+$/.test(v) && !STOP.has(v.toUpperCase())) return v;
      }
    }
    // Büyük harfli kelime öbeği (metnin tamamı büyük harf değilse)
    const letters = text.replace(/[^A-Za-zÇĞİÖŞÜçğıöşü]/g, '');
    const upperRatio = letters ? letters.replace(/[^A-ZÇĞİÖŞÜ]/g, '').length / letters.length : 1;
    if (upperRatio < 0.6) {
      const runs = text.match(/\b[A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜ0-9&.\-*]{2,}(?:\s+[A-ZÇĞİÖŞÜ0-9&.\-*]{2,}){0,4}/g) || [];
      const good = runs.map((r) => r.trim()).filter((r) => !r.split(/\s+/).every((w) => STOP.has(w)) && !/^(TL|TRY)$/.test(r));
      if (good.length) return good.sort((a, b) => b.length - a.length)[0];
    }
    return '';
  }

  function findDate(text, fallbackMs) {
    const m = text.match(/(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})/);
    if (m) {
      let [, d, mo, y] = m; y = y.length === 2 ? '20' + y : y;
      const iso = `${y}-${pad(+mo)}-${pad(+d)}`;
      if (!isNaN(new Date(iso).getTime()) && +mo <= 12 && +d <= 31) return iso;
    }
    const f = fallbackMs ? new Date(fallbackMs) : new Date();
    return `${f.getFullYear()}-${pad(f.getMonth() + 1)}-${pad(f.getDate())}`;
  }

  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }

  /** Tek bir SMS'i çözümler. Dönen: {ok, reason?, type, amount, date, cat, note, merchant, confidence, hash, body} */
  function parse(body, meta = {}) {
    const text = String(body || '').trim();
    const n = norm(text);
    const h = hash(n + '|' + (meta.date || ''));
    const base = { body: text, hash: h, sender: meta.address || '' };
    if (!text) return { ...base, ok: false, reason: 'Boş mesaj' };
    if (SKIP.some((r) => r.test(n))) return { ...base, ok: false, reason: 'Şifre / doğrulama mesajı' };
    if (STATEMENT.some((r) => r.test(n)) && !/harcama|islem yapil|gelmistir|gonderil/.test(n)) return { ...base, ok: false, reason: 'Hesap özeti / ekstre bilgisi', statement: parseStatement(n, meta.date) };

    // Tutarları bul, limit/bakiye ifadelerini ele
    const amounts = [];
    let m; AMT_RE.lastIndex = 0;
    while ((m = AMT_RE.exec(text))) {
      const raw = m[1] || m[2];
      const before = norm(text.slice(Math.max(0, m.index - 32), m.index));
      const after = norm(text.slice(m.index + m[0].length, m.index + m[0].length + 24));
      const excluded = /(limit|bakiye|kalan|kullanilabilir|toplam borc|asgari|puan|chip|bonus|maxipuan|worldpuan|ekstre)/.test(before) || PUAN_AFTER.test(after) || /^\s*['’]?(ye|ya|e|a)?\s*(varan|kadar|ve uzeri)/.test(after);
      amounts.push({ v: parseAmount(raw), excluded, idx: m.index });
    }
    const chosen = amounts.find((a) => !a.excluded && a.v > 0) || null;
    if (!chosen) return adScore(n) ? { ...base, ok: false, ad: true, reason: 'Kampanya / reklam mesajı' } : { ...base, ok: false, reason: 'Tutar bulunamadı' };

    let inS = 0, outS = 0;
    for (const [r, w] of IN_WORDS) if (r.test(n)) inS += w;
    for (const [r, w] of OUT_WORDS) if (r.test(n)) outS += w;
    const isStatement = STATEMENT.some((r) => r.test(n)) && !/harcama|islem yapil/.test(n);
    if (isStatement) return { ...base, ok: false, reason: 'Hesap özeti / ekstre bilgisi' };
    // Kampanya kontrolü: öğrenilmiş kalıp, ya da tamamlanmış işlem ifadesi olmadan teklif dili
    const learned = (typeof Store !== 'undefined' && Store.state.adSigs || []).includes(signature(text));
    const ads = adScore(n), done = DONE.test(n);
    if (learned) return { ...base, ok: false, ad: true, reason: 'Kampanya (daha önce işaretledin)' };
    if (!done && ads >= 1) return { ...base, ok: false, ad: true, reason: 'Kampanya / reklam mesajı' };
    if (done && ads >= 3 && inS + outS < 3) return { ...base, ok: false, ad: true, reason: 'Kampanya / reklam mesajı' };

    const type = inS > outS ? 'in' : 'out';
    const confidence = (inS + outS === 0 ? 0.35 : Math.min(1, Math.abs(inS - outS) / 3 + 0.4)) * (done ? 1 : 0.8);
    const merchant = findMerchant(text);
    const hay = norm(merchant + ' ' + text);

    let cat = type === 'in' ? 'otherIn' : 'otherOut';
    const rules = type === 'in' ? IN_CAT_RULES : CAT_RULES;
    for (const [id, r] of rules) if (r.test(hay)) { cat = id; break; }
    if (type === 'out' && cat === 'otherOut' && /(eft|fast|havale)/.test(n)) cat = 'transferOut';

    const note = merchant ? merchant.slice(0, 40) : (type === 'in' ? 'Gelen para' : 'Harcama');
    return { ...base, ok: true, type, amount: Math.round(chosen.v * 100) / 100, date: findDate(text, meta.date), ts: meta.date || 0, cat, note, merchant, confidence };
  }

  /** Yapıştırılmış metni SMS'lere böler (boş satırla ayrılmış) */
  function splitPasted(txt) {
    return String(txt || '').split(/\n\s*\n+/).map((s) => s.trim()).filter(Boolean);
  }

  function senderMatches(address, list) {
    const a = norm(address).replace(/[^a-z0-9]/g, '');
    if (!a) return false;
    return list.split(',').map((s) => norm(s).replace(/[^a-z0-9]/g, '')).filter(Boolean).some((s) => a.includes(s) || s.includes(a));
  }

  return { parse, splitPasted, senderMatches, norm, hash, signature, guessBank };
})();


/* ---------- Android yerel köprü (Capacitor) ---------- */
const Native = {
  isNative() { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); },
  get(name) {
    const C = window.Capacitor; if (!C) return null;
    return (C.Plugins && C.Plugins[name]) || (C.registerPlugin ? C.registerPlugin(name) : null);
  },
  plugin() { return this.get('SmsReader'); },
  akis() { return this.get('Akis'); },
  /** Gelen kutusundaki SMS'leri okur. since: ms */
  async readInbox(since) {
    const p = this.plugin(); if (!p) throw new Error('SMS okuyucu bulunamadı');
    const res = await p.getMessages({ since: Math.floor(since), limit: 800 });
    return res.messages || [];
  },
};

const BANK_RE = /bank|banka|isbank|iscep|pozitron|garanti|akbank|ziraat|vakif|halk|yapikredi|ykb|qnb|finansbank|enpara|deniz|\bteb\b|ingbank|kuveyt|albaraka|papara|fibabanka|odea|sekerbank|cepte|paycell|tosla|ininal|turkiye ?finans|vakifkatilim|emlak ?katilim|ziraatkatilim|hayat ?finans|colendi|midas/i;

/* ---------- Çift kayıt engeli ----------
   Aynı harcama hem SMS hem uygulama bildirimi olarak gelebilir:
   aynı yön + aynı tutar + (30 dk içinde ya da aynı gün) => aynı hareket */
function sameMovement(a, b) {
  if (a.type !== b.type || Math.abs(a.amount - b.amount) > 0.009) return false;
  if (a.ts && b.ts) return Math.abs(a.ts - b.ts) < 30 * 60e3;
  return a.date === b.date;
}
function findDuplicate(r, extra = []) {
  const st = Store.state;
  const auto = st.tx.filter((t) => t.src === 'sms' || t.src === 'notif');
  const hit = [...auto, ...st.pending, ...extra].find((t) => t.hash === r.hash || sameMovement(t, r));
  if (hit) return { kind: 'auto', hit };
  const man = st.tx.find((t) => t.src === 'manual' && t.type === r.type && Math.abs(t.amount - r.amount) < 0.01 && t.date === r.date);
  return man ? { kind: 'manual', hit: man } : null;
}

/** Bulunan hareketleri (SMS/bildirim) çift kayıt kontrolüyle ekler */
function ingest(results, src) {
  const st = Store.state; const s = st.settings; let added = 0; const batch = [];
  for (const r of results) {
    const dup = findDuplicate(r, batch);
    if (dup && dup.kind === 'auto') continue;              // zaten var: atla
    const item = { ...r, id: uid(), src, possibleDup: !!dup }; // elle girilmiş benzeri varsa onaya düşür
    batch.push(item);
    if (s.smsAutoApprove && !dup) st.tx.push({ id: uid(), type: r.type, amount: r.amount, date: r.date, cat: r.cat, note: r.note, src, hash: r.hash, ts: r.ts, body: r.body });
    else st.pending.push(item);
    added++;
  }
  return added;
}

/** Gelen kutusunu tarar */
async function scanSmsInbox({ manual = false } = {}) {
  const st = Store.state; const s = st.settings;
  const since = manual || !s.lastSmsScan ? Date.now() - (s.smsFirstDays || 60) * 864e5 : s.lastSmsScan - 5 * 60e3;
  const msgs = await Native.readInbox(since);
  const seen = new Set(st.seen); const found = [];
  for (const msg of msgs.sort((a, b) => a.date - b.date)) {
    if (!SMS.senderMatches(msg.address, s.smsSenders)) continue;
    const r = SMS.parse(msg.body, { date: msg.date, address: msg.address });
    if (seen.has(r.hash)) continue;
    seen.add(r.hash);
    if (r.ok) found.push(r); else if (r.statement) suggestCard(r, msg.address);
  }
  st.seen = [...seen].slice(-4000);
  s.lastSmsScan = Date.now();
  const n = ingest(found, 'sms');
  Store.save();
  return n;
}

/** Banka uygulaması bildirimlerini okur (bildirim erişimi verildiyse) */
function notifAppAllowed(pkg, label) {
  const conf = Store.state.notifApps[pkg];
  if (conf && typeof conf.on === 'boolean') return conf.on;
  return BANK_RE.test(SMS.norm(pkg + ' ' + (label || '')));
}
async function scanNotifications() {
  const p = Native.akis(); if (!p) return 0;
  const st = Store.state; const s = st.settings;
  const acc = await p.notifAccess(); if (!acc.enabled) return 0;
  const res = await p.getNotifs({ since: Math.max(0, (s.lastNotifScan || 0) - 60e3) });
  const seen = new Set(st.seen); const found = [];
  for (const n of (res.items || []).sort((a, b) => a.time - b.time)) {
    if (!st.notifApps[n.pkg]) st.notifApps[n.pkg] = { label: n.label || n.pkg };
    else st.notifApps[n.pkg].label = n.label || st.notifApps[n.pkg].label;
    if (!notifAppAllowed(n.pkg, n.label)) continue;
    const text = [n.title, n.text].filter(Boolean).join(' — ');
    const r = SMS.parse(text, { date: n.time, address: n.label });
    if (seen.has(r.hash)) continue;
    seen.add(r.hash);
    // Bildirimlerde işlem kelimesi (harcama, ödeme, gelen…) şart: sohbet mesajlarını ele
    if (r.ok && r.confidence >= 0.4) { r.sender = n.label; found.push(r); } else if (r.statement) suggestCard(r, n.label + ' ' + n.pkg);
  }
  st.seen = [...seen].slice(-4000);
  s.lastNotifScan = Date.now();
  const k = ingest(found, 'notif');
  Store.save();
  return k;
}

/** Tüm kaynakları tarar (SMS + bildirim) */
async function scanAllSources({ manual = false } = {}) {
  let n = 0; const errs = [];
  const s = Store.state.settings;
  if (manual || s.smsAuto) { try { n += await scanSmsInbox({ manual }); } catch (e) { errs.push('SMS: ' + (e.message || e)); } }
  if (manual || s.notifAuto) { try { n += await scanNotifications(); } catch (e) { errs.push('Bildirim: ' + (e.message || e)); } }
  return { n, errs };
}
/* ---------- Kampanya öğrenme & geçmiş temizliği ---------- */
/** Kullanıcı bir hareketi "kampanya" diye işaretleyince kalıbı öğrenir; benzerleri bir daha eklenmez */
function learnAd(body) {
  if (!body) return;
  const st = Store.state; st.adSigs = st.adSigs || [];
  const sig = SMS.signature(body);
  if (!st.adSigs.includes(sig)) st.adSigs.push(sig);
  st.adSigs = st.adSigs.slice(-500);
  // Bekleyenlerde aynı kalıptakileri de kaldır
  st.pending = st.pending.filter((p) => SMS.signature(p.body || '') !== sig);
  Store.save();
}
/** Daha önce eklenmiş SMS/bildirim hareketlerini yeni filtreyle yeniden kontrol eder; kampanya olanları siler */
async function cleanupAds() {
  const st = Store.state; let removed = 0;
  const isAd = (body, date) => { const r = SMS.parse(body, { date }); return !r.ok && r.ad ? r.hash : null; };
  // 1) Bekleyenler ve gövdesi saklı hareketler
  const before = st.pending.length;
  st.pending = st.pending.filter((p) => !(p.body && !SMS.parse(p.body, { date: p.ts }).ok));
  removed += before - st.pending.length;
  const adHashes = new Set();
  for (const t of st.tx) if ((t.src === 'sms' || t.src === 'notif') && t.body && !SMS.parse(t.body, { date: t.ts }).ok) adHashes.add(t.hash);
  // 2) Telefondaki SMS'ler ve saklı bildirimler üzerinden eski kayıtları eşleştir
  if (Native.isNative()) {
    try {
      const msgs = await Native.readInbox(Date.now() - 400 * 864e5);
      for (const m of msgs) { const h = isAd(m.body, m.date); if (h) adHashes.add(h); }
    } catch (e) {}
    try {
      const res = await Native.akis().getNotifs({ since: 0 });
      for (const n of res.items || []) { const h = isAd([n.title, n.text].filter(Boolean).join(' — '), n.time); if (h) adHashes.add(h); }
    } catch (e) {}
  }
  const n0 = st.tx.length;
  st.tx = st.tx.filter((t) => !((t.src === 'sms' || t.src === 'notif') && adHashes.has(t.hash)));
  removed += n0 - st.tx.length;
  st.adCleanup = 1; Store.save();
  return removed;
}
/* ---------- Kart ekstresi önerileri ---------- */
function suggestCard(r, sender) {
  const st = Store.state; st.cardSuggest = st.cardSuggest || [];
  const s = r.statement; const bank = SMS.guessBank(sender + ' ' + r.body);
  // Aynı ekstre hem SMS hem bildirim olarak gelebilir: içerik aynıysa tekrar ekleme
  if (st.cardSuggest.some((x) => x.hash === r.hash || (x.bank === bank && x.total === s.total && x.min === s.min && x.dueISO === s.dueISO))) return;
  if ((st.cards || []).some((c) => c.bank === bank && (c.history || []).some((h) => h.sig === `${s.total}|${s.min}|${s.dueISO}`))) return;
  if (r.ts && Date.now() - r.ts > 40 * 864e5) return;
  st.cardSuggest.push({ id: uid(), hash: r.hash, bank, body: r.body, ts: r.ts || Date.now(), ...s });
}