/* Hafif, animasyonlu SVG grafikleri (harici kütüphane yok — çevrimdışı çalışır) */

const Charts = {
  donut(segments, { size = 168, thick = 20, center = '' } = {}) {
    const r = (size - thick) / 2, c = 2 * Math.PI * r;
    const total = segments.reduce((s, x) => s + x.value, 0) || 1;
    let off = 0; const gap = segments.length > 1 ? 2.5 : 0;
    const arcs = segments.map((s, i) => {
      const len = Math.max(0, (s.value / total) * c - gap);
      const el = `<circle class="donut-seg" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${s.color}" stroke-width="${thick}"
        stroke-dasharray="${len} ${c - len}" stroke-dashoffset="${-off}" stroke-linecap="butt" style="--c:${c};animation-delay:${i * 60}ms"/>`;
      off += (s.value / total) * c;
      return el;
    }).join('');
    return `<div class="donut" style="width:${size}px;height:${size}px">
      <svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" style="transform:rotate(-90deg)">
        <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--track)" stroke-width="${thick}"/>${segments.length ? arcs : ''}
      </svg><div class="donut-center">${center}</div></div>`;
  },

  bars(data, { height = 170 } = {}) {
    // data: [{label, a, b}]  a=gelir, b=gider
    const W = 320, H = height, pb = 22, pt = 10;
    const max = Math.max(1, ...data.map((d) => Math.max(d.a, d.b)));
    const gw = W / data.length, bw = Math.min(14, gw / 3.4);
    const y = (v) => H - pb - (v / max) * (H - pb - pt);
    const grid = [0.25, 0.5, 0.75, 1].map((f) => `<line x1="0" x2="${W}" y1="${y(max * f)}" y2="${y(max * f)}" class="grid"/>`).join('');
    const bars = data.map((d, i) => {
      const cx = gw * i + gw / 2;
      return `<g class="bar-g" style="animation-delay:${i * 50}ms">
        <rect x="${cx - bw - 1.5}" y="${y(d.a)}" width="${bw}" height="${Math.max(0, H - pb - y(d.a))}" rx="4" fill="var(--in)"/>
        <rect x="${cx + 1.5}" y="${y(d.b)}" width="${bw}" height="${Math.max(0, H - pb - y(d.b))}" rx="4" fill="var(--out)"/>
        <text x="${cx}" y="${H - 6}" text-anchor="middle" class="axis ${d.active ? 'active' : ''}">${d.label}</text></g>`;
    }).join('');
    return `<svg class="chart" viewBox="0 0 ${W} ${H}">${grid}${bars}</svg>`;
  },

  /* Çok serili çizgi grafiği + dokunarak gezinme */
  line(el, { labels, series, height = 200, fmt = compact }) {
    const W = 340, H = height, pl = 4, pr = 4, pt = 14, pb = 24;
    const all = series.flatMap((s) => s.values);
    let min = Math.min(0, ...all), max = Math.max(1, ...all);
    const span = max - min || 1; max += span * 0.08;
    const n = labels.length;
    const x = (i) => pl + (n <= 1 ? 0 : (i / (n - 1)) * (W - pl - pr));
    const y = (v) => pt + (1 - (v - min) / (max - min)) * (H - pt - pb);
    const path = (vals) => vals.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join('');
    const grid = [0, 0.25, 0.5, 0.75, 1].map((f) => { const v = min + (max - min) * f; return `<line x1="0" x2="${W}" y1="${y(v)}" y2="${y(v)}" class="grid"/>`; }).join('');
    const zero = min < 0 ? `<line x1="0" x2="${W}" y1="${y(0)}" y2="${y(0)}" class="zero"/>` : '';
    const step = Math.max(1, Math.ceil(n / 6));
    const ticks = labels.map((l, i) => (i % step === 0 || i === n - 1) && (i === n - 1 || n - 1 - i >= step * 0.9)
      ? `<text x="${x(i)}" y="${H - 6}" text-anchor="${i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle'}" class="axis">${l}</text>` : '').join('');
    const defs = series.map((s, k) => `<linearGradient id="lg${k}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.color}" stop-opacity=".28"/><stop offset="1" stop-color="${s.color}" stop-opacity="0"/></linearGradient>`).join('');
    const paths = series.map((s, k) => {
      const p = path(s.values);
      const area = s.area ? `<path d="${p}L${x(n - 1)},${y(Math.max(min, 0))}L${x(0)},${y(Math.max(min, 0))}Z" fill="url(#lg${k})" class="area"/>` : '';
      return `${area}<path d="${p}" pathLength="1" fill="none" stroke="${s.color}" stroke-width="${s.width || 2.4}" stroke-linejoin="round" stroke-linecap="round" class="line-path" ${s.dash ? 'stroke-dasharray="4 4"' : ''} style="animation-delay:${k * 120}ms"/>`;
    }).join('');
    el.innerHTML = `<div class="line-wrap"><svg class="chart" viewBox="0 0 ${W} ${H}"><defs>${defs}</defs>${grid}${zero}${paths}
      <line class="cursor" x1="0" x2="0" y1="${pt}" y2="${H - pb}" style="opacity:0"/>${series.map((s, k) => `<circle class="dot" data-k="${k}" r="4.5" fill="${s.color}" style="opacity:0"/>`).join('')}${ticks}</svg>
      <div class="tip" style="opacity:0"></div></div>`;

    const svg = el.querySelector('svg'), tip = el.querySelector('.tip'), cur = el.querySelector('.cursor'), dots = el.querySelectorAll('.dot');
    const show = (clientX) => {
      const r = svg.getBoundingClientRect();
      const rel = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
      const i = Math.round(rel * (n - 1));
      const px = x(i);
      cur.setAttribute('x1', px); cur.setAttribute('x2', px); cur.style.opacity = 1;
      dots.forEach((d, k) => { d.setAttribute('cx', px); d.setAttribute('cy', y(series[k].values[i])); d.style.opacity = 1; });
      tip.innerHTML = `<b>${labels[i]}</b>${series.map((s) => `<span><i style="background:${s.color}"></i>${s.name}: ${fmt(s.values[i])}</span>`).join('')}`;
      tip.style.opacity = 1;
      const tx = (px / W) * r.width; const tw = tip.offsetWidth;
      tip.style.left = Math.min(r.width - tw, Math.max(0, tx - tw / 2)) + 'px';
    };
    const hide = () => { cur.style.opacity = 0; tip.style.opacity = 0; dots.forEach((d) => (d.style.opacity = 0)); };
    svg.addEventListener('pointerdown', (e) => { show(e.clientX); });
    svg.addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse' || e.buttons) show(e.clientX); });
    svg.addEventListener('pointerleave', hide);
    svg.addEventListener('pointerup', (e) => { if (e.pointerType !== 'mouse') setTimeout(hide, 1600); });
  },
};
