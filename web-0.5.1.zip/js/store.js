/* Veri katmanı: kategoriler, biçimlendirme, kalıcı depolama */

const CATEGORIES = {
  out: [
    { id: 'market', name: 'Market', icon: 'cart', color: '#16a34a' },
    { id: 'food', name: 'Yemek', icon: 'food', color: '#f97316' },
    { id: 'transport', name: 'Ulaşım', icon: 'car', color: '#0ea5e9' },
    { id: 'bills', name: 'Fatura', icon: 'bolt', color: '#eab308' },
    { id: 'rent', name: 'Kira', icon: 'house', color: '#6366f1' },
    { id: 'shopping', name: 'Alışveriş', icon: 'bag', color: '#ec4899' },
    { id: 'health', name: 'Sağlık', icon: 'heart', color: '#ef4444' },
    { id: 'fun', name: 'Eğlence', icon: 'film', color: '#a855f7' },
    { id: 'subs', name: 'Abonelik', icon: 'tv', color: '#8b5cf6' },
    { id: 'edu', name: 'Eğitim', icon: 'book', color: '#14b8a6' },
    { id: 'debt', name: 'Kredi / Kart', icon: 'card', color: '#64748b' },
    { id: 'transferOut', name: 'Giden Transfer', icon: 'swap', color: '#0891b2' },
    { id: 'toSavings', name: 'Birikime Aktarım', icon: 'piggy', color: '#2563eb', internal: true },
    { id: 'otherOut', name: 'Diğer', icon: 'dots', color: '#94a3b8' },
  ],
  in: [
    { id: 'salary', name: 'Maaş', icon: 'briefcase', color: '#16a34a' },
    { id: 'scholarship', name: 'Burs', icon: 'book', color: '#0ea5e9' },
    { id: 'otherIn', name: 'Diğer', icon: 'dots', color: '#94a3b8' },
    { id: 'fromSavings', name: 'Birikimden Çekim', icon: 'piggy', color: '#2563eb', internal: true, hidden: true },
    { id: 'collected', name: 'Alacak Tahsili', icon: 'in', color: '#14b8a6', hidden: true },
    { id: 'extra', name: 'Ek Gelir', icon: 'gift', color: '#0ea5e9', hidden: true },
    { id: 'transferIn', name: 'Gelen Transfer', icon: 'swap', color: '#6366f1', hidden: true },
    { id: 'refund', name: 'İade', icon: 'undo', color: '#f97316', hidden: true },
    { id: 'interest', name: 'Faiz / Getiri', icon: 'percent', color: '#eab308', hidden: true },
  ],
};

const ASSET_TYPES = {
  savings: [
    { id: 'deposit', name: 'Vadeli Mevduat', icon: 'bank', color: '#2563eb' },
    { id: 'cash', name: 'Nakit / Kumbara', icon: 'piggy', color: '#0ea5e9' },
    { id: 'goal', name: 'Hedef Birikimi', icon: 'target', color: '#14b8a6' },
    { id: 'emergency', name: 'Acil Durum Fonu', icon: 'safe', color: '#6366f1' },
  ],
  investment: [
    { id: 'gold', name: 'Altın', icon: 'gold', color: '#eab308' },
    { id: 'silver', name: 'Gümüş / Maden', icon: 'gold', color: '#94a3b8' },
    { id: 'fx', name: 'Döviz', icon: 'dollar', color: '#16a34a' },
    { id: 'stock', name: 'Hisse Senedi', icon: 'trend', color: '#ef4444' },
    { id: 'fund', name: 'Yatırım Fonu', icon: 'pie', color: '#a855f7' },
    { id: 'crypto', name: 'Kripto', icon: 'crypto', color: '#f97316' },
    { id: 'otherInv', name: 'Diğer', icon: 'coins', color: '#64748b' },
  ],
};

const catById = (id) => [...CATEGORIES.out, ...CATEGORIES.in].find((c) => c.id === id) || CATEGORIES.out[CATEGORIES.out.length - 1];
const visibleCats = (type) => CATEGORIES[type].filter((c) => !c.hidden);
const assetTypeById = (id) => [...ASSET_TYPES.savings, ...ASSET_TYPES.investment].find((t) => t.id === id) || ASSET_TYPES.investment[ASSET_TYPES.investment.length - 1];

/* Canlı fiyatı takip edilebilen enstrümanlar
   src: tg = Türkiye piyasası (altın/gümüş/döviz), cg = kripto, yh = BIST hisse */
const INSTRUMENTS = [
  { id: 'GRA', name: 'Gram Altın', unit: 'gr', src: 'tg', type: 'gold' },
  { id: 'CEYREKALTIN', name: 'Çeyrek Altın', unit: 'adet', src: 'tg', type: 'gold' },
  { id: 'YARIMALTIN', name: 'Yarım Altın', unit: 'adet', src: 'tg', type: 'gold' },
  { id: 'TAMALTIN', name: 'Tam Altın', unit: 'adet', src: 'tg', type: 'gold' },
  { id: 'CUMHURIYETALTINI', name: 'Cumhuriyet Altını', unit: 'adet', src: 'tg', type: 'gold' },
  { id: 'YIA', name: '22 Ayar Bilezik', unit: 'gr', src: 'tg', type: 'gold' },
  { id: 'GUMUS', name: 'Gram Gümüş', unit: 'gr', src: 'tg', type: 'silver' },
  { id: 'GPL', name: 'Gram Platin', unit: 'gr', src: 'tg', type: 'silver' },
  { id: 'USD', name: 'Dolar', unit: 'USD', src: 'tg', type: 'fx' },
  { id: 'EUR', name: 'Euro', unit: 'EUR', src: 'tg', type: 'fx' },
  { id: 'GBP', name: 'Sterlin', unit: 'GBP', src: 'tg', type: 'fx' },
  { id: 'CHF', name: 'İsviçre Frangı', unit: 'CHF', src: 'tg', type: 'fx' },
  { id: 'bitcoin', name: 'Bitcoin', unit: 'BTC', src: 'cg', type: 'crypto' },
  { id: 'ethereum', name: 'Ethereum', unit: 'ETH', src: 'cg', type: 'crypto' },
  { id: 'solana', name: 'Solana', unit: 'SOL', src: 'cg', type: 'crypto' },
  { id: 'ripple', name: 'XRP', unit: 'XRP', src: 'cg', type: 'crypto' },
  { id: 'tether', name: 'Tether', unit: 'USDT', src: 'cg', type: 'crypto' },
  { id: 'FUND', name: 'Yatırım Fonu (TEFAS)', unit: 'pay', src: 'tf', type: 'fund', fund: true },
  { id: 'BIST', name: 'BIST Hisse', unit: 'lot', src: 'yh', type: 'stock', symbol: true },
];
const instrById = (id) => INSTRUMENTS.find((i) => i.id === id);
const priceKey = (track) => (track.src === 'yh' || track.src === 'tf' ? track.src + ':' + String(track.sym || '').toUpperCase() : track.src + ':' + track.id);

/* ---------- Biçimlendirme ---------- */
const _fmt = new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const _fmt0 = new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 });
const MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const MONTHS_S = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
const DAYS = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];

function money(v, opts = {}) {
  if (opts.mask !== false && Store.state.settings.hide) return '₺ •••••';
  const n = Number(v) || 0;
  const s = (opts.short ? _fmt0 : _fmt).format(Math.abs(n));
  const sign = n < 0 ? '-' : opts.sign && n > 0 ? '+' : '';
  return `${sign}₺${s}`;
}
function compact(v) {
  const n = Math.abs(v), s = v < 0 ? '-' : '';
  if (n >= 1e6) return `${s}₺${(n / 1e6).toLocaleString('tr-TR', { maximumFractionDigits: 1 })} Mn`;
  if (n >= 1e3) return `${s}₺${(n / 1e3).toLocaleString('tr-TR', { maximumFractionDigits: 0 })} B`;
  return `${s}₺${_fmt0.format(n)}`;
}
function pct(v, d = 1) { return `%${(Number(v) || 0).toLocaleString('tr-TR', { maximumFractionDigits: d })}`; }

function parseNum(str) {
  if (typeof str === 'number') return str;
  let s = String(str || '').replace(/[₺\s]|TL/gi, '').trim();
  if (!s) return 0;
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if ((s.match(/\./g) || []).length > 1 || /\.\d{3}$/.test(s)) s = s.replace(/\./g, '');
  const n = parseFloat(s);
  return isFinite(n) ? n : 0;
}
function numInput(v) {
  if (!v && v !== 0) return '';
  return Number(v).toLocaleString('tr-TR', { maximumFractionDigits: 2 });
}

const pad = (n) => String(n).padStart(2, '0');
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const ymOf = (iso) => iso.slice(0, 7);
const ymNow = () => todayISO().slice(0, 7);
function ymAdd(ym, k) { let [y, m] = ym.split('-').map(Number); m += k; while (m < 1) { m += 12; y--; } while (m > 12) { m -= 12; y++; } return `${y}-${pad(m)}`; }
function ymLabel(ym, short) { const [y, m] = ym.split('-').map(Number); return short ? `${MONTHS_S[m - 1]} ${String(y).slice(2)}` : `${MONTHS[m - 1]} ${y}`; }
function dayLabel(iso) {
  const t = todayISO(); const y = new Date(Date.now() - 864e5);
  const yIso = `${y.getFullYear()}-${pad(y.getMonth() + 1)}-${pad(y.getDate())}`;
  if (iso === t) return 'Bugün';
  if (iso === yIso) return 'Dün';
  const d = new Date(iso + 'T12:00:00');
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${DAYS[d.getDay()]}`;
}
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- Depolama ---------- */
const DEFAULT_SENDERS = 'ISBANK, IS BANKASI, ISCEP, GARANTI, GARANTIBBVA, AKBANK, YAPIKREDI, YKB, ZIRAAT, VAKIFBANK, HALKBANK, QNB, ENPARA, DENIZBANK, TEB, ING, KUVEYTTURK, ALBARAKA, FIBABANKA, SEKERBANK, ODEABANK, PAPARA, ININAL';

const Store = (() => {
  const KEY = 'akis.v2';
  const defaults = () => ({
    v: 1,
    onboarded: false,
    settings: {
      name: '', theme: 'system', hide: false, openingBalance: 0,
      smsAuto: true, smsAutoApprove: false, smsSenders: DEFAULT_SENDERS, smsFirstDays: 60, lastSmsScan: 0,
      notifAuto: true, lastNotifScan: 0, priceAlerts: true, sweetNotifs: true,
      palette: 'navy', updateUrl: '', lastUpdateCheck: 0, ipoNotify: true, cardReminders: true,
      layout: {
        home: [{ id: 'dock', on: true }, { id: 'month', on: true }, { id: 'debts', on: true }, { id: 'recv', on: true }, { id: 'spend', on: true }, { id: 'recent', on: true }],
        recentCount: 5, tabbar: 'normal', tabLabels: true, density: 'normal', radius: 'normal', scale: 'normal', hero: 'normal',
        txDefault: 'list', assetsDefault: 'all',
      },
    },
    cards: [],    // kredi kartları {id,bank,name,last4,limit,current,statement,paid,minRate,minPay,cutDay,dueDay,history:[]}
    bankLogos: {},// kullanıcının yüklediği banka logoları
    tx: [],       // {id,type:'in'|'out',amount,date,cat,note,src:'manual'|'sms'|'notif',hash,ts}
    assets: [],   // {id,kind,type,name,value,cost,qty,unit,rate,target,track:{src,id,sym},alert:{basis,below,above},history:[]}
    debts: [],    // {id,name,amount,remaining,due,note,history:[]}
    receivables: [], // alacaklar {id,name,amount,remaining,due,note,history:[]}
    adSigs: [],   // kampanya olarak öğrenilmiş mesaj kalıpları
    adCleanup: 0,
    cardSuggest: [], // SMS/bildirimden bulunan kart ekstreleri
    bes: null,    // bireysel emeklilik
    pending: [],  // SMS/bildirimden gelen, onay bekleyen hareketler
    seen: [],     // işlenmiş mesaj hash'leri
    notifApps: {},// {paket: {label, on:true|false}}
    prices: {},   // {anahtar: {p, t}}
    pricesAt: 0,
    simHorizons: [6, 12, 24, 60, 120],
    sim: null,
  });
  function merge(base, over) {
    for (const k in over) {
      if (over[k] && typeof over[k] === 'object' && !Array.isArray(over[k]) && base[k] && typeof base[k] === 'object') merge(base[k], over[k]);
      else base[k] = over[k];
    }
    return base;
  }
  let state;
  try { const raw = localStorage.getItem(KEY); state = raw ? merge(defaults(), JSON.parse(raw)) : defaults(); }
  catch (e) { state = defaults(); }

  let t;
  function save() { clearTimeout(t); t = setTimeout(() => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }, 60); }

  return {
    get state() { return state; },
    save,
    replace(obj) { state = merge(defaults(), obj); save(); },
    reset() { state = defaults(); state.onboarded = false; try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} },
    exportJSON() { return JSON.stringify(state, null, 1); },
    defaultsLayout() { return defaults().settings.layout; },
  };
})();

/* ---------- Hesaplamalar ---------- */
const Calc = {
  balance() {
    const s = Store.state;
    return s.tx.reduce((a, t) => a + (t.type === 'in' ? t.amount : -t.amount), Number(s.settings.openingBalance) || 0);
  },
  savingsTotal() { return Store.state.assets.filter((a) => a.kind === 'savings').reduce((s, a) => s + (a.value || 0), 0); },
  investTotal() { return Store.state.assets.filter((a) => a.kind === 'investment').reduce((s, a) => s + (a.value || 0), 0); },
  investCost() { return Store.state.assets.filter((a) => a.kind === 'investment').reduce((s, a) => s + (a.cost || 0), 0); },
  cardTotal() { return (Store.state.cards || []).reduce((s, c) => s + Math.max(0, Number(c.current) || 0), 0); },
  debtTotal() { return (Store.state.debts || []).reduce((s, d) => s + Math.max(0, d.remaining || 0), 0) + this.cardTotal(); },
  besTotal() { const b = Store.state.bes; return b ? (Number(b.fund) || 0) + (Number(b.state) || 0) : 0; },
  recvTotal() { return (Store.state.receivables || []).reduce((s, d) => s + Math.max(0, d.remaining || 0), 0); },
  netWorth() { return this.balance() + this.savingsTotal() + this.investTotal() + this.besTotal() + this.recvTotal() - this.debtTotal(); },
  monthTx(ym) { return Store.state.tx.filter((t) => ymOf(t.date) === ym); },
  monthSums(ym) {
    let inc = 0, out = 0;
    for (const t of this.monthTx(ym)) {
      if (catById(t.cat).internal) continue;
      if (t.type === 'in') inc += t.amount; else out += t.amount;
    }
    return { inc, out, net: inc - out };
  },
  byCategory(ym, type = 'out') {
    const map = {};
    for (const t of this.monthTx(ym)) {
      if (t.type !== type || catById(t.cat).internal) continue;
      map[t.cat] = (map[t.cat] || 0) + t.amount;
    }
    return Object.entries(map).map(([id, v]) => ({ cat: catById(id), value: v })).sort((a, b) => b.value - a.value);
  },
  /* Son n tamamlanmış ayın ortalamaları (simülasyon için) */
  averages(n = 3) {
    const cur = ymNow(); const months = []; for (let i = 1; i <= n; i++) months.push(ymAdd(cur, -i));
    const has = months.filter((m) => this.monthTx(m).length);
    if (!has.length) return null;
    let inc = 0, sal = 0; const cats = {};
    for (const m of has) {
      for (const t of this.monthTx(m)) {
        if (catById(t.cat).internal) continue;
        if (t.type === 'in') { inc += t.amount; if (t.cat === 'salary') sal += t.amount; }
        else cats[t.cat] = (cats[t.cat] || 0) + t.amount;
      }
    }
    const k = has.length;
    return {
      months: k, income: inc / k, salary: sal / k,
      expenses: Object.entries(cats).map(([id, v]) => ({ name: catById(id).name, amount: Math.round(v / k) })).sort((a, b) => b.amount - a.amount),
    };
  },
};

/* ---------- Demo verisi ---------- */
function buildDemo() {
  const tx = []; const cur = ymNow();
  const rnd = (a, b) => Math.round((a + Math.random() * (b - a)) * 100) / 100;
  const today = todayISO();
  const add = (date, type, amount, cat, note, src = 'manual') => { if (date <= today) tx.push({ id: uid(), type, amount, date, cat, note, src }); };
  const shops = { market: ['MIGROS', 'A101', 'BIM', 'SOK MARKET', 'CARREFOURSA'], food: ['YEMEKSEPETI', 'GETIR', 'BURGER KING', 'STARBUCKS'], transport: ['SHELL', 'OPET', 'ISTANBULKART', 'BITAKSI'], shopping: ['TRENDYOL', 'HEPSIBURADA', 'LC WAIKIKI', 'DECATHLON'], fun: ['CINEMAXIMUM', 'BILETIX', 'STEAM'] };
  for (let i = 5; i >= 0; i--) {
    const ym = ymAdd(cur, -i);
    add(`${ym}-01`, 'in', 52000, 'salary', 'Maaş ödemesi', 'sms');
    add(`${ym}-02`, 'out', 17500, 'rent', 'Ev kirası');
    add(`${ym}-05`, 'out', rnd(850, 1400), 'bills', 'ENERJISA elektrik', 'sms');
    add(`${ym}-07`, 'out', rnd(400, 650), 'bills', 'IGDAS doğalgaz', 'sms');
    add(`${ym}-09`, 'out', 499.9, 'bills', 'TURKCELL fatura', 'sms');
    add(`${ym}-10`, 'out', 229.99, 'subs', 'NETFLIX');
    add(`${ym}-10`, 'out', 99.99, 'subs', 'SPOTIFY');
    add(`${ym}-03`, 'out', 5000, 'toSavings', 'Birikim hesabına aktarım');
    for (let k = 0; k < 7; k++) { const d = pad(2 + Math.floor(Math.random() * 26)); const s = shops.market[k % 5]; add(`${ym}-${d}`, 'out', rnd(180, 1350), 'market', s, Math.random() > .4 ? 'sms' : 'manual'); }
    for (let k = 0; k < 6; k++) { const d = pad(2 + Math.floor(Math.random() * 26)); add(`${ym}-${d}`, 'out', rnd(150, 700), 'food', shops.food[k % 4], 'sms'); }
    for (let k = 0; k < 4; k++) { const d = pad(2 + Math.floor(Math.random() * 26)); add(`${ym}-${d}`, 'out', rnd(300, 1800), 'transport', shops.transport[k % 4], 'sms'); }
    for (let k = 0; k < 2; k++) { const d = pad(2 + Math.floor(Math.random() * 26)); add(`${ym}-${d}`, 'out', rnd(400, 3200), 'shopping', shops.shopping[(i + k) % 4], 'sms'); }
    if (i % 2 === 0) add(`${ym}-18`, 'out', rnd(350, 1200), 'fun', shops.fun[i % 3]);
    if (i % 3 === 1) add(`${ym}-21`, 'in', rnd(3000, 8000), 'extra', 'Serbest iş ödemesi');
    if (i === 2) add(`${ym}-14`, 'out', 1450, 'health', 'Diş kontrolü');
    if (i === 1) add(`${ym}-12`, 'in', 640, 'refund', 'TRENDYOL iade', 'sms');
  }
  const h = (amount, note, daysAgo) => ({ id: uid(), amount, note, date: new Date(Date.now() - daysAgo * 864e5).toISOString().slice(0, 10) });
  const assets = [
    { id: uid(), kind: 'savings', type: 'deposit', name: 'Vadeli Hesap', value: 185000, rate: 42, target: 0, history: [h(150000, 'Açılış', 180), h(30000, 'Aylık aktarımlar', 30), h(5000, 'Faiz getirisi', 2)] },
    { id: uid(), kind: 'savings', type: 'emergency', name: 'Acil Durum Fonu', value: 42000, rate: 0, target: 90000, history: [h(42000, 'Açılış', 120)] },
    { id: uid(), kind: 'savings', type: 'goal', name: 'Tatil', value: 18500, rate: 0, target: 40000, history: [h(18500, 'Açılış', 60)] },
    { id: uid(), kind: 'investment', type: 'gold', name: 'Gram Altın', qty: 25, unit: 'gr', cost: 72500, value: 86750, history: [h(72500, 'Alım: 25 gr', 200)] },
    { id: uid(), kind: 'investment', type: 'fx', name: 'Dolar', qty: 1500, unit: 'USD', cost: 48900, value: 51600, history: [h(48900, 'Alım: 1.500 USD', 150)] },
    { id: uid(), kind: 'investment', type: 'fund', name: 'Hisse Senedi Fonu', qty: 0, unit: '', cost: 30000, value: 34200, history: [h(30000, 'Alım', 90)] },
    { id: uid(), kind: 'investment', type: 'crypto', name: 'Bitcoin', qty: 0.012, unit: 'BTC', cost: 38000, value: 35100, history: [h(38000, 'Alım', 70)] },
  ];
  return { tx, assets, openingBalance: 12000 };
}
