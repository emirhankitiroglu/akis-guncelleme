/* Gelecek simülasyonu motoru */

/* Başlangıçta her şey sıfır — kullanıcı kendisi ayarlar */
function simDefaults() {
  return {
    horizon: (Store.state.simHorizons || [12])[1] || 12,
    salary: 0, raisePct: 0, raiseMode: 'jan_jul', extraIncome: 0,
    incomeMode: 'fixed', hourly: 0, hoursPerDay: 0, daysPerWeek: 0, raiseType: 'pct', raiseAmt: 0,
    investMode: 'pct', investAmt: 0,
    expenses: [],
    inflation: 0, depositRate: 0, investRatio: 0, investReturn: 0,
    autoStart: true, startCash: 0, startInv: 0,
    events: [],
  };
}
const horizonLabel = (m) => (m % 12 === 0 ? `${m / 12} Yıl` : `${m} Ay`);

/* ---------- Bireysel Emeklilik (BES) ---------- */
function besDefaults() {
  return { company: '', start: '', monthly: 0, paid: 0, fund: 0, state: 0, stateRate: 30, ret: 0, birthYear: 0, retireAge: 56, yearlyCap: 0 };
}
/** Devlet katkısı hak ediş oranı: sistemde kalınan yıla ve yaşa göre */
function besVesting(years, age) {
  if (years >= 10 && age >= 56) return 100;
  if (years >= 10) return 60;
  if (years >= 6) return 35;
  if (years >= 3) return 15;
  return 0;
}
function besCalc(b) {
  const now = new Date();
  const [sy, sm] = (b.start || '').split('-').map(Number);
  const months = sy ? Math.max(0, (now.getFullYear() - sy) * 12 + (now.getMonth() + 1 - sm)) : 0;
  const years = months / 12;
  const age = b.birthYear ? now.getFullYear() - b.birthYear : 0;
  const vest = besVesting(years, age);
  // Emekliliğe kadar projeksiyon: en az 10 yıl ve 56 yaş
  const toTenYears = Math.max(0, 120 - months);
  const toAge = b.birthYear ? Math.max(0, (b.birthYear + (b.retireAge || 56) - now.getFullYear()) * 12 - now.getMonth()) : 0;
  const left = Math.max(toTenYears, toAge);
  const r = Math.pow(1 + (Number(b.ret) || 0) / 100, 1 / 12) - 1;
  let fund = Number(b.fund) || 0, st = Number(b.state) || 0, paid = Number(b.paid) || 0, stateAdded = 0;
  const monthly = Number(b.monthly) || 0, rate = (Number(b.stateRate) || 0) / 100, cap = Number(b.yearlyCap) || 0;
  let yearState = 0, curYear = now.getFullYear();
  for (let i = 1; i <= left; i++) {
    const y = new Date(now.getFullYear(), now.getMonth() + i, 1).getFullYear();
    if (y !== curYear) { curYear = y; yearState = 0; }
    let add = monthly * rate;
    if (cap > 0) add = Math.max(0, Math.min(add, cap - yearState));
    yearState += add;
    fund = fund * (1 + r) + monthly; st = st * (1 + r) + add; paid += monthly; stateAdded += add;
  }
  const end = new Date(now.getFullYear(), now.getMonth() + left, 1);
  const milestones = [3, 6, 10].map((y) => ({ y, date: sy ? new Date(sy, sm - 1 + y * 12, 1) : null, pct: besVesting(y, y === 10 ? 0 : 0) }));
  return {
    months, years, age, vest,
    vestedState: (Number(b.state) || 0) * vest / 100,
    nowTotal: (Number(b.fund) || 0) + (Number(b.state) || 0) * vest / 100,
    gain: (Number(b.fund) || 0) - (Number(b.paid) || 0),
    left, end, projFund: fund, projState: st, projPaid: paid, stateAdded, milestones,
  };
}

function runSim(p) {
  const startYm = ymAdd(ymNow(), 1);
  let cash = p.autoStart ? Calc.balance() + Calc.savingsTotal() : Number(p.startCash) || 0;
  let inv = p.autoStart ? Calc.investTotal() : Number(p.startInv) || 0;
  const start = cash + inv;
  const baseExp = p.expenses.reduce((s, e) => s + (Number(e.amount) || 0), 0);
  const infM = Math.pow(1 + (p.inflation || 0) / 100, 1 / 12);
  const depM = Math.pow(1 + (p.depositRate || 0) / 100, 1 / 12);
  const invM = Math.pow(1 + (p.investReturn || 0) / 100, 1 / 12);
  // Gelir: sabit maaş ya da part-time (saatlik ücret × saat × gün)
  const hourlyMode = p.incomeMode === 'hourly';
  let hourly = Number(p.hourly) || 0;
  const monthlyHours = (Number(p.hoursPerDay) || 0) * (Number(p.daysPerWeek) || 0) * 52 / 12;
  let salary = hourlyMode ? hourly * monthlyHours : Number(p.salary) || 0;
  let extra = Number(p.extraIncome) || 0;
  const rows = [];
  let totIn = 0, totOut = 0, totInterest = 0, totReturn = 0, negMonth = null;
  for (let i = 0; i < p.horizon; i++) {
    const ym = ymAdd(startYm, i);
    const mon = +ym.slice(5);
    const raise = (p.raiseMode === 'jan_jul' && (mon === 1 || mon === 7)) || (p.raiseMode === 'jan' && mon === 1);
    if (raise) {
      // Zam: yüzde ya da sabit tutar (saatlik modda saat ücretine eklenir)
      if (p.raiseType === 'amount') { if (hourlyMode) hourly += Number(p.raiseAmt) || 0; else salary += Number(p.raiseAmt) || 0; }
      else { if (hourlyMode) hourly *= 1 + (p.raisePct || 0) / 100; else salary *= 1 + (p.raisePct || 0) / 100; }
      if (hourlyMode) salary = hourly * monthlyHours;
    }
    const income = salary + extra;
    const expense = baseExp * Math.pow(infM, i + 1);
    const ev = p.events.filter((e) => e.ym === ym).reduce((s, e) => s + (Number(e.amount) || 0), 0);
    const surplus = income - expense + ev;
    if (surplus > 0) { const toInv = p.investMode === 'amount' ? Math.min(surplus, Number(p.investAmt) || 0) : surplus * (p.investRatio || 0) / 100; inv += toInv; cash += surplus - toInv; }
    else { cash += surplus; if (cash < 0 && inv > 0) { const take = Math.min(inv, -cash); inv -= take; cash += take; } }
    const intr = cash > 0 ? cash * (depM - 1) : 0; cash += intr;
    const ret = inv * (invM - 1); inv += ret;
    totIn += income + Math.max(0, ev); totOut += expense + Math.max(0, -ev); totInterest += intr; totReturn += ret;
    const total = cash + inv;
    if (total < 0 && negMonth === null) negMonth = ym;
    rows.push({ ym, income, expense, ev, surplus, cash, inv, total, real: total / Math.pow(infM, i + 1) });
  }
  const last = rows[rows.length - 1] || { total: start, real: start };
  return { rows, start, end: last.total, endReal: last.real, totIn, totOut, totInterest, totReturn, negMonth, avgSave: totIn ? (totIn - totOut) / totIn * 100 : 0 };
}

/* ---------- Borç kapanış simülasyonu ----------
   Aylık faiz eklenir, sonra ödeme düşülür; borç bitene kadar (en fazla 50 yıl) */
function debtPayoff(amount, monthlyRatePct, payment) {
  let bal = Number(amount) || 0; const r = (Number(monthlyRatePct) || 0) / 100; const pay = Number(payment) || 0;
  const rows = [bal]; let interest = 0, paid = 0, m = 0;
  if (bal <= 0) return { months: 0, interest: 0, paid: 0, rows, never: false };
  if (pay <= bal * r) return { months: Infinity, interest: Infinity, paid: Infinity, rows, never: true, minPay: bal * r };
  while (bal > 0.005 && m < 600) {
    const i = bal * r; interest += i; bal += i;
    const p = Math.min(pay, bal); bal -= p; paid += p; m++; rows.push(bal);
  }
  return { months: m, interest, paid, rows, never: false };
}